<?php

class StatementsHelper {
	public function getStatusStr( $statement ) {
		$statuses  = array(
			0 => 'Incomplete',
			1 => 'Completed',
			2 => 'Failed',
			3 => 'Passed',
		);
		$status    = $this->getStatus( $statement );
		$statusStr = $statuses[ $status ];
		return $statusStr;
	}

	public function getScoreStr( $statement ) {
		$status   = $this->getStatus( $statement );
		$scoreStr = 'N/A';
		$score    = $statement['result']['score']['scaled'];
		if ( isset( $score ) && $status > 1 ) {
			$scoreStr = strval( $score * 100 );
		}
		// check to see if the raw value is in the statement
		else {
			 $score = $statement['result']['score']['raw'];
			if ( isset( $score ) && $status > 1 ) {
				$scoreMax = $statement['result']['score']['max'];
				$scoreStr = strval( ( $score * 100 ) / $scoreMax );
			}
		}
		return $scoreStr;
	}

	public function getTimestampStr( $statement ) {
		// $timestampStr = date('Y-m-d', $statement['timestamp']['sec']);
		$timestampN   = strtotime( $statement['timestamp'] );
		$timestampStr = date( 'Y-m-d', $timestampN );
		return $timestampStr;
	}

	public function getDurationStr( $statement ) {
		$durationStr = 'N/A';
		if ( isset( $statement['result']['duration'] ) ) {
			$durationRaw = $statement['result']['duration'];
			if ( isset( $durationRaw ) ) {
				$durationRaw = preg_replace( '/\.\d+/', '', $durationRaw );
				$duration    = $this->parseDuration( $durationRaw );
				$durationStr = $this->formatDuration( $duration );
			}
		}
		return $durationStr;
	}

	private function formatDuration( $duration ) {
		if ( isset( $duration['hours'] ) ) {
			$h = $duration['hours'] > 9 ? $duration['hours'] : '0' . $duration['hours'];
		} else {
			$h = '0';
		}
		if ( isset( $duration['minutes'] ) ) {
			$m = $duration['minutes'] > 9 ? $duration['minutes'] : '0' . $duration['minutes'];
		} else {
			$m = '0';
		}
		$s = $duration['seconds'] > 9 ? $duration['seconds'] : '0' . $duration['seconds'];
		return $h . ':' . $m . ':' . $s;
	}

	private function parseDuration( $str ) {
		$result = array();
		preg_match( '/^(?:P)([^T]*)(?:T)?(.*)?$/', trim( $str ), $sections );
		if ( ! empty( $sections[1] ) ) {
			preg_match_all( '/(\d+)([YMWD])/', $sections[1], $parts, PREG_SET_ORDER );
			$units = array(
				'Y' => 'years',
				'M' => 'months',
				'W' => 'weeks',
				'D' => 'days',
			);
			foreach ( $parts as $part ) {
				$result[ $units[ $part[2] ] ] = $part[1];
			}
		}
		if ( ! empty( $sections[2] ) ) {
			preg_match_all( '/(\d+)([HMS])/', $sections[2], $parts, PREG_SET_ORDER );
			$units = array(
				'H' => 'hours',
				'M' => 'minutes',
				'S' => 'seconds',
			);
			foreach ( $parts as $part ) {
				$result[ $units[ $part[2] ] ] = $part[1];
			}
		}
		return( $result );
	}

	public function getTimestampDateTimeStr( $statement ) {
		// $timestampStr = date('Y-m-d', $statement['timestamp']['sec']).' at '.date('h:i:s a', $statement['timestamp']['sec']);
		$timestampN   = strtotime( $statement['timestamp'] );
		$timestampStr = date( 'Y-m-d', $timestampN ) . ' at ' . date( 'h:i:s a', $timestampN );
		return $timestampStr;
	}

	public function getBestResultsForEachUser( $statements ) {
		$bestResults = array();
		foreach ( $statements['result'] as $r ) {
			$statement = $r['statement'];
			// $statement['timestamp'] = $r['timestamp'];
			$arr   = explode( ':', $r['statement']['actor']['mbox'] );
			$email = $arr[1];
			if ( isset( $bestResults[ $email ] ) ) {
				$bestResult = $bestResults[ $email ];
				$bestStatus = $this->getStatus( $bestResult );
				$status     = $this->getStatus( $statement );
				if ( $status > $bestStatus ) {
					$bestResults[ $email ] = $statement;
				} elseif ( $status == $bestStatus ) {
					if ( isset( $statement['result']['score']['scaled'] ) && ( $statement['result']['score']['scaled'] > $bestResult['result']['score']['scaled'] ) ) {
						$bestResults[ $email ] = $statement;
					}
				}
			} else {
				$bestResults[ $email ] = $statement;
			}
		}
		uasort( $bestResults, array( $this, 'compareTimestamps' ) );
		return $bestResults;
	}

	public function getAttemptQuestionResults( $statements, $attempt ) {
		// $timestamp = $attempt['timestamp']['sec'];
		$attempt_timestamp  = strtotime( $attempt );
		$status             = $this->getStatus( $attempt );
		$completed          = $status > 0;
		$filteredStatements = array();
		foreach ( $statements as $statement ) {
			if ( isset( $statement['timestamp'] ) ) {
				$s_timestamp = strtotime( $statement['timestamp'] );
				if ( $s_timestamp <= $attempt_timestamp || ! $completed ) {
					array_push( $filteredStatements, $statement );
				}
			}
		}
		$groupedStatements = array();
		foreach ( $filteredStatements as $statement ) {
			$id = $statement['statement']['object']['id'];
			if ( isset( $groupedStatements[ $id ] ) ) {
				$lastTimestamp    = strtotime( $groupedStatements[ $id ]['timestamp'] );
				$currentTimestamp = strtotime( $statement['timestamp'] );
				if ( $currentTimestamp > $lastTimestamp ) {
					$groupedStatements['id'] = $statement;
				}
			} else {
				$groupedStatements[ $id ] = $statement;
			}
		}
		return $groupedStatements;
	}

	private function getStatus( $statement ) {
		// 0: incomplete, 1: completed, 2: failed, 3: passed
		$status = 0;
		if ( isset( $statement['verb']['id'] ) ) {
			if ( strcmp( $statement['verb']['id'], 'http://adlnet.gov/expapi/verbs/completed' ) == 0 ) {
				$status = 1;
			} elseif ( strcmp( $statement['verb']['id'], 'http://adlnet.gov/expapi/verbs/failed' ) == 0 ) {
				$status = 2;
			} elseif ( strcmp( $statement['verb']['id'], 'http://adlnet.gov/expapi/verbs/passed' ) == 0 ) {
				$status = 3;
			}
		}
		return $status;
	}

	private function compareTimestamps( $s1, $s2 ) {
		$timestampN_1 = strtotime( $s1['timestamp'] );
		$timestampN_2 = strtotime( $s2['timestamp'] );
		if ( $timestampN_1 == $timestampN_2 ) {
			return 0;
		}
		return $timestampN_1 > $timestampN_2 ? -1 : 1;
	}
}


