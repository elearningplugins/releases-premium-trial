<?php
// shortcode handler

function articulate_iframe_handler( $attr, $content ) {

	global $quiz_load_scripts_on_frontend;
	global $quiz_iframe_responsive;
	$quiz_load_scripts_on_frontend = true;
	$quiz_iframe_responsive        = false;

	$id = 'articulate-iframe-' . uniqid();

	$colorbox_theme = '';
	$title          = '';
	$href           = '';
	$link_text      = '';
	$button_text    = '';
	$opt            = articulate_get_quiz_embeder_options();
	$cbox_themes    = articulate_quiz_embeder_get_colorbox_themes();
	$link_text      = '<br/><img src="' . articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'launch_presentation.gif" alt="Launch Presentation" /><br/>'; // a button image, will be reset if short have link_text option
	extract( $attr ); // http://php.net/manual/en/function.extract.php
	if ( isset( $button ) && '' != trim( $button ) ) {
		$link_text = '<img src="' . $button . '" alt="Launch Presentation" />';
	}
	if ( isset( $src ) ) {
		$src = articulate_quiz_embeder_relative_to_abs_url( $src );
		$src = apply_filters( 'iea/iframe/url/after', $src, $attr );
		$src = wp_make_link_relative( $src );
	}
	if ( isset( $href ) ) {
		$href = articulate_quiz_embeder_relative_to_abs_url( $href );
		$href = apply_filters( 'iea/iframe/url/after', $href, $attr );
		$href = wp_make_link_relative( $href );
	}

	if ( ! empty( $attr['button_text'] ) && empty( $attr['link_text'] ) ) {
		$use_button = true;
	} else {
		$use_button = false;
	}

		// creating content to send
	if ( $type == '' ) {
		$type = 'iframe';}
	switch ( $type ) {
		case 'iframe':
			  {
			  $return_content                = "<iframe src='$src' width='$width' height='$height' frameborder='0' scrolling='no' class='articulate-iframe'></iframe>";
			  $href                          = $src;
			  $quiz_load_scripts_on_frontend = false;
			if ( isset( $attr['show_button'] ) && $attr['show_button'] === 'yes' ) {
				if ( $use_button ) {
					$return_content .= '<br/><button type="button" class="articulate-fs" data-id="' . $id . '">' . $attr['button_text'] . '</button><br/>';
				} else {
					$return_content .= '<a href="' . $href . '" class="articulate-fs" data-id="' . $id . '">' . $link_text . '</a>';
				}
				$return_content .= "<iframe id='$id' src='$src' width='$width' height='$height' frameborder='0' scrolling='no' style='height: 0; border: 0; border: none; margin: 0 !important; position: absolute;' class='articulate-iframe'></iframe>";
			}
			  break;
		}
		case 'iframe_responsive':
		{
			if ( ! isset( $ratio ) ) {
				$ratio = '4:3'; }
			if ( ! in_array( $ratio, array( '4:3', '16:9' ) ) ) {
				$ratio = '4:3'; }
			$embed_class            = 'articulate-embed-responsive-' . str_replace( ':', 'by', $ratio );
			$html                   = '<div class="articulate-embed-responsive ' . $embed_class . '">';
			$html                  .= '<iframe id="' . $id . '" class="articulate-embed-responsive-item articulate-iframe" src="' . $src . '"  frameborder="0" scrolling="no" allowfullscreen></iframe>';
			$html                  .= '</div>';
			$return_content         = $html;
			$quiz_iframe_responsive = true;
			if ( isset( $attr['show_button'] ) && $attr['show_button'] === 'yes' ) {

				if ( $use_button ) {
					$return_content .= '<br/><button type="button" class="articulate-fs" data-id="' . $id . '">' . $attr['button_text'] . '</button><br/>';
				} else {
					$return_content .= '<a href="' . $href . '" class="articulate-fs" data-id="' . $id . '">' . $link_text . '</a>';
				}
			}
				  break;
		}
		case 'lightbox':
		{
			if ( $opt['lightbox_script'] == 'nivo_lightbox' ) {
				if ( $use_button ) {
					$return_content = '<br/><button type="button" class="nivo_lightbox_iframe" data-lightbox-type="iframe" title="' . $title . '" href="' . $href . '">' . $attr['button_text'] . '</button><br/>';
				} else {
					$return_content = '<a class="nivo_lightbox_iframe" data-lightbox-type="iframe" title="' . $title . '" href="' . $href . '">' . $link_text . '</a>';
				}
			} else {
				if ( $colorbox_theme != '' ) {
					if ( array_key_exists( $colorbox_theme, $cbox_themes ) ) {
								global $quiz_embeder_colorbox_theme;
									$quiz_embeder_colorbox_theme = $colorbox_theme;}
				}
				if ( $use_button ) {
					$return_content = '<br/><button type="button" class="colorbox_iframe" title="' . $title . '" href="' . $href . '">' . $attr['button_text'] . '</button><br/>';
				} else {
					$return_content = '<a class="colorbox_iframe" title="' . $title . '" href="' . $href . '">' . $link_text . '</a>';
				}
			}
			if ( isset( $size_opt ) ) {
				global $quiz_embeder_size_opt;
				$quiz_embeder_size_opt = $size_opt;}
			if ( isset( $width ) && isset( $height ) ) {
				global $quiz_embeder_width;
				$quiz_embeder_width = $width;
				global $quiz_embeder_height;
				$quiz_embeder_height = $height; }
			if ( isset( $scrollbar ) && $scrollbar == 'no' ) {
				global $quiz_embeder_scrollbar;
				$quiz_embeder_scrollbar = 'no';}

			break;
		}
		case 'open_link_in_new_window':
		{
			$quiz_load_scripts_on_frontend = false;
			if ( $use_button ) {
				$return_content = '<br/><button type="button" onclick=\'window.open("' . $href . '", "_blank" );\'>' . $attr['button_text'] . '</button><br/>';
			} else {
				$return_content = '<a target="_blank" href="' . $href . '">' . $link_text . '</a>';
			}
			break;
		}
		case 'open_link_in_same_window':
		{
			$quiz_load_scripts_on_frontend = false;

			if ( isset( $attr['launch_fullscreen'] ) && $attr['launch_fullscreen'] === 'yes' ) {

				if ( $use_button ) {
					$return_content = '<br/><button type="button" class="articulate-fs" data-id="' . $id . '">' . $attr['button_text'] . '</button><br/>';
				} else {
					$return_content = '<a href="' . $href . '" class="articulate-fs" data-id="' . $id . '">' . $link_text . '</a>';
				}

				$return_content .= "<iframe id='$id' src='$href' width='$width' height='0' frameborder='0' scrolling='no' style='height: 0; border: 0; border: none; margin: 0 !important; position: absolute;' class='articulate-iframe'></iframe>";
			} else {
				if ( $use_button ) {
					$return_content = '<br/><button type="button" onclick=\'window.open("' . $href . '", "_self" );\'>' . $attr['button_text'] . '</button><br/>';
				} else {
					$return_content = '<a href="' . $href . '">' . $link_text . '</a>';
				}
			}

			break;
		}

	}// end switch($type)

	// return
	return apply_filters( 'articulate_shortcode_output', $return_content );

}

add_shortcode( 'iframe_loader', 'articulate_iframe_handler' );
add_shortcode( 'cap_iframe_loader', 'articulate_iframe_handler' );
add_shortcode( 'ispring_iframe_loader', 'articulate_iframe_handler' );
