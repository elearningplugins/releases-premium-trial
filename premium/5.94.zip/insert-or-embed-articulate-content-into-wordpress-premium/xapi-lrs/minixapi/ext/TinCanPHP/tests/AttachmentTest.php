<?php
/*
	Copyright 2014 Rustici Software

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.
*/

namespace TinCanTest;

use TinCan\Attachment;
use TinCan\Version;

class AttachmentTest extends \PHPUnit_Framework_TestCase {
	use TestCompareWithSignatureTrait;

	const USAGE_TYPE     = 'http://id.tincanapi.com/attachment/supporting_media';
	const DISPLAY        = 'testDisplay';
	const DESCRIPTION    = 'Test description.';
	const FILE_URL       = 'http://tincanapi.com/tincanphp/attachment/fileUrl';
	const CONTENT_TYPE   = 'text/plain';
	const CONTENT_STR    = 'some text content';
	const CONTENT_SHA2   = 'bd1a58265d96a3d1981710dab8b1e1ed04a8d7557ea53ab0cf7b44c04fd01545';
	const CONTENT_LENGTH = 17;

	private $emptyProperties = array(
		'usageType',
		'contentType',
		'length',
		'sha2',
		'fileUrl',
	);

	private $nonEmptyProperties = array(
		'display',
		'description',
	);

	public function testInstantiation() {
		$obj = new Attachment();
		$this->assertInstanceOf( 'TinCan\Attachment', $obj );
		foreach ( $this->emptyProperties as $property ) {
			$this->assertAttributeEmpty( $property, $obj, "$property empty" );
		}
		foreach ( $this->nonEmptyProperties as $property ) {
			$this->assertAttributeNotEmpty( $property, $obj, "$property not empty" );
		}
	}

	public function testUsesArraySetterTrait() {
		$this->assertContains( 'TinCan\ArraySetterTrait', class_uses( 'TinCan\Attachment' ) );
	}

	public function testUsesFromJSONTrait() {
		$this->assertContains( 'TinCan\FromJSONTrait', class_uses( 'TinCan\Attachment' ) );
	}

	public function testUsesAsVersionTrait() {
		$this->assertContains( 'TinCan\AsVersionTrait', class_uses( 'TinCan\Attachment' ) );
	}

	public function testContent() {
		$obj = new Attachment();
		$obj->setContent( self::CONTENT_STR );

		$this->assertSame( $obj->getContent(), self::CONTENT_STR, 'content body' );
		$this->assertSame( $obj->getLength(), self::CONTENT_LENGTH, 'length' );
		$this->assertSame( $obj->getSha2(), self::CONTENT_SHA2, 'sha2' );
	}

	public function testHasContent() {
		$no_content = new Attachment();
		$this->assertFalse( $no_content->hasContent() );

		$has_content = new Attachment(
			array(
				'content' => self::CONTENT_STR,
			)
		);
		$this->assertTrue( $has_content->hasContent() );

		$set_content = new Attachment();
		$set_content->setContent( self::CONTENT_STR );
		$this->assertTrue( $set_content->hasContent() );
	}

	// TODO: need more robust test (happy-path)
	public function testAsVersion() {
		$args      = array(
			'usageType'   => self::USAGE_TYPE,
			'display'     => array( 'en-US' => self::DISPLAY ),
			'description' => array( 'en-US' => self::DESCRIPTION ),
			'contentType' => self::CONTENT_TYPE,
			'length'      => self::CONTENT_LENGTH,
			'sha2'        => self::CONTENT_SHA2,
			'fileUrl'     => self::FILE_URL,
		);
		$obj       = new Attachment( $args );
		$versioned = $obj->asVersion( Version::latest() );
		$this->assertEquals( $versioned, $args, '1.0.0' );

		$obj = new Attachment(
			array(
				'content' => self::CONTENT_STR,
			)
		);
		$this->assertEquals(
			$obj->asVersion( Version::latest() ),
			array(
				'length' => self::CONTENT_LENGTH,
				'sha2'   => self::CONTENT_SHA2,
			),
			'auto populated properties but content not returned'
		);
	}

	public function testAsVersionEmpty() {
		$args = array();

		$obj       = Attachment::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$this->assertEquals( $versioned, $args, 'serialized version matches original' );
	}

	public function testAsVersionEmptyLanguageMap() {
		$args = array( 'display' => array() );

		$obj       = Attachment::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		unset( $args['display'] );

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testCompareWithSignature() {
		$full = array(
			'usageType'   => self::USAGE_TYPE,
			'display'     => array( 'en-US' => self::DISPLAY ),
			'description' => array( 'en-US' => self::DESCRIPTION ),
			'contentType' => self::CONTENT_TYPE,
			'length'      => self::CONTENT_LENGTH,
			'sha2'        => self::CONTENT_SHA2,
			'fileUrl'     => self::FILE_URL,
		);

		$cases = array(
			array(
				'description' => 'all null',
				'objArgs'     => array(),
			),
			array(
				'description' => 'usageType',
				'objArgs'     => array( 'usageType' => self::USAGE_TYPE ),
			),
			array(
				'description' => 'display',
				'objArgs'     => array( 'display' => self::DISPLAY ),
			),
			array(
				'description' => 'description',
				'objArgs'     => array( 'description' => self::DESCRIPTION ),
			),
			array(
				'description' => 'contentType',
				'objArgs'     => array( 'contentType' => self::CONTENT_TYPE ),
			),
			array(
				'description' => 'length',
				'objArgs'     => array( 'length' => self::CONTENT_LENGTH ),
			),
			array(
				'description' => 'sha2',
				'objArgs'     => array( 'sha2' => self::CONTENT_SHA2 ),
			),
			array(
				'description' => 'fileUrl',
				'objArgs'     => array( 'fileUrl' => self::FILE_URL ),
			),
			array(
				'description' => 'all',
				'objArgs'     => $full,
			),

			//
			// display and description are language maps which we aren't
			// checking for meaningful differences, so even though they
			// differ they should not cause signature comparison to fail
			//
			array(
				'description' => 'display only with difference',
				'objArgs'     => array( 'display' => array( 'en-US' => self::DISPLAY ) ),
				'sigArgs'     => array( 'display' => array( 'en-US' => self::DISPLAY . ' invalid' ) ),
			),
			array(
				'description' => 'description only with difference',
				'objArgs'     => array( 'description' => array( 'en-US' => self::DESCRIPTION ) ),
				'sigArgs'     => array( 'description' => array( 'en-US' => self::DESCRIPTION . ' invalid' ) ),
			),

			array(
				'description' => 'usageType only: mismatch',
				'objArgs'     => array( 'usageType' => self::USAGE_TYPE ),
				'sigArgs'     => array( 'usageType' => self::USAGE_TYPE . '/invalid' ),
				'reason'      => 'Comparison of usageType failed: value is not the same',
			),
			array(
				'description' => 'contentType only: mismatch',
				'objArgs'     => array( 'contentType' => self::CONTENT_TYPE ),
				'sigArgs'     => array( 'contentType' => 'application/octet-stream' ),
				'reason'      => 'Comparison of contentType failed: value is not the same',
			),
			array(
				'description' => 'length only: mismatch',
				'objArgs'     => array( 'length' => self::CONTENT_LENGTH ),
				'sigArgs'     => array( 'length' => self::CONTENT_LENGTH + 2 ),
				'reason'      => 'Comparison of length failed: value is not the same',
			),
			array(
				'description' => 'sha2 only: mismatch',
				'objArgs'     => array( 'sha2' => self::CONTENT_SHA2 ),
				'sigArgs'     => array( 'sha2' => self::CONTENT_SHA2 . self::CONTENT_SHA2 ),
				'reason'      => 'Comparison of sha2 failed: value is not the same',
			),
			array(
				'description' => 'fileUrl only: mismatch',
				'objArgs'     => array( 'fileUrl' => self::FILE_URL ),
				'sigArgs'     => array( 'fileUrl' => self::FILE_URL . '/invalid' ),
				'reason'      => 'Comparison of fileUrl failed: value is not the same',
			),
			array(
				'description' => 'full: usageType mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'usageType' => self::USAGE_TYPE . '/invalid' ) ),
				'reason'      => 'Comparison of usageType failed: value is not the same',
			),
			array(
				'description' => 'full: contentType mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'contentType' => 'application/octet-stream' ) ),
				'reason'      => 'Comparison of contentType failed: value is not the same',
			),
			array(
				'description' => 'full: length mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'length' => self::CONTENT_LENGTH + 2 ) ),
				'reason'      => 'Comparison of length failed: value is not the same',
			),
			array(
				'description' => 'full: sha2 mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'sha2' => self::CONTENT_SHA2 . self::CONTENT_SHA2 ) ),
				'reason'      => 'Comparison of sha2 failed: value is not the same',
			),
			array(
				'description' => 'full: fileUrl mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'fileUrl' => self::FILE_URL . '/invalid' ) ),
				'reason'      => 'Comparison of fileUrl failed: value is not the same',
			),
		);
		$this->runSignatureCases( 'TinCan\Attachment', $cases );
	}
}
