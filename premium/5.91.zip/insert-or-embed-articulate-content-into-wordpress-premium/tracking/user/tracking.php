<?php


$iea_tracking_user = new iea_tracking_user();

class iea_tracking_user {

		public $user_info = array();

	public function __construct() {
		// start session
		if ( session_id() == '' ) {
			session_start(); }
		add_action( 'init', array( $this, 'setup_user_info' ) );
		add_filter( 'iea/iframe/url/after', array( $this, 'after_url' ), 10, 2 );

	}

	public function after_url( $src, $attr ) {

		if ( iea_is_tincan( $src ) == true ) {

			$user_info = $this->get_user_info();
			$actor     = rawurlencode( '{"name":["' . $user_info['name'] . '"],"mbox":["mailto:' . $user_info['email'] . '"], "objectType":"Person"}' ) . '';

			$original_url = $src;
			$src         .= '?endpoint=' . rawurlencode( ARTICULATE_PREMIUM_TRACKING_ENDPOINT ) . '';
			$src         .= '&auth=Basic ' . iea_get_tracking_api_key() . '';
			$src         .= '&actor=' . $actor;
			$src         .= '&registration=' . iea_get_uuid( $original_url ) . '';

		}
		return $src;
	}

	public function get_user_info() {
		return $this->user_info;
	}

	public function setup_user_info() {

		if ( ! empty( $this->user_info ) ) {
			session_write_close();
			return $this->user_info;
		}

		global $current_user;
		$name  = '';
		$email = '';
		if ( is_user_logged_in() ) {
			// $user =  get_userdata( $current_user->ID );
			$user  = $current_user;
			$name  = '';
			$email = '';
			if ( $user->user_firstname != '' && $user->user_lastname != '' ) {
				$name = $user->user_firstname . ' ' . $user->user_lastname;
			} elseif ( $user->user_firstname != '' ) {
				$name = $user->user_firstname;
			} elseif ( $user->user_lastname != '' ) {
				$name = $user->user_lastname;
			}
			if ( $name == '' && $user->user_nicename != '' ) {
				$name = $user->user_nicename;
			}

			$email = $user->user_email;

			if ( $name == '' && $email == '' ) {
				$name = 'Anonymous';
			}
		} else {
			$ano_user_id = '';
			$name        = 'Anonymous';
			// check session and cookie for previously generated Anonymous user
			if ( isset( $_SESSION['quiz_anonymous_user_id'] ) ) {
				$ano_user_id = $_SESSION['quiz_anonymous_user_id'];
			} elseif ( isset( $_COOKIE['quiz_anonymous_user_id'] ) ) {
				$ano_user_id = $_COOKIE['quiz_anonymous_user_id'];
			}

			if ( $ano_user_id == '' ) {
				// create new id
				$ano_user_id                        = uniqid();
				$_SESSION['quiz_anonymous_user_id'] = $ano_user_id;
				setcookie( 'quiz_anonymous_user_id', $ano_user_id, time() + ( 365 * DAY_IN_SECONDS ), COOKIEPATH, COOKIE_DOMAIN, '', true );

			}
			$domain = iea_get_current_domain();
			$name   = 'Anonymous ' . $ano_user_id;
			$email  = 'anonymous_' . $ano_user_id . '@' . $domain;

		}

		$this->user_info = array(
			'name'  => $name,
			'email' => $email,
		);
		session_write_close();
		return $this->user_info;

	}//end setup_user_info()


}
