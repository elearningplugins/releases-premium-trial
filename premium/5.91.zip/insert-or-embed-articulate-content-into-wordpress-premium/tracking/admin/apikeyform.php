<?php
class ApiKeyForm {
	function showForm() {
		echo '<link href="' . articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'css/materialize.css?v=APIKEYFORMPHPLINE4" rel="stylesheet"></link>';
		echo '<script src="' . articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'js/materialize.js?v=APIKEYFORMPHPLINE5"></script>';
		echo '<script src="' . articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'js/jshelpers.js?v=APIKEYFORMPHPLINE6"></script>';
		echo '<h2 class="header">Insert or Embed Articulate Content Into WordPress</h2>
    <form action="" method="post">
    <input type="hidden" name="iea_save" value="api_key">
        <table class="widefat"><tr><td>
        <tr>
        <td>
        <p><label><strong>API Key</strong></label> <br><input style="width:100%" type="text" name="iea-tracking-api-key" value="' . iea_get_tracking_api_key() . '" readonly ></p>
        <p class="flow-text">This key was emailed to you seperately</p>
        <p ><button class="waves-effect waves-light btn" type="submit" name="save-tracking" disabled ><i class="material-icons left">save</i>Save</button></p>

        </td></tr>

        </table>
    </form>
    ';

	}
}

