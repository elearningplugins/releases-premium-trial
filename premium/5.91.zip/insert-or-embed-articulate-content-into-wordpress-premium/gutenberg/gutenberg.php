<?php

function articulate_enqueue_gutenberg_scripts() {
	wp_enqueue_script( 'jquery' );
	wp_enqueue_script( 'materializejs', articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'js/materialize.js', array( 'jquery', 'jquery-ui-core', 'jquery-ui-tooltip' ) );
	wp_enqueue_style( 'material-icons', articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'css/materializeicons.css' );
	wp_enqueue_script( 'articulate-gutenberg-block', articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'gutenberg/build/block.js', array( 'wp-api', 'wp-i18n', 'wp-blocks', 'wp-components', 'wp-compose', 'wp-data', 'wp-editor', 'wp-element' ), filemtime( articulate_WP_QUIZ_EMBEDER_PLUGIN_DIR . '/gutenberg/build/block.js' ), true );

	wp_localize_script(
		'articulate-gutenberg-block',
		'articulateOptions',
		array(
			'options'            => articulate_get_quiz_embeder_options(),
			'ajax_url'           => admin_url( 'admin-ajax.php' ),
			'_nonce_upload_file' => wp_create_nonce( 'articulate_upload_file' ),
			'_nonce_del_dir'     => wp_create_nonce( 'articulate_del_dir' ),
			'_nonce_rename_dir'  => wp_create_nonce( 'articulate_rename_dir' ),
			'dir'                => count( articulate_getDirs() ),
			'count'              => articulate_quiz_embeder_count(),
			'plupload'           => array(
				'chunk_size'  => articulate_get_upload_chunk_size(),
				'max_retries' => 10,
			),
		)
	);

	wp_enqueue_style( 'articulate-gutenberg-block', articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'gutenberg/build/block.css' );
}

add_action( 'enqueue_block_editor_assets', 'articulate_enqueue_gutenberg_scripts' );

function articulate_register_block() {
	register_block_type(
		'e-learning/block',
		array(
			'render_callback' => 'articulate_gutenberg_block_callback',
			'attributes'      => array(
				'src'            => array(
					'type' => 'string',
				),
				'href'           => array(
					'type' => 'string',
				),
				'type'           => array(
					'type'    => 'string',
					'default' => 'iframe',
				),
				'width'          => array(
					'type'    => 'string',
					'default' => '100%',
				),
				'height'         => array(
					'type'    => 'string',
					'default' => '600',
				),
				'ratio'          => array(
					'type'    => 'string',
					'default' => '4:3',
				),
				'frameborder'    => array(
					'type'    => 'string',
					'default' => '0',
				),
				'scrolling'      => array(
					'type'    => 'string',
					'default' => 'no',
				),
				'title'          => array(
					'type' => 'string',
				),
				'link_text'      => array(
					'type' => 'string',
				),
				'button_text'    => array(
					'type' => 'string',
				),
				'button'         => array(
					'type' => 'string',
				),
				'scrollbar'      => array(
					'type' => 'string',
				),
				'colorbox_theme' => array(
					'type' => 'string',
				),
				'size_opt'       => array(
					'type' => 'string',
				),
			),
		)
	);
}

add_action( 'init', 'articulate_register_block' );

function articulate_gutenberg_block_callback( $attr ) {
	if ( ! isset( $attr['href'] ) && ! isset( $attr['src'] ) ) {
		return;
	} else {
		if ( $attr['type'] === 'iframe' || $attr['type'] === 'iframe_responsive' ) {
			unset( $attr['href'] );
		} else {
			unset( $attr['src'] );
		}

		$params = wp_parse_args( array_filter( $attr ) );

		if ( ! empty( $attr['src'] ) || ! empty( $attr['href'] ) ) {
			return articulate_iframe_handler( $params, '' );
		}
	}
}
