<?php

require_once __DIR__ . '/../../src/utils/RewriteUtil.php';

print_r( RewriteUtil::getPathComponents() );
exit;
