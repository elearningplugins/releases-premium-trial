<?php
/**
 * quiz mini xAPI LRS based on miniXapi library https://github.com/limikael/minixapi
 *
 * @author oneTarek
 */



// Check PHP version
if ( ! defined( 'PHP_VERSION_ID' ) || PHP_VERSION_ID < 50500 ) {
	trigger_error( 'Your PHP version is too old, you need at least 5.5.0, you have ' . phpversion(), E_USER_ERROR );
	return;
}

if ( ! class_exists( 'MiniXapi' ) ) {
	require_once __DIR__ . '/minixapi/MiniXapi.php';
}


require_once __DIR__ . '/helper.php';

class Quiz_Xapi_Lrs_Main {

	public $miniXapi = null; // store MiniXapi object
	public function __construct() {

		add_action( 'iea_admin_menu', array( $this, 'admin_menu' ), 20 );
		register_activation_hook( articulate_WP_QUIZ_EMBEDER_PLUGIN_DIR_FILE, array( $this, 'activate' ) );

		add_action( 'rest_api_init', array( $this, 'register_rest_api' ) );

	}

	public function activate() {

		global $wpdb;

		// Install MiniXapi if not installed yet
		$miniXapi = $this->get_MiniXapi();

		if ( ! $miniXapi->isInstalled() ) {
			$miniXapi->install();
		}

		// Generate username and password if not exists
		if ( ! get_option( 'quiz_xapilrs_username' ) ) {
			// generate a random username
			$username = bin2hex( openssl_random_pseudo_bytes( 16 ) );
			update_option( 'quiz_xapilrs_username', $username );
		}

		if ( ! get_option( 'quiz_xapilrs_password' ) ) {
			// generate a random password
			$password = bin2hex( openssl_random_pseudo_bytes( 16 ) );
			update_option( 'quiz_xapilrs_password', $password );
		}

	}

	public function get_MiniXapi() {
		if ( $this->miniXapi !== null ) {
			return $this->miniXapi;
		}

		$miniXapi = new MiniXapi();
		$miniXapi->setPdo( Quiz_Xapi_Lrs_Helper::get_compatible_pdo() );
		$miniXapi->setTablePrefix( QUIZ_LRS_TABLE_PREFIX );
		$this->miniXapi = $miniXapi;
		return $this->miniXapi;

	}

	public function admin_menu() {
	}
	public function admin_page() {

		$quiz_xapilrs_username = get_option( 'quiz_xapilrs_username' );
		$quiz_xapilrs_password = get_option( 'quiz_xapilrs_password' );

		?>
		<div class="wrap">
			<h1>Articulate xAPI Learning Record Store</h1>

			<p>
				The xAPI Learning Record Store is available at the following endpoint:
			</p>

			<table class="form-table" style="width:800px;">
				<tr>
					<td width="120"><b>Url</b></td>
					<td><?php echo articulate_WP_QUIZ_EMBEDER_LRS_ENDPOINT; ?></td>
				</tr>
				<tr>
					<td><b>Username</b></td>
					<td><?php echo $quiz_xapilrs_username; ?></td>
				</tr>
				<tr>
					<td><b>Password</b></td>
					<td><?php echo $quiz_xapilrs_password; ?></td>
				</tr>
			</table>
		</div>
		<?php
	}//end admin_page()

	public function register_rest_api() {
		register_rest_route(
			'articulate/v1',
			'/lrs/(?P<id>.+)',
			array(
				'methods'             => array( 'GET', 'POST', 'PUT' ),
				'callback'            => array( $this, 'rest_callback' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	public function rest_callback( $data ) {

		// we need to change the $_SERVER['REQUEST_URI'] value because
		// RewriteUtil::getPathComponents() retrieve path information from REQUEST_URI
		$server_request_uri_backup = $_SERVER['REQUEST_URI'];
		$parts                     = explode( '/lrs', $_SERVER['REQUEST_URI'] );
		$_SERVER['REQUEST_URI']    = $parts[1];
		require_once articulate_WP_QUIZ_EMBEDER_PLUGIN_DIR . '/xapi-lrs/endpoint.php';

	}
}//end class
global $quiz_xapi_lrs_main_obj;
$quiz_xapi_lrs_main_obj = new Quiz_Xapi_Lrs_Main();
