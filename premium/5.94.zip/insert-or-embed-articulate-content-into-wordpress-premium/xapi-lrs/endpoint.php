<?php
/**
 * quiz xapi lrs endpoint
 *
 * @author oneTarek
 * NOTE : This file will be called from outside of WordPress by http request.
 * Do not apply wp translation in this file.
 **/

require_once __DIR__ . '/helper.php';


if ( ! defined( 'ABSPATH' ) ) {
	// Load WordPress
	$wp_load_file_path = Quiz_Xapi_Lrs_Helper::wp_load_file_path();
	if ( $wp_load_file_path ) {
		require_once $wp_load_file_path;
	} else {
		throw new \Exception( 'No WordPress installation found.' );
		exit;
	}
}

if ( ! class_exists( 'MiniXapi' ) ) {
	require_once __DIR__ . '/minixapi/MiniXapi.php';
}


// Remove magic quotes, WordPress always adds these.
// http://stackoverflow.com/questions/8949768/with-magic-quotes-disabled-why-does-php-wordpress-continue-to-auto-escape-my
// https://core.trac.wordpress.org/ticket/18322
foreach ( $_REQUEST as $key => $val ) {
	$_REQUEST[ $key ] = stripslashes( $val );
}

$quiz_xapilrs_username = get_option( 'quiz_xapilrs_username' );
$quiz_xapilrs_password = get_option( 'quiz_xapilrs_password' );

$miniXapi = new MiniXapi();
$miniXapi->setPdo( Quiz_Xapi_Lrs_Helper::get_compatible_pdo() );
$miniXapi->setTablePrefix( QUIZ_LRS_TABLE_PREFIX );

if ( $data->get_method() != 'GET' ) {
	$miniXapi->setBasicAuth( $quiz_xapilrs_username . ':' . $quiz_xapilrs_password );
}

$miniXapi->serve();
