<?php
$report = '';


class TrackingReportScore {

	public function showReport() {
		global $wpdb;
		error_reporting( error_reporting() & ~E_NOTICE );
		?>

		<h2 class="header">Reports</h2>
		<?php
		$courses         = $this->courses_names();
		$apiDataProvider = new ApiDataProvider();
		$result_arr      = $apiDataProvider->getUniquieStatementDefinitionNameUnds();
		$page            = $_GET['page'];
		$report          = $_GET['report'];

		$show_incomplete = ( isset( $_GET['show_incomplete'] ) && $_GET['show_incomplete'] == 1 );

		// get courses list from database courses table instead of statements
		$qs = "SELECT uuid, course_name, active FROM {$wpdb->prefix}quiz_lrs_courses";

		// $results_status_tbl = $wpdb->get_results( $query2, OBJECT );
		$results_courses = $wpdb->get_results( $qs, ARRAY_A );

		$export_url = '';

		$per_page = 25;
		$count    = 0;

		// Store date range in a variable.
		$date_range = 'all_time';
		if ( isset( $_GET['report_date'] ) && $_GET['report_date'] != '' ) {
			$date_range = esc_attr( $_GET['report_date'] );
		}

		// Get since/until.
		$date_since = isset( $_GET['date_since'] ) ? esc_attr( $_GET['date_since'] ) : '';
		$date_until = isset( $_GET['date_until'] ) ? esc_attr( $_GET['date_until'] ) : '';

		$course = isset( $_GET['course'] ) ? $_GET['course'] : '';
		if ( ! empty( $course ) ) {

			$query2              = "SELECT uuid, id, course_name FROM {$wpdb->prefix}quiz_lrs_courses WHERE uuid = '$course'";
			$results_status_data = $wpdb->get_results( $query2, ARRAY_A );

			$course_id   = $results_status_data[0]['id'];
			$course_data = $results_status_data[0];
			$uuid        = $course;

			// Prepare date query.
			$date_query = '';
			if ( $date_range === 'today' ) {
				$date_query .= ' AND date(st_timestamp) = CURDATE()';
			}

			if ( $date_range === 'yesterday' ) {
				$date_query .= ' AND date(st_timestamp) = CURDATE() - 1';
			}

			if ( $date_range === 'this_month' ) {
				$date_query .= ' AND MONTH(st_timestamp) = MONTH(CURRENT_DATE())';
			}

			if ( $date_range === 'last_month' ) {
				$date_query .= ' AND YEAR(st_timestamp) = YEAR(CURRENT_DATE - INTERVAL 1 MONTH)
								AND MONTH(st_timestamp) = MONTH(CURRENT_DATE - INTERVAL 1 MONTH)';
			}

			if ( $date_range === 'last_7' ) {
				$date_query .= ' AND date(st_timestamp) BETWEEN CURDATE() - INTERVAL 7 DAY AND CURDATE()';
			}

			if ( $date_range === 'last_30' ) {
				$date_query .= ' AND date(st_timestamp) BETWEEN CURDATE() - INTERVAL 30 DAY AND CURDATE()';
			}

			if ( $date_range === 'custom' && ( $date_since || $date_until ) ) {
				if ( $date_since && $date_until ) {
					$date_query .= " AND date(st_timestamp) BETWEEN '$date_since' AND '$date_until'";
				} elseif ( $date_since && ! $date_until ) {
					$date_query .= " AND date(st_timestamp) >= '$date_since'";
				} elseif ( ! $date_since && $date_until ) {
					$date_query .= " AND date(st_timestamp) <= '$date_until'";
				}
			}

			$query2             = "SELECT * FROM {$wpdb->prefix}quiz_lrs_status WHERE id_course_fk = '$course_id'" . $date_query;
			$results_status_tbl = $wpdb->get_results( $query2, OBJECT );

			$query3              = "SELECT * FROM ( SELECT * FROM {$wpdb->prefix}quiz_lrs_statements_expand WHERE context_registration = '$uuid' " . $date_query . " AND verb_display = 'attempted' AND actor_mbox NOT IN ( SELECT pd.actor_mbox FROM {$wpdb->prefix}quiz_lrs_status pd WHERE context_registration = '$uuid' ) ORDER BY st_timestamp DESC LIMIT 18446744073709551615 ) AS sub GROUP BY sub.actor_mbox";
			$results_status_tbl2 = $show_incomplete ? $wpdb->get_results( $query3, OBJECT ) : array();

			$count = count( $results_status_tbl ) + count( $results_status_tbl2 );

			$safe_uuid = htmlspecialchars( $uuid );

			if ( ! empty( $results_status_tbl ) || ! empty( $results_status_tbl2 ) ) {
				$export_url = add_query_arg( 'action', 'articulate_download_csv' );
				$export_url = add_query_arg( '_wpnonce', wp_create_nonce( 'articulate_download_csv' ), $export_url );
				$export_url = remove_query_arg( 'show_incomplete', $export_url );
			}

			$numelem = 0;
			$results = array();
			foreach ( $results_status_tbl as $key => $stmnt ) {
				$userdata            = get_user_by( 'email', str_replace( 'mailto:', '', $stmnt->actor_mbox ) );
				$numelem            += 1;
				$results[ $numelem ] = array(
					'user_name'   => $this->get_user_name( $userdata ),
					'actor_mbox'  => $stmnt->actor_mbox,
					'user'        => str_replace( 'mailto:', '', $stmnt->actor_mbox ),
					'status'      => $stmnt->status,
					'timestamp'   => $stmnt->st_timestamp,
					'status_html' => ucfirst( $stmnt->status ),
					'score'       => $stmnt->score,
					'score_plain' => $stmnt->score,
					'course_name' => $course_data['course_name'],
				);
			}

			if ( $show_incomplete ) {
				foreach ( $results_status_tbl2 as $key => $stmnt ) {
					$userdata            = get_user_by( 'email', str_replace( 'mailto:', '', $stmnt->actor_mbox ) );
					$numelem            += 1;
					$results[ $numelem ] = array(
						'user_name'   => $this->get_user_name( $userdata ),
						'actor_mbox'  => $stmnt->actor_mbox,
						'user'        => str_replace( 'mailto:', '', $stmnt->actor_mbox ),
						'status'      => 'incomplete',
						'timestamp'   => $stmnt->st_timestamp,
						'status_html' => 'Incomplete',
						'score'       => 'N/A',
						'score_plain' => -1,
						'course_name' => $stmnt->course_name,
					);
				}
			}

			if ( ! empty( $results ) ) {
				array_multisort(
					array_map( 'strtotime', array_column( $results, 'timestamp' ) ),
					SORT_DESC,
					$results
				);
			}
		}
		?>
		<form id='report_form' action='' name='report_form' method='get' style="margin:0 24px 0 0;">
			<select id='report_select' name='course' class="materialize_me">
					  <option value="" disabled selected>Select a content item (deleted courses are no longer active in the system)</option>
			  <?php

				foreach ( $results_courses as $key => $row ) {
					if ( $row['active'] == 0 ) {
						$course_active = '(deleted)';
					}
					if ( $row['active'] == 1 ) {
						$course_active = '(active)';
					}
					echo "<option value='" . $row['uuid'] . "'" . selected( $row['uuid'], $course, false ) . '>' . $row['course_name'] . ' ' . $course_active . '</option>';
				}
				?>
			</select>
			<select id='report_date' name='report_date' class="materialize_me">
				<option value="all_time" <?php selected( 'all_time', $date_range ); ?>>Date range: all time</option>
				<option value="today" <?php selected( 'today', $date_range ); ?>>Date range: today</option>
				<option value="yesterday" <?php selected( 'yesterday', $date_range ); ?>>Date range: yesterday</option>
				<option value="last_7" <?php selected( 'last_7', $date_range ); ?>>Date range: last 7 days</option>
				<option value="this_month" <?php selected( 'this_month', $date_range ); ?>>Date range: this month</option>
				<option value="last_month" <?php selected( 'last_month', $date_range ); ?>>Date range: last month</option>
				<option value="last_30" <?php selected( 'last_30', $date_range ); ?>>Date range: last 30 days</option>
				<option value="custom" <?php selected( 'custom', $date_range ); ?>>Date range: custom</option>
			</select>
			<div class="articulate_cb double articulate_cb_date articulate_cb-hidden">
				<div><label>Since</label><input id="date_since" name="date_since" type="date" class="datepickerz" value="<?php echo $date_since; ?>" ></div>
				<div><label>Until</label><input id="date_until" name="date_until" type="date" class="datepickerz" value="<?php echo $date_until; ?>" ></div>
			</div>
			<div class="articulate_cb">
				  <input type="checkbox" class="filled-in" id="show_incompletions" name="show_incomplete" value="1" <?php checked( 1, $show_incomplete ); ?>>
				  <label for="show_incompletions">Show incompletions</label>
			</div>
			<button type='submit' name='run_report' class="waves-effect waves-light btn">Run Report</button>
			<?php if ( $export_url ) { ?>
			<a href="<?php echo $export_url; ?>" class="waves-effect waves-light btn export-report" style="margin-left:8px">Export Report</a>
			<?php } ?>
			<input type="hidden" name="page" value="<?php echo $page; ?>" />
			<input type="hidden" name="report" value="<?php echo $report; ?>" />
		</form>

		<?php if ( ! empty( $course ) ) { ?>

		<div class="row">
		  <div id="admin" class="col s12">
			<div class="card material-table articulate-table">
			  <div class="table-header">
				<!-- hide safeid 
				<span class="table-title"><?php echo '<h3 class="header">' . $course_data['course_name'] . ' (' . $safe_uuid . ')' . '</h3>'; ?></span> -->
				<span class="table-title"><?php echo '<h3 class="header">' . $course_data['course_name'] . '</h3>'; ?></span>
				<div class="actions">
				  <a href="#" class="search-toggle waves-effect btn-flat nopadding"><i class="material-icons">search</i></a>
				</div>
			  </div>
					<div class="articulate-progress">
					<?php echo '<img src="' . articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'css/loading.gif" alt="" width="24" height="24" />'; ?>
					Loading reports...
				</div>
			  <table id="datatable" class="tblScore" data-per-page="<?php echo $per_page; ?>" style="display: none;">
				<thead>
				  <tr>
					<th>User</th>
					<th>Score</th>
					<th>Status</th>
					<th>Date</th>
					<th class="unsortable">Action</th>
				  </tr>
				</thead>
				<tbody>
				<?php
				foreach ( $results as $key => $result ) {
					$key = $key + 1;
					?>
				  <tr data-user-email='<?php echo $result['user']; ?>' data-attempted="<?php echo $result['status'] == 'incomplete' ? 'yes' : 'no'; ?>">
					<td class='actor'><?php echo $result['user_name'] . '<br/>(' . $result['user'] . ')'; ?></td>
					<td class='score' data-order="<?php echo $result['score_plain']; ?>"><?php echo $result['score']; ?></td>
					<td class='status'><?php echo $result['status_html']; ?></td></td>
					<td class='date'><?php echo date( 'Y-m-d h:ia', strtotime( $result['timestamp'] ) ); ?></td>
					<td class='delete'><?php echo $this->delete_button( $result['course_name'], $result['user'], $safe_uuid, $result['user_name'] ); ?></td>
				  </tr>
				<?php } ?>
				</tbody>
			  </table>
			</div>
		  </div>
		</div>
			<?php if ( $count && $numelem > $per_page ) { ?>
		<button id="showMoreReports" class="waves-light btn normalfont hide-button" style="display: inline-block;">More...</button>
				<?php
			}
		}
	}

	/**
	 * Get user name.
	 */
	public function get_user_name( $userdata ) {
		$user_name = '';
		if ( isset( $userdata->user_firstname ) && $userdata->user_firstname != '' && $userdata->user_lastname != '' ) {
			$user_name = $userdata->user_firstname . ' ' . $userdata->user_lastname;
		} elseif ( isset( $userdata->user_firstname ) && $userdata->user_firstname != '' ) {
			$user_name = $userdata->user_firstname;
		} elseif ( isset( $userdata->user_lastname ) && $userdata->user_lastname != '' ) {
			$user_name = $userdata->user_lastname;
		}
		if ( $user_name == '' && isset( $userdata->display_name ) && $userdata->display_name != '' ) {
			$user_name = $userdata->display_name;
		}
		if ( $user_name == '' ) {
			$user_name = 'Anonymous';
		}
		return $user_name;
	}

	public function initScoreLinks() {

		?>
	   <script>
		   jQuery(function () {			   
			   //todo it now sends the course uuid instead of the name
			   var baseUrl = window.location.href.replace('report=score', 'report=answers');
			   var $ = jQuery;
			   var rows = $('.tblScore tr');
			   var txtUser = $('#txtUser');
	   
			   for (var i = 1; i < rows.length; i++) {
				   var row = $(rows[i]);				   
				   var email = row[0].dataset.userEmail;
				   email = encodeURIComponent(email);
				   var attempted = row[0].dataset.attempted;
				   var column = $('.score', row);				   
				   var url = baseUrl + '&user=' + email + '&attempted=' + attempted;
				   console.log(url);
				   var link = $('<a/>').attr('href', url).html(column.html());
				   column.html('').append(link);
			   }
		   });
		   
		   //modal 
			jQuery(document).ready(function($){
				
				$('.tr_agree').click(function(e){
					e.preventDefault();
					var form_id = $( this ).parents( '.modal' ).attr( 'id' );
					console.log('clicked on agree for form ' + form_id );
					$( '.' + form_id ).submit();
				});
				
				$('.tr_disagree').click(function(e){
					e.preventDefault();
					
					var form_id = $( this ).parents( '.modal' ).attr( 'id' );
					console.log('clicked on disagree for form ' + form_id );
				});
			  });
			  
			 document.addEventListener('DOMContentLoaded', function() {
				var elems = document.querySelectorAll('.modal');
				var instances = M.Modal.init(elems, '');
			  });
	   </script>
		<?php
	}
	private function delete_button( $coursename, $user, $uuid, $username ) {

		$page   = $_GET['page'];
		$report = $_GET['report'];
		$course = $_GET['course'];
		$string = $user . $coursename . $uuid . $username;
		?>
		<!-- modal triger btn -->
		
		 <button type='submit' name='delete_submit' value='1' class="waves-effect waves-light btn modal-trigger" data-target="form-<?php echo md5( $string ); ?>" >Delete</button>

		 <form  action='' name='delete_form' method='get' class="form-<?php echo md5( $string ); ?>">
			<input type="hidden" name="delete_submit" value="1" />
			<input type="hidden" name="del_course" value="<?php echo $coursename; ?>" />
			<input type="hidden" name="del_uuid" value="<?php echo $uuid; ?>" />
			<input type="hidden" name="del_user" value="<?php echo $user; ?>" />
			<input type="hidden" name="del_username" value="<?php echo $username; ?>" />
			<input type="hidden" name="page" value="<?php echo $page; ?>" />
			<input type="hidden" name="page" value="<?php echo $page; ?>" />
			<input type="hidden" name="report" value="<?php echo $report; ?>" />
			<input type="hidden" name="course" value="<?php echo $course; ?>" />
			<input type="hidden" name="run_report" value="" />
			</form>
		
		<!--modal -->
		<div id="form-<?php echo md5( $string ); ?>" class="modal">
			<div class="modal-content">
			  <h4 style='color:#000;'>Delete</h4>
			  <p style='color:#000;'>Are you sure?</p>
			</div>
			<div class="modal-footer">
			<a href="" class="modal-close waves-effect waves-green btn-flat tr_agree">Agree</a>
			  <a href="" class="modal-close waves-effect waves-red btn-flat tr_disagree">Disagree</a>
			  
			</div>
		  </div>
		
		
		<?php
	}

	public function delete_action() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( isset( $_REQUEST['delete_submit'] ) ) {
			global $wpdb;

			 $del_user     = $_REQUEST['del_user'];
			 $del_course   = $_REQUEST['del_course'];
			 $del_uuid     = $_REQUEST['del_uuid'];
			 $del_username = $_REQUEST['del_username'];

			$wpdb->delete(
				$wpdb->prefix . 'quiz_lrs_status',
				array(
					'uuid'       => $del_uuid,
					// 'user_name' => $del_username,
					'actor_mbox' => 'mailto:' . $del_user,
				)
			);

			// select all statement id from expand table

			$query              = "SELECT * FROM {$wpdb->prefix}quiz_lrs_statements_expand WHERE actor_mbox = 'mailto:$del_user' and context_registration ='$del_uuid'";
			$results_expand_tbl = $wpdb->get_results( $query, OBJECT );

			foreach ( $results_expand_tbl as $key => $stmnt ) {
				$statementId = $stmnt->statementId;
				$context     = $stmnt->context_registration;
				$course_name = $stmnt->object_definition_name_und;
				$actor_mbox  = $stmnt->actor_mbox;

				// delete from statements table  statementId
				$wpdb->delete( $wpdb->prefix . 'quiz_lrs_statements', array( 'statementId' => $statementId ) );
				// delete from index table
				$wpdb->delete( $wpdb->prefix . 'quiz_lrs_statements_index', array( 'statementId' => $statementId ) );
				// delete from expand  table  ,note: few row still remains in this table
				$wpdb->delete( $wpdb->prefix . 'quiz_lrs_statements_expand', array( 'statementId' => $statementId ) );
				// delete from lrs_states table  using context
				$wpdb->delete( $wpdb->prefix . 'quiz_lrs_states', array( 'context_registration' => $context ) );

				// get all statements from statement table
				$query2                 = "SELECT * FROM {$wpdb->prefix}quiz_lrs_statements WHERE statement LIKE '%$context%'";
				$results_statements_tbl = $wpdb->get_results( $query2, OBJECT );

				$i = 0;
				// delete from statement table
				foreach ( $results_statements_tbl as $key2 => $stmnt2 ) {

					$stmt_id = $stmnt2->statementId;

					$stmt               = $stmnt2->statement;
					$data               = json_decode( $stmt );
					$current_actor_mbox = $data->actor->mbox;
					$current_context    = $data->context->registration;

					// match mail , context and corse name

					if ( $actor_mbox == $current_actor_mbox && $context == $current_context ) {
						// then delete statement

						$wpdb->delete( $wpdb->prefix . 'quiz_lrs_statements', array( 'statementId' => $stmt_id ) );
						// also from index
						$wpdb->delete( $wpdb->prefix . 'quiz_lrs_statements_index', array( 'statementId' => $stmt_id ) );
					}

					$i++;
				}
			}
			exit( wp_redirect( admin_url( 'admin.php?course=' . $del_uuid . '&page=articulate-settings-tracking&report=score' ) ) );
		}//eof delete submit

	}
	private function delete_message() {
		$message = '<span style="color:red;">Statement Deleted successfully.</span>';
		return $message;
	}
	private function courses_names() {
		$n = array();
		// get all xml file folder
		$upload_dir = wp_upload_dir();
		$dir        = '' . $upload_dir['basedir'] . '/articulate_uploads';

		$i = 0;
		foreach ( new DirectoryIterator( $dir ) as $fileInfo ) {
			if ( ! $fileInfo->isDot() ) {
				// echo '<li>' . $fileInfo->getFilename();
				if ( $fileInfo->isDir() ) {

					$folder_name = $fileInfo->getFilename();
					$course_dir  = $dir . DIRECTORY_SEPARATOR . $folder_name;

					$xml_path = $course_dir . DIRECTORY_SEPARATOR . 'tincan.xml';
					// check for file
					$filename = '/path/to/foo.txt';

					$name = '';
					if ( file_exists( $xml_path ) ) {
						$xml_string = file_get_contents( $xml_path );
						$xml        = simplexml_load_string( $xml_string );
						$json       = json_encode( $xml );
						$xml_array  = json_decode( $json, true );

						if ( isset( $xml_array['activities']['activity']['name'] ) ) {
							$name = $xml_array['activities']['activity']['name'];
						}

						if ( isset( $xml_array['activities']['activity'][0]['name'] ) ) {
							$name = $xml_array['activities']['activity'][0]['name'];
						}
					}

					// get uuid
					$uuid_path = $course_dir . DIRECTORY_SEPARATOR . 'uuid.txt';
					if ( file_exists( $xml_path ) ) {
						$uuid = file_get_contents( $uuid_path );
					}

					// add to array only if there is name
					if ( ! empty( $name ) ) {
						$n[ $i ]['name']       = $name;
						$n[ $i ]['course_dir'] = $course_dir;
						$n[ $i ]['uuid']       = $uuid;

						// update expand table
						$this->update_names( $uuid, $name );

						$i++;
					}
				}
			}
		}
		return $n;
	}
	/**
	 * update name for rise course zip
	 */
	private function update_names( $uuid, $name ) {
		 global $wpdb;
					 $table_name = $wpdb->prefix . 'quiz_lrs_statements_expand';

					$wpdb->update(
						$table_name,
						array(
							'course_name'                => $name,
							'object_definition_name_und' => $name,
						),
						array(
							'context_registration' => $uuid,
							'verb_display'         => 'attempted',
						)
					);
	}
}
?>
