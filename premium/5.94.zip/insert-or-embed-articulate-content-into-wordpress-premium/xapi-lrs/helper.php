<?php
/**
 * Helper class for quiz xapi lrs
 *
 * @author oneTarek
 * NOTE : do not apply wp translation in this file.
 **/

if ( ! class_exists( 'Quiz_Xapi_Lrs_Helper' ) ) :

	class Quiz_Xapi_Lrs_Helper {

		/**
		 * Search return the path of wp-load.php file.
		 */
		public static function wp_load_file_path() {

			if ( php_sapi_name() == 'cli' ) {
				$path = $_SERVER['PWD'];
			} else {
				$path = $_SERVER['SCRIPT_FILENAME'];
			}

			while ( true ) {
				if ( file_exists( $path . '/wp-load.php' ) ) {
					return $path . '/wp-load.php';
				}

				$last = $path;
				$path = dirname( $path );

				if ( $last == $path ) {
					return false;
				}
			}
		}

		/**
		 * Create a PDO object that is compatible with the current. http://php.net/manual/en/book.pdo.php
		 * Call this function if WordPress is loaded
		 *
		 * @retrun PDO object
		 */
		public static function get_compatible_pdo() {

			static $pdo;

			if ( ! $pdo ) {
				$pdo = new PDO( 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME, DB_USER, DB_PASSWORD );
				$pdo->setAttribute( PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true );
			}

			return $pdo;
		}


	}//end class

endif;
