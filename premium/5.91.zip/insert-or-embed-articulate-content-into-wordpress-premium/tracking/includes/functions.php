<?php

// general functions

function iea_is_tincan( $url ) {
	if ( $url != '' ) {
		$url  = str_replace( 'story.html', '', $url );
		$url  = str_replace( 'index.html', '', $url );
		$path = iea_get_path_from_url( $url );
		return iea_check_tincan_file( $path );

	}
	return false;

}

// recursive function
function iea_check_tincan_file( $dir ) {

	if ( $dir == '' ) {
		return false; }
	$dir         = untrailingslashit( $dir );
	$upload_path = untrailingslashit( articulate_getUploadsPath() );
	if ( $upload_path == $dir ) {
		return false;
	}
	if ( file_exists( $dir . '/tincan.xml' ) ) {
		return true;
	} else {
		// check parent dir
		return iea_check_tincan_file( dirname( $dir ) );
	}

}

// recursive function
function iea_search_uuid_file( $dir ) {

	if ( $dir == '' ) {
		return ''; }
	$dir         = untrailingslashit( $dir );
	$upload_path = untrailingslashit( articulate_getUploadsPath() );
	if ( $upload_path == $dir ) {
		return '';
	}
	if ( file_exists( $dir . '/uuid.txt' ) ) {
		return $dir . '/uuid.txt';
	} else {
		// check parent dir
		return iea_search_uuid_file( dirname( $dir ) );
	}

}


function iea_get_uuid( $url ) {
	$body = '';
	$url  = str_replace( 'story.html', '', $url );
	$url  = str_replace( 'index.html', '', $url );

	$path      = iea_get_path_from_url( $url );
	$uuid_path = iea_search_uuid_file( $path );
	if ( $uuid_path != '' ) {
		$body = file_get_contents( $uuid_path );
	} else {
		$body = iea_generate_uuid();
		file_put_contents( $path . '/uuid.txt', $body );

	}

	return $body;
}

function iea_generate_uuid() {

	$uuid = UUID::v4();

	return $uuid;
}

function iea_get_tracking_api_key() {

	static $api_key;
	if ( isset( $api_key ) ) {
		return $api_key;
	}

	$quiz_xapilrs_username = get_option( 'quiz_xapilrs_username' );
	$quiz_xapilrs_password = get_option( 'quiz_xapilrs_password' );
	if ( $quiz_xapilrs_username != '' && $quiz_xapilrs_password != '' ) {
		$api_key = base64_encode( $quiz_xapilrs_username . ':' . $quiz_xapilrs_password );
	} else {
		$api_key = '';
	}

	return $api_key;

}

function iea_get_path_from_url( $url ) {
	$url         = untrailingslashit( $url );
	$upload_url  = trailingslashit( articulate_getUploadsUrl( true ) );
	$upload_path = articulate_getUploadsPath();
	$rel         = str_replace( $upload_url, '', $url );
	$path        = $upload_path . $rel;
	return $path;
}

function iea_get_current_domain() {
	$url  = untrailingslashit( get_bloginfo( 'url' ) );
	$url  = str_replace( 'http://', '', $url );
	$url  = str_replace( 'https://', '', $url );
	$part = explode( '/', $url );
	return $part[0];
}
