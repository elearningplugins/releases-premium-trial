<?php
/*
we need some settings in this seperate file because, our locker.php need some settings without whole WordPress loading.
and this same settings is being used in whole WordPress

we  need articulate_WP_UPLOADS_DIR_NAME because WordPress uploades directory may be different in some case,
we need this to decleard here becaue locker.php will be called without WordPress.
*/
define( 'articulate_WP_CONTENT_DIR_NAME', 'wp-content' ); // CHANGE THIS IF YOUR content directory is defferent.
define( 'articulate_WP_UPLOADS_DIR_NAME', 'uploads' );
define( 'articulate_UPLOADS_DIR_NAME', 'articulate_uploads' );
define( 'articulate_CAPABILITY', 'edit_posts' );
