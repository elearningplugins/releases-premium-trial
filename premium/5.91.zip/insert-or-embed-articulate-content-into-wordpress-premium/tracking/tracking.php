<?php

// supporting classes
require_once dirname( __FILE__ ) . '/classes/uuid.php';

// local functions
require_once dirname( __FILE__ ) . '/includes/functions.php';

define( 'ARTICULATE_PREMIUM_VER_TRACKING', '1.0.0' );
// define("ARTICULATE_PREMIUM_TRACKING_ADMIN", 'https://www.xapiwp.com/');
define( 'ARTICULATE_PREMIUM_TRACKING_ADMIN', articulate_WP_QUIZ_EMBEDER_LRS_ENDPOINT );
// define("ARTICULATE_PREMIUM_TRACKING_ENDPOINT", 'https://www.elearningfreak.com/sandbox/wp-content/plugins/wp-xapi-lrs/endpoint.php');
// define("ARTICULATE_PREMIUM_TRACKING_ENDPOINT", 'http://localhost/wordpress/wp-content/plugins/wp-xapi-lrs/endpoint.php');
define( 'ARTICULATE_PREMIUM_TRACKING_ENDPOINT', articulate_WP_QUIZ_EMBEDER_LRS_ENDPOINT );
define( 'ARTICULATE_PREMIUM_TRACKING_PLUGIN_URL', plugins_url( '', __FILE__ ) );

// plugin classes
require_once dirname( __FILE__ ) . '/classes/ApiDataProvider.php';
require_once dirname( __FILE__ ) . '/classes/StatementsHelper.php';
require_once dirname( __FILE__ ) . '/admin/tracking.php';
require_once dirname( __FILE__ ) . '/admin/upload.php';
require_once dirname( __FILE__ ) . '/user/tracking.php';
