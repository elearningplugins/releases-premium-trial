<?php

// Don't allow direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

if ( ! class_exists( 'QuizScriptLoader' ) ) {

	class QuizScriptLoader {

		public $var = '5.7.8';
		public $opt; // plugin options
		public $size_opt;
		public $scrollbar = '';
		public $width     = '';
		public $height    = '';
		public $colorbox_theme;

		public function __construct() {
			add_action( 'wp_footer', array( $this, 'site_footer' ), -1 );

		}

		public function setup_vars() {
			$this->opt = articulate_get_quiz_embeder_options();
			global $quiz_embeder_size_opt;
			global $quiz_embeder_width;
			global $quiz_embeder_height;
			global $quiz_embeder_scrollbar;
			global $quiz_embeder_colorbox_theme;

			if ( isset( $quiz_embeder_size_opt ) ) {
				$this->size_opt = $quiz_embeder_size_opt;
			}

			if ( isset( $quiz_embeder_scrollbar ) ) {
				$this->scrollbar = $quiz_embeder_scrollbar;
			}

			if ( isset( $quiz_embeder_colorbox_theme ) ) {
				$this->colorbox_theme = $quiz_embeder_colorbox_theme;
			}

			if ( isset( $this->size_opt ) && $this->size_opt == 'custom_form_dashboard' ) {
				$this->width  = $this->opt['width'] . $this->opt['width_type'];
				$this->height = $this->opt['height'] . $this->opt['height_type'];
			}

			if ( $this->opt['lightbox_script'] != 'nivo_lightbox' ) {

				if ( ! isset( $this->colorbox_theme ) || $this->colorbox_theme == '' ) {
					$this->colorbox_theme = $this->opt['colorbox_theme'];
				}

				if ( $this->size_opt != 'custom_form_dashboard' && $this->size_opt != 'custom' ) {
					// default
					$this->width  = '80%';
					$this->height = '80%';
				}
			}

		}

		public function site_footer() {
			global $quiz_load_scripts_on_frontend;
			/*
			 * If the decision of loading script is false and current page is NOT DIVI visual builder,
			 * no need to load scripts.
			 */
			if ( ! $quiz_load_scripts_on_frontend && ! ( isset( $_GET['et_fb'] ) && $_GET['et_fb'] == 1 ) ) {
				return;
			}

			$this->setup_vars();

			wp_enqueue_script( 'jquery' );
			$script_handler = '';
			$style_handler  = '';
			if ( $this->opt['lightbox_script'] == 'nivo_lightbox' ) {
				// enqueue nivo litebox related scripts and styles
				wp_enqueue_style( 'quiz_nivo_lightbox_css', articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'nivo-lightbox/nivo-lightbox.css', array(), $this->var );
				$style_handler = 'quiz_nivo_lightbox_theme_css';
				wp_enqueue_style( $style_handler, articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'nivo-lightbox/themes/default/default.css', array(), $this->var );

				if ( $this->size_opt != 'lightebox_default' ) {
					wp_add_inline_style( $style_handler, $this->lightebox_default_extra_css() );
				}

				$script_handler = 'quiz_nivo_lightbox_script';
				wp_enqueue_script( $script_handler, articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'nivo-lightbox/nivo-lightbox.min.js', array( 'jquery' ), $this->var );

			} else {
				// enqueue colorbox related scripts and styels
				$style_handler  = 'quiz_nivo_colorbox_css';
				$script_handler = 'quiz_nivo_colorbox_script';
				wp_enqueue_style( $style_handler, articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'colorbox/themes/' . $this->colorbox_theme . '/colorbox.css', array(), $this->var );
				wp_enqueue_script( $script_handler, articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'colorbox/jquery.colorbox-min.js', array( 'jquery' ), $this->var );

			}

			// enqueue quiz global CSS
			wp_add_inline_style( $style_handler, $this->inline_style() );
			wp_add_inline_script( $script_handler, $this->inline_script() );

		}//end site_footer()

		public function lightebox_default_extra_css() {
			ob_start();
			?>
			
			.nivo-lightbox-content{
				width: <?php echo $this->width; ?>;
				height: <?php echo $this->height; ?>;
				margin:auto;
			}
			<?php
			if ( isset( $this->scrollbar ) && $this->scrollbar == 'no' ) {
				?>
			.nivo-lightbox-content iframe{
				width: <?php echo $this->width; ?>;
				height: <?php echo $this->height; ?>;
				overflow:hidden;
			}
			<?php } ?>
			
			<?php
			return ob_get_clean();
		}

		public function inline_style() {
			ob_start();
			?>
			/* embed responsive CSS from bootstrap */
			.articulate-embed-responsive {
			  position: relative;
			  display: block;
			  width: 100%;
			  padding: 0;
			  overflow: hidden;
			}

			.articulate-embed-responsive::before {
			  display: block;
			  content: "";
			}

			.articulate-embed-responsive .articulate-embed-responsive-item,
			.articulate-embed-responsive iframe,
			.articulate-embed-responsive embed,
			.articulate-embed-responsive object,
			.articulate-embed-responsive video {
			  position: absolute;
			  top: 0;
			  bottom: 0;
			  left: 0;
			  width: 99.9%;
			  height: 100%;
			  border: 0;
			}

			.articulate-embed-responsive-21by9::before {
			  padding-top: 42.857143%;
			}

			.articulate-embed-responsive-16by9::before {
			  padding-top: 56.25%;
			}

			.articulate-embed-responsive-4by3::before {
			  padding-top: 75%;
			}

			.articulate-embed-responsive-1by1::before {
			  padding-top: 100%;
			}
			
			<?php
			return ob_get_clean();
		}

		public function inline_script() {
			ob_start();
			?>

			var articulatejq = jQuery.noConflict();
			articulatejq(document).ready( function( $ ) {
				<?php if ( $this->opt['lightbox_script'] == 'nivo_lightbox' ) { ?>
				var nivoLightboxTranslate = <?php echo json_encode( array( 'errorMessage' => __( 'The requested content cannot be loaded. Please try again later.', 'quiz' ) ) ); ?>;			
				articulatejq('.nivo_lightbox_iframe').nivoLightbox({
					effect: '<?php echo $this->opt['nivo_lightbox_effect']; ?>',                             // The effect to use when showing the lightbox
					theme: 'default',                           // The lightbox theme to use
					keyboardNav: true,                          // Enable/Disable keyboard navigation (left/right/escape)
					clickOverlayToClose: true,                  // If false clicking the "close" button will be the only way to close the lightbox
					onInit: function(){},                       // Callback when lightbox has loaded
					beforeShowLightbox: function(){},           // Callback before the lightbox is shown
					afterShowLightbox: function(lightbox){},    // Callback after the lightbox is shown
					beforeHideLightbox: function(){},           // Callback before the lightbox is hidden
					afterHideLightbox: function(){},            // Callback after the lightbox is hidden
					onPrev: function(element){},                // Callback when the lightbox gallery goes to previous item
					onNext: function(element){},                // Callback when the lightbox gallery goes to next item
					errorMessage: nivoLightboxTranslate.errorMessage // Error message when content can't be loaded
				});

				<?php } else { ?>
				
				//Examples of how to assign the ColorBox event to elements
				articulatejq(".colorbox_iframe").each( function() {
					var w = articulatejq(this).attr( 'data-width' );
					var h = articulatejq(this).attr( 'data-height' );
					articulatejq(this).colorbox({ 
						iframe: 	true, 
						transition: "<?php echo $this->opt['colorbox_transition']; ?>", 
						width: 		w, 
						height: 	h, 
						scrolling: 	<?php echo( $this->scrollbar == 'no' ) ? 'false' : 'true'; ?> 
					});
				} );

				<?php } ?>			
			
			});
			
			/* Colorbox resize function */
			var resizeTimer;
			function resizeColorBox()
			{
				var cboxOptions = {
				  width: '80%',
				  height: '80%',
				}
				if (resizeTimer) clearTimeout(resizeTimer);
				resizeTimer = setTimeout(function() {
						if (articulatejq('.colorbox_iframe').is(':visible')) {
							var w = articulatejq('.colorbox_iframe:visible').attr( 'data-width' );
							var h = articulatejq('.colorbox_iframe:visible').attr( 'data-height' );
							if ( w.indexOf("%") >= 0 ) {
								w = parseInt( w ) * window.innerWidth / 100;
							}
							if ( h.indexOf("%") >= 0 ) {
								h = parseInt( h ) * window.innerHeight / 100;
							}
							w = parseInt( w );
							h = parseInt( h );
								articulatejq.colorbox.resize({
								  width: window.innerWidth > w ? w : cboxOptions.width,
								  height: window.innerHeight > h ? h : cboxOptions.height
								} );
						}
				}, 300)
			}

			// Resize Colorbox when resizing window or changing mobile device orientation
			articulatejq(window).resize(resizeColorBox);
			window.addEventListener("orientationchange", resizeColorBox, false);
	
			<?php
			// if DIVI theme is activated and current page is DIVI visual builder
			if ( isset( $_GET['et_fb'] ) && $_GET['et_fb'] == 1 ) {
				?>
				
			window.wpActiveEditor = 'main_content_content_vb_tiny_mce'; //id of textarea of DIVI builder text component tinyMCE editor	
			<?php } ?>
			
			
			<?php
			return ob_get_clean();
		}


	}

}

$quiz_script_loader = new QuizScriptLoader();
