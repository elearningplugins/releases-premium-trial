<?php

class ApiDataProvider {
	/*
	public function getStatementResultsAndActors($statementObjectDefinitionUnd){
		$query = '[{"$match": {"statement.object.definition.name.und": "'.$statementObjectDefinitionUnd.'"}}, {"$project": {"timestamp": 1, "statement": {"result": 1, "actor": 1}}}]';
		$statements = $this -> getQueryResults($query);
		return $statements;
	}

	public function getUniquieStatementDefinitionNameUnds(){
		$query = '[{"$match": {"statement.object.definition.type": "http://adlnet.gov/expapi/activities/course"}}, {"$group": {"_id": "$statement.object.definition.name.und"}}]';
		$statements = $this -> getQueryResults($query);
		return $statements;
	}


	public function getStatementResultsForActor($statementObjectDefinitionUnd, $statementActorMbox){
		$query = '[{"$match": { "$and": [{"statement.object.definition.type": "http://adlnet.gov/expapi/activities/course"}, {"statement.object.definition.name.und": "'.$statementObjectDefinitionUnd.'"}, {"statement.actor.mbox": "mailto:'.$statementActorMbox.'"}]}}]';
		$statements = $this -> getQueryResults($query);
		return $statements;
	}

	public function getAnswersForRegistration($registrationId, $statementActorMbox){
		$query = '[{"$match": { "$and": [{"statement.context.registration": "'.$registrationId.'"}, {"statement.verb.id": "http://adlnet.gov/expapi/verbs/answered"}, {"statement.actor.mbox": "mailto:'.$statementActorMbox.'"}]}}]';
		$statements = $this -> getQueryResults($query);
		return $statements;
	}

	private function getQueryResults($query){
		$baseUrl = ARTICULATE_PREMIUM_TRACKING_ADMIN.'api/v1/statements/aggregate?pipeline=';
		$url = $baseUrl.urlencode($query);
		$statements = $this -> getObjectFromUrl($url);
		return $statements;
	}

	private function getObjectFromUrl($url){
		$login_var_string = base64_decode(iea_get_tracking_api_key());
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		curl_setopt($ch, CURLOPT_USERPWD, $login_var_string);
		curl_setopt($ch, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
		$statementsStr = curl_exec($ch);
		if($statementsStr === false)
		{
			echo 'Error curl: ' . curl_error($ch);
		}
		curl_close($ch);
		$statements = json_decode($statementsStr, true);
		return $statements;
	}
	*/
	/*
	 All above funcitons are commented out by oneTarek
	 and wrote same funcitons in new way
	 Now functions are not sending HTTP request to get remote data.
	 functionas are getting data using LRS functions directly as LRS is in same domain.
	 These new functions are NOT following xApi standard to make query
	 */
	public function getStatementResultsAndActors( $statementObjectDefinitionUnd ) {
		global $quiz_xapi_lrs_main_obj;
		$miniXapi = $quiz_xapi_lrs_main_obj->get_MiniXapi();
		$response = $miniXapi->getStatementResultsAndActors( $statementObjectDefinitionUnd );
		return $response;
	}

	public function getUniquieStatementDefinitionNameUnds() {
		global $quiz_xapi_lrs_main_obj;
		$miniXapi = $quiz_xapi_lrs_main_obj->get_MiniXapi();
		$response = $miniXapi->getUniquieStatementDefinitionNameUnds();
		return $response;
	}

	public function getStatementResultsForActor( $statementObjectDefinitionUnd, $statementActorMbox ) {
		global $quiz_xapi_lrs_main_obj;
		$miniXapi = $quiz_xapi_lrs_main_obj->get_MiniXapi();
		$response = $miniXapi->getStatementResultsForActor( $statementObjectDefinitionUnd, $statementActorMbox );
		return $response;
	}

	public function getAnswersForRegistration( $registrationId, $statementActorMbox ) {
		global $quiz_xapi_lrs_main_obj;
		$miniXapi = $quiz_xapi_lrs_main_obj->get_MiniXapi();
		$response = $miniXapi->getAnswersForRegistration( $registrationId, $statementActorMbox );
		return $response;
	}
}


