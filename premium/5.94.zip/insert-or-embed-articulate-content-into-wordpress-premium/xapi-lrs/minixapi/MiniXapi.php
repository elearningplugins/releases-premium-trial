<?php

require_once __DIR__ . '/src/utils/RewriteUtil.php';
require_once __DIR__ . '/src/utils/DatabaseException.php';
require_once __DIR__ . '/src/utils/StatementUtil.php';
require_once __DIR__ . '/ext/TinCanPHP/autoload.php';

/**
 * MiniXapi is an embeddable Learning Record Store.
 */
class MiniXapi {

	private $dsn;
	private $tablePrefix;
	private $basicAuth;

	private $next_statement_page_url; // store the url of next page request for statements viewer. Set this blank if there is not more record to return.
	/**
	 * Constructor.
	 */
	public function __construct() {
		 $this->tablePrefix = '';
	}

	/**
	 * Are we installed?
	 */
	public function isInstalled() {
		global $wpdb;

		if ( $wpdb->get_var( "SHOW TABLES LIKE '{$this->tablePrefix}statements'" ) != "{$this->tablePrefix}statements" ) {
			return false;
		}

		if ( $wpdb->get_var( "SHOW TABLES LIKE '{$this->tablePrefix}statements_index'" ) != "{$this->tablePrefix}statements_index" ) {
			return false;
		}

		if ( $wpdb->get_var( "SHOW TABLES LIKE '{$this->tablePrefix}statements_expand'" ) != "{$this->tablePrefix}statements_expand" ) {
			return false;
		}
		/**
		 * 2019-08-12
		 * Codeable Paul Cohen
		 * Implement state API for Storyline resume functionality
		 */
		if ( $wpdb->get_var( "SHOW TABLES LIKE '{$this->tablePrefix}states'" ) != "{$this->tablePrefix}states" ) {
			return false;
		}

		/**
		 * 2020-Nov
		 * Carlos Galilea
		 * Add tables for reports
		 */

		if ( $wpdb->get_var( "SHOW TABLES LIKE '{$this->tablePrefix}courses'" ) != "{$this->tablePrefix}courses" ) {
			return false;
		}

		if ( $wpdb->get_var( "SHOW TABLES LIKE '{$this->tablePrefix}status'" ) != "{$this->tablePrefix}status" ) {
			return false;
		}

		return true;
	}

	/**
	 * Set a table prefix.
	 * This function needs to be called before install.
	 */
	public function setTablePrefix( $tablePrefix ) {
		$this->tablePrefix = $tablePrefix;
	}

	/**
	 * Set username and password to use for basic auth.
	 */
	public function setBasicAuth( $userColonPass ) {
		$this->basicAuth = $userColonPass;
	}

	public function getBasicAuthFromRequest() {
		 $auth = '';

		// This technique is copied from https://github.com/eventespresso/Basic-Auth/blob/master/basic-auth.php#L19-L53

		// account for issue where some servers remove the PHP auth headers
		// so instead look for auth info in a custom environment variable set by rewrite rules
		// probably in .htaccess
		// and, as a last resort, look in the querystring
		if ( ! isset( $_SERVER['PHP_AUTH_USER'] ) ) {
			if ( isset( $_SERVER['HTTP_AUTHORIZATION'] ) ) {
				$header = $_SERVER['HTTP_AUTHORIZATION'];
			} elseif ( isset( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ) ) {
				$header = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
			} elseif ( isset( $_GET['_authorization'] ) ) {
				$header = $_GET['_authorization'];
				// and now remove this special header so it doesn't interfere with other parts of the request
				unset( $_GET['authorization'] );
			} elseif ( isset( $_SERVER['HTTP_X_AUTHORIZATION'] ) ) {
				$header = $_SERVER['HTTP_X_AUTHORIZATION'];
			} elseif ( isset( $_SERVER['HTTP_REFERER'] ) ) {
				$HTTP_REF = urldecode( $_SERVER['HTTP_REFERER'] );
				preg_match( '/auth=(Basic .*?=)/', $HTTP_REF, $matches );
				$header = $matches[1];
			} else {
				$header = null;
			}
			if ( ! empty( $header ) ) {
				// make sure there's the word 'Basic ' at the start, or else it's not for us
				if ( strpos( $header, 'Basic ' ) === 0 ) {
					$header_sans_word_basic = str_replace( 'Basic ', '', $header );
					$auth_parts             = explode( ':', base64_decode( $header_sans_word_basic ), 2 );
					if ( is_array( $auth_parts ) && isset( $auth_parts[0], $auth_parts[1] ) ) {
						$_SERVER['PHP_AUTH_USER'] = $auth_parts[0];
						$_SERVER['PHP_AUTH_PW']   = $auth_parts[1];
					}
				}
			}
		}

		// Check that we're trying to authenticate
		if ( ! isset( $_SERVER['PHP_AUTH_USER'] ) ) {
			return $auth;
		}
		$username = $_SERVER['PHP_AUTH_USER'];
		$password = $_SERVER['PHP_AUTH_PW'];
		$auth     = $_SERVER['PHP_AUTH_USER'] . ':' . $_SERVER['PHP_AUTH_PW'];
		return $auth;

	}
	/**
	 * Serve a request.
	 */
	public function serve() {
		$auth = $this->getBasicAuthFromRequest();

		if ( $this->basicAuth && $auth != $this->basicAuth ) {
			header( 'WWW-Authenticate: Basic realm="MiniXapi"' );
			header( 'HTTP/1.0 401 Unauthorized' );
			$res = array(
				'error'   => true,
				'message' => 'Unauthorized',
			);
			echo json_encode( $res, JSON_PRETTY_PRINT );
			exit;
		}

		$components = RewriteUtil::getPathComponents();

		try {
			$res = $this->processRequest(
				$_SERVER['REQUEST_METHOD'],
				$components[0],
				$_REQUEST,
				file_get_contents( 'php://input' )
			);
		} catch ( Exception $e ) {
			http_response_code( 500 );
			header( 'Content-Type: application/json' );
			$res = array(
				'error'   => true,
				'message' => $e->getMessage(),
			);
			echo json_encode( $res, JSON_PRETTY_PRINT );
			exit;
			// return;
		}

		header( 'Content-Type: application/json' );
		echo json_encode( $res, JSON_PRETTY_PRINT );
		exit;
	}

	/**
	 * Put a statement in the xAPI database.
	 *
	 * @return String The id for the inserted statement.
	 */
	public function putStatement( $data ) {
		global $wpdb;
		$statement = new TinCan\Statement( $data );
		StatementUtil::formalize( $statement );

		$statementObject  = $statement->asVersion( TinCan\Version::latest() );
		$statementEncoded = json_encode( $statementObject, JSON_PRETTY_PRINT );
		$statementId      = $statement->getId();

		$table   = "{$this->tablePrefix}statements";
		$datains = array(
			'statementId' => $statementId,
			'statement'   => $statementEncoded,
		);
		$format  = array( '%s', '%s' );
		$wpdb->insert( $table, $datains, $format );

		$indices   = array();
		$indices[] = array(
			'type'  => 'verb',
			'value' => $statement->getVerb()->getId(),
		);

		$indices[] = array(
			'type'  => 'agent',
			'value' => $statement->getActor()->getMbox(),
		);

		$indices[] = array(
			'type'  => 'activity',
			'value' => $statement->getTarget()->getId(),
		);

		$indices[] = array(
			'type'  => 'relatedActivity',
			'value' => $statement->getTarget()->getId(),
		);

		$context = $statement->getContext();
		if ( $context ) {
			$contextActivities = $context->getContextActivities();
			$relatedActivities = array_merge(
				$contextActivities->getCategory(),
				$contextActivities->getGrouping(),
				$contextActivities->getParent(),
				$contextActivities->getOther()
			);

			foreach ( $relatedActivities as $relatedActivity ) {
				$indices[] = array(
					'type'  => 'relatedActivity',
					'value' => $relatedActivity->getId(),
				);
			}
		}

		$qs =
			"INSERT INTO {$this->tablePrefix}statements_index " .
			'            (type, value, statementId) ' .
			'VALUES ';

		$qa     = array();
		$params = array();

		/*
		Check and remove duplicate $indices . We can not insert duplicate value to database.
		For some articulate content we are getting duplicate relatedActivity.
		@author: oneTarek
		*/
		$indices_unique = array();
		$indices_lines  = array();
		foreach ( $indices as $index ) {
			$str = $index['type'] . $index['value'];
			if ( ! in_array( $str, $indices_lines ) ) {
				$indices_unique[] = $index;
				$indices_lines[]  = $str;
			}
		}
		// end check and remove duplicate $indices

		foreach ( $indices_unique as $index ) { // update by oneTarek. changed $indices to $indices_unique
			$qa[]     = '(?,?,?)';
			$params[] = $index['type'];
			$params[] = $index['value'];
			$params[] = $statement->getId();
		}

		$values = array();

		foreach ( $indices_unique as $index ) {
			$values[] = $wpdb->prepare( '(%s,%s,%s)', $index['type'], $index['value'], $statement->getId() );
		}

		$query  = "INSERT INTO {$this->tablePrefix}statements_index (type, value, statementId) VALUES ";
		$query .= implode( ",\n", $values );
		$wpdb->query( $query );

		if ( isset( $data['result'] ) ) {
			// insert to result table
			$statementId = $statement->getId(); // some articulate contents send data without statement id. Using this method to confirm a not null value of statementId.
			$userName    = isset( $data['actor']['name'] ) ? $data['actor']['name'] : '';
			$actor_mbox  = isset( $data['actor']['mbox'] ) ? $data['actor']['mbox'] : '';

			$verb_id = isset( $data['verb']['id'] ) ? $data['verb']['id'] : '';

			$verb_display         = $this->getfirstValue( $data['verb']['display'] );
			$context_registration = isset( $data['context']['registration'] ) ? $data['context']['registration'] : '';
			$st_timestamp         = isset( $data['timestamp'] ) ? $data['timestamp'] : '';

			$object_objecttype      = isset( $data['object']['objectType'] ) ? $data['object']['objectType'] : '';
			$object_id              = isset( $data['object']['id'] ) ? $data['object']['id'] : '';
			$object_definition_type = isset( $data['object']['definition']['type'] ) ? $data['object']['definition']['type'] : '';

			// fix by ajayitprof, get name always for any lang und, us-US , ar...
			$object_definition_name_und = $this->getfirstValue( $data['object']['definition']['name'] );

			$course_name = '';
			if ( $object_definition_type != '' ) {
				if ( $object_definition_type == 'http://adlnet.gov/expapi/activities/course' && $object_definition_name_und != '' ) {
					$course_name = $object_definition_name_und;
				}
			} else {
				if ( in_array( $verb_display, array( 'passed', 'failed', 'attempted' ) ) ) {
					$course_name = $object_id;
				}
			}

			// Get course id from courses table using the uuid and path of course launched
			$pathinfo = pathinfo( $_SERVER['HTTP_REFERER'] );

			$uuid_path = $pathinfo['dirname'] . DIRECTORY_SEPARATOR . 'uuid.txt';
			$uuid      = file_get_contents( $uuid_path );

			// Get key id of course from uuid

			$qs           = "SELECT id, course_name FROM {$this->tablePrefix}courses WHERE uuid = '$uuid' LIMIT 1";
			$results_data = $wpdb->get_results( $qs, ARRAY_A );

			// should only return one row, we need only the id
			$course_id = $results_data[0]['id'];

			// end Calculate course name

			$q = "INSERT INTO {$this->tablePrefix}statements_expand " .
					'       (statementId, actor_mbox, verb_id, verb_display, context_registration, st_timestamp,object_objecttype, object_id, object_definition_type, object_definition_name_und, course_name) ' .
					'VALUES ($statementId, $actor_mbox, $verb_id, $verb_display, $context_registration, $st_timestamp, $object_objecttype, $object_id, $object_definition_type, $object_definition_name_und, $course_name) ';

			$table   = "{$this->tablePrefix}statements_expand";
			$datains = array(
				'statementId'                => $statementId,
				'actor_mbox'                 => $actor_mbox,
				'verb_id'                    => $verb_id,
				'verb_display'               => $verb_display,
				'context_registration'       => $context_registration,
				'st_timestamp'               => $st_timestamp,
				'object_objecttype'          => $object_objecttype,
				'object_id'                  => $object_id,
				'object_definition_type'     => $object_definition_type,
				'object_definition_name_und' => $object_definition_name_und,
				'course_name'                => $course_name,
			);
			$format  = array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' );
			$wpdb->insert( $table, $datains, $format );

			// CG: insert values into status table
			// only insert when verb is passed, failed, completed or attempted and course_name is present (we cannot allow duplicate course names!)
			if ( in_array( $verb_display, array( 'passed', 'failed', 'completed' ) ) ) {

				$user_name = str_replace( 'mailto:', '', $actor_mbox );

				// check context_registration should be unique
				// if context_registration exists we are updating the status (depending on other conditions)
				$qs                  = "SELECT id, score, status FROM {$this->tablePrefix}status WHERE context_registration = '$context_registration' AND actor_mbox = '$actor_mbox' LIMIT 1";
				$results_status_data = $wpdb->get_results( $qs, ARRAY_A );

				// should only return one row, we need only the id
				$id_value             = $results_status_data[0]['id'];
				$current_score_value  = $results_status_data[0]['score'];
				$current_status_value = $results_status_data[0]['status'];

				// get score if present (for failed and passed verbs)
				$score = 0;

				if ( in_array( $verb_display, array( 'passed', 'failed' ) ) ) {
					$new_score = isset( $data['result']['score']['scaled'] ) ? $data['result']['score']['scaled'] * 100 : '';

					// if no scaled score present check raw score
					if ( $new_score == '' ) {
						$new_score = isset( $data['result']['score']['raw'] ) ? $data['result']['score']['raw'] * 100 / $data['result']['score']['max'] : '';
					}
					$score = $new_score;
				}

				// error_log( 'DebugCarlos=' );
				// error_log( print_r( $results_status_data[0], true ) );

				// new entry
				if ( ! $id_value ) {

					// no matching id for context_registration, set to null for insertion query
					unset( $id_value );

					// get course id and name from courses table
					$id_course_fk  = $course_id;
					$course_dbname = $course_data['course_name'];

					$q = "INSERT INTO {$this->tablePrefix}status " .
							'       (id, id_course_fk, uuid, user_name, actor_mbox, verb_id, context_registration, st_timestamp, status, score, course_name, statementId) ' .
							'VALUES ($id_value, $id_course_fk, $uuid, $userName, $actor_mbox, $verb_id, $context_registration, $st_timestamp, $verb_display, $score, $course_dbname, $statementId) ';

					$table   = "{$this->tablePrefix}status";
					$datains = array(
						'id'                   => $id_value,
						'id_course_fk'         => $id_course_fk,
						'uuid'                 => $uuid,
						'user_name'            => $userName,
						'actor_mbox'           => $actor_mbox,
						'verb_id'              => $verb_id,
						'context_registration' => $context_registration,
						'st_timestamp'         => $st_timestamp,
						'status'               => $verb_display,
						'score'                => $score,
						'course_name'          => $course_dbname,
						'statementId'          => $statementId,
					);
					$format  = array( '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s' );
					$wpdb->insert( $table, $datains, $format );

				}

				// update existing entry
				else {

							// $score = $current_score_value;
						// $course_dbname = 'update existing entry only if score is bette';
						$q = "UPDATE {$this->tablePrefix}status SET verb_id = $verb_id, course_name = $course_dbname, st_timestamp = $st_timestamp, status = $verb_display, score = $score WHERE id = $id_value ";

						$table   = "{$this->tablePrefix}status";
						$datains = array(
							'verb_id'      => $verb_id,
							'course_name'  => $course_dbname,
							'st_timestamp' => $st_timestamp,
							'status'       => $verb_display,
							'score'        => $score,
						);
						$dformat = array( '%s', '%s', '%s', '%s' );
						$where   = array( 'id' => $id_value );
						$wformat = array( '%d' );
						$wpdb->update( $table, $datains, $where, $dformat, $wformat );

				}
			} //CG end if: insert values into status table

		} //end if( isset( $data['result'] ) )

		return $statement->getId();
	}

	/**
	 * Get statements.
	 * Returns an array with matching statements.
	 *
	 * @return Array The statements matching the query.
	 */
	public function getStatements( $query = array() ) {
		global $wpdb;
		$pdo                           = $this->getPdo();
		$this->next_statement_page_url = '';
		$offset                        = isset( $query['lrs_offset'] ) ? intval( $query['lrs_offset'] ) : 0;
		if ( $offset < 0 ) {
			$offset = 0;
		}

		$understood = array(
			'agent',
			'verb',
			'activity',
			'statementId',
			'related_activities',
		);
		if ( isset( $query['agent'] ) ) {
			$decoded = json_decode( $query['agent'], true );
			if ( ! $decoded ) {
				$decoded = array( 'mbox' => $query['agent'] );
				// throw new Exception( 'Unable to decode json for agent: ' . $query['agent'] );
			}

			if ( ! $decoded['mbox'] ) {
				throw new Exception( 'Expected agent to have mbox' );
			}

			$query['agent'] = $decoded['mbox'];
		}

		$limit = isset( $query['limit'] ) ? intval( $query['limit'] ) : 25;
		if ( $limit < 1 ) {
			$limit = 25;
		}

		$tables     = array();
		$wheres     = array();
		$params     = array();
		$tableCount = 0;

		$queryables = array(
			'agent'    => 'agent',
			'verb'     => 'verb',
			'activity' => 'activity',
		);

		if ( isset( $query['related_activities'] ) && $query['related_activities'] ) {
			$queryables['activity'] = 'relatedActivity';
		}

		foreach ( $queryables as $queryable => $type ) {
			if ( isset( $query[ $queryable ] ) ) {
				$tables[] = "{$this->tablePrefix}statements_index";
				$wheres[] = "t_$tableCount.type=?";
				$params[] = $type;
				$wheres[] = "t_$tableCount.value=?";
				$params[] = $query[ $queryable ];
				$tableCount++;
			}
		}

		$tables[] = "{$this->tablePrefix}statements";
		$stn      = $tableCount; // statements_table_number
		if ( isset( $query['statementId'] ) ) {
			$wheres[] = "t_$tableCount.statementId=?";
			$params[] = $query['statementId'];
		}

		// Date range queries start here.
		$date_since = ! empty( $query['since'] ) ? $query['since'] : '';
		$date_until = ! empty( $query['until'] ) ? $query['until'] : '';
		if ( $date_since && $date_until ) {
			$wheres[] = "date(t_$tableCount.stored_time) BETWEEN '$date_since' AND '$date_until'";
		} elseif ( $date_since && ! $date_until ) {
			$wheres[] = "date(t_$tableCount.stored_time) >= '$date_since'";
		} elseif ( ! $date_since && $date_until ) {
			$wheres[] = "date(t_$tableCount.stored_time) <= '$date_until'";
		}
		// End custom date range code.

		$prev = $tableCount;
		$tableCount++;

		$qs  = "SELECT DISTINCT t_$prev.statement, t_$prev.stored_time FROM $tables[0] AS t_0 ";
		$qsc = "SELECT COUNT( DISTINCT t_$prev.statement ) FROM $tables[0] AS t_0 "; // for count total rows

		for ( $i = 1; $i < $tableCount; $i++ ) {
			$prev = $i - 1;
			$qs  .= "JOIN $tables[$i] AS t_$i ON t_$prev.statementId=t_$i.statementId ";
			$qsc .= "JOIN $tables[$i] AS t_$i ON t_$prev.statementId=t_$i.statementId ";
		}

		if ( $wheres ) {
			$qs  .= 'WHERE ';
			$qsc .= 'WHERE ';
		}

		$qs  .= join( ' AND ', $wheres );
		$qsc .= join( ' AND ', $wheres );

		// RUN COUNT QUERY AND GET COUNT
		$qc = $pdo->prepare( $qsc );
		if ( ! $qc ) {
			throw new DatabaseException( $pdo->errorInfo() );
		}
		$rc = $qc->execute( $params );
		if ( ! $rc ) {
			throw new DatabaseException( $qc->errorInfo() );
		}
		$row_count = $qc->fetchColumn();
		// end COUNT

		// ORDER BY DATE
		$qs .= ' ORDER BY t_' . $stn . '.stored_time DESC ';

		// LIMIT
		$qs .= ' LIMIT ' . $limit;

		// Calculate offset
		if ( $offset >= $row_count ) {
			// do not go next
			return array();
		}
		if ( $offset ) {
			$qs .= ' OFFSET ' . $offset;
		}
		// end calculate offset

		$q = $pdo->prepare( $qs );
		if ( ! $q ) {
			throw new DatabaseException( $pdo->errorInfo() );
		}

		$r = $q->execute( $params );
		if ( ! $r ) {
			throw new DatabaseException( $q->errorInfo() );
		}

		$res = array();
		foreach ( $q as $row ) {
			$res[] = json_decode( $row['statement'], true );
		}

		// generate more url
		$next_offset = $offset + $limit;
		if ( $next_offset < $row_count ) {
			$query['lrs_offset']           = $next_offset;
			$this->next_statement_page_url = add_query_arg( $query, '/statements' );
		}
		return $res;
	}

	/**
	 * Process a request.
	 */
	public function processRequest( $method, $url, $query = array(), $body = '' ) {
		if ( ( $method == 'POST' || $method == 'PUT' ) && $url == 'statements' ) {
			$data = json_decode( $body, true );
			if ( ! $data ) {
				throw new Exception( 'Unable to parse JSON' );
			}

			$statementId = $this->putStatement( $data );
			return array( $statementId );
		}

		/**
		 * 2019-08-12
		 * Codeable Paul Cohen
		 * Implement state API for Storyline resume functionality
		 */
		elseif ( $method == 'PUT' && $url == 'activities' ) {
			$putResult = $this->PutState( $query, $body );
			return $putResult;
		}

		if ( $method == 'GET' && $url == 'statements' ) {
			$res = $this->getStatements( $query );

			if ( isset( $query['statementId'] ) ) {
				return $res[0];
			}

			$return_arr = array( 'statements' => $res );
			if ( $this->next_statement_page_url != '' ) {
				$return_arr['more'] = $this->next_statement_page_url;
			}
			return $return_arr;
		}
		/**
		 * 2019-08-12
		 * Codeable Paul Cohen
		 * Implement state API for Storyline resume functionality
		 */
		elseif ( $method == 'GET' && $url == 'activities' ) {
			$resumeData = $this->getState( $query, $body );
			return $resumeData;
		}

		if ( ! $url ) {
			throw new Exception( 'Expected xAPI method, try appending /statements to the url.' );
		}

	}

	/**
	 * 2019-08-12
	 * Codeable Paul Cohen
	 * Implement state API for Storyline resume functionality
	 */
	public function getState( $query = array(), $body = '' ) {
		global $wpdb;
		error_log( '******GET for Resume' );
		error_log( 'getState for Resume query key + values' );
		foreach ( $query as $x => $x_value ) {
			error_log( 'Key=' . $x . ', Value=' . $x_value );
			switch ( $x ) {
				case 'stateId':
					$stateId = $x_value;
					// error_log("stateId=" . $stateId);
					break;
				case 'activityId':
					$activityId = $x_value;
					// error_log("activityId=" . $activityId);
					break;
				case 'agent':
					$agent = $x_value;
					$data  = json_decode( $agent, true );
					if ( ! $data ) {
						throw new Exception( 'Unable to parse JSON' );
					}
					foreach ( $data as $x2 => $x2_value ) {
						switch ( $x2 ) {
							case 'objectType':
								$objectType = $x2_value;
								// error_log("objectType=" . $objectType);
								break;
							case 'mbox':
								$mbox = $x2_value;
								// error_log("mbox=" . $mbox);
								break;
							case 'name':
								$userName = $x2_value;
								// error_log("userName=" . $userName);
								break;
						}
					}
					break;
				case 'registration':
					$registration = $x_value;
					break;
			}
		}
		// Test resume data (compressed)

		// $pdo = $this->getPdo(); WHERE uuid = '$course'"
		// $qs = "SELECT * FROM {$this->tablePrefix}states WHERE state_id = ? AND activity_id = ? AND user_name = ?";
		$qs                 = "SELECT * FROM {$this->tablePrefix}states WHERE state_id = '$stateId' AND activity_id = '$activityId' AND user_name = '$userName'";
		$results_state_data = $wpdb->get_results( $qs, ARRAY_A );

		// $r = $q->execute([$stateId, $activityId, $userName]);
		// foreach ( $results_status_tbl as $key => $stmnt ) {

		$res = array();

		foreach ( $results_state_data as $row ) {
			$res[] = $row;
		}
		// Quick and dirty check to eliminate duplicate records
		if ( count( $res ) > 1 ) {
			return null;
		} else {
			$resumeData = isset( $res[0] ) ? $res[0]['state_data'] : '';
			// State Data decoding - WARNING: THIS CAN IMPACT PERFORMANCE SO USE ONLY WHEN NECESSARY
			// error_log("stateData=" . (string) $resumeData);
			// First, read your data into the slides method
			// $slides = $this->slides($resumeData);
			// if you only need the slide count
			// $numslides = count(array_unique($slides));
			// If you want to see the actual slide IDs
			// $detail = $this->translateSlides($slides);
			// error_log("Course resuming at Slide Number =" . $numslides);
			return $resumeData;
		}
	}

	/**
	 * 2019-08-12
	 * Codeable Paul Cohen
	 * Implement state API for Storyline resume functionality
	 */
	public function getStateId( $query = array() ) {
		global $wpdb;
		error_log( '***Start - getState Id for Put Insert or Update state record' );
		foreach ( $query as $x => $x_value ) {
			// error_log("Key=" . $x . ", Value=" . $x_value);
			switch ( $x ) {
				case 'stateId':
					$stateId = $x_value;
					// error_log("stateId=" . $stateId);
					break;
				case 'activityId':
					$activityId = $x_value;
					// error_log("activityId=" . $activityId);
					break;
				case 'agent':
					$agent = $x_value;
					// error_log("agent=" . $agent);
					$data = json_decode( $agent, true );
					if ( ! $data ) {
						throw new Exception( 'Unable to parse JSON' );
					}
					foreach ( $data as $x2 => $x2_value ) {
						switch ( $x2 ) {
							case 'objectType':
								$objectType = $x2_value;
								// error_log("objectType=" . $objectType);
								break;
							case 'mbox':
								$mbox = $x2_value;
								// error_log("mbox=" . $mbox);
								break;
							case 'name':
								$userName = $x2_value;
								// error_log("userName=" . $userName);
								break;
						}
					}
					break;
				case 'registration':
					$registration = $x_value;
					// error_log("registration=" . $registration);
					break;
			}
		}
		// Test resume data (compressed)

		$qs                 = "SELECT * FROM {$this->tablePrefix}states WHERE state_id = '$stateId' AND activity_id = '$activityId' AND user_name = '$userName'";
		$results_state_data = $wpdb->get_results( $qs, ARRAY_A );

		$res = array();

		foreach ( $results_state_data as $row ) {
			$res[] = $row;
		}
		// Quick and dirty check to eliminate duplicate records
		if ( count( $res ) > 1 ) {
			error_log( '***Finish - getState Id for Put Insert or Update state record' );
			return null;
		} else {
			$id = isset( $res[0] ) ? $res[0]['id'] : '';
			error_log( 'id=' . $id );
			error_log( '***Finish - getState Id for Put Insert or Update state record' );
			return $id;
		}
	}
	/**
	 * 2019-08-12
	 * Codeable Paul Cohen
	 * Implement state API for Storyline resume functionality
	 * Test Function to mockup resumetesting
	 */
	public function getTestState( $query = array(), $body = '' ) {
		error_log( "Get Activities State $query key + values" );
		foreach ( $query as $x => $x_value ) {
			error_log( 'Key=' . $x . ', Value=' . $x_value );
		}
		// Test resume data (compressed)
		$slide2     = '2K246070ji1001112a0101201112~2L1a00000000001^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^101^1^101^v_player.6RoriILyZrf.5rv2GAmKi6e1^1^00r0000000000000000000000000002000';
		$slide3     = '2j56607080on1001212f010120111201212~2L1a00000000001^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^101^1^101^v_player.6RoriILyZrf.6oAmxoYSFQ41^1^00~2S2~2o2f210b101001a1a103Jz0~2913400r78000141^h_default_DisabledA780501c1^q_default_Selected_Disabled3400PN2BhH3400340034003400q7w020181^g_default_Visited000000000000000000000000000000002000';
		$slide4     = '2B8860708090ts1001312k01012011120121201312~2L1a00000000001^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^101^1^101^v_player.6RoriILyZrf.5oovvGpXcCK1^1^00~216~2o2f210b101001a1a103Jz0~2913400r78000141^h_default_DisabledA780501c1^q_default_Selected_Disabled3400PN2BhH3400340034003400q7w020181^g_default_Visited000000~283h41110b101001a1a1038e1~2T13400x79000o000c0141^h_default_Disabledx79000o0s1e0141^h_default_DisabledG79050o0K0d01c1^q_default_Selected_Disabled3400PN2NfH3400340034003400q70020181^g_default_Visited00000000000000000000000000000002000';
		$slide5     = '2Rba60708090a0yx1001412p0101201112012120131201412~2L1a00000000001^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^101^1^101^v_player.6RoriILyZrf.5hfXU149fAe1^1^00~2a9~2o2f210b101001a1a103Jz0~2913400r78000141^h_default_DisabledA780501c1^q_default_Selected_Disabled3400PN2BhH3400340034003400q7w020181^g_default_Visited000000~283h41110b101001a1a1038e1~2T13400x79000o000c0141^h_default_Disabledx79000o0s1e0141^h_default_DisabledG79050o0K0d01c1^q_default_Selected_Disabled3400PN2NfH3400340034003400q70020181^g_default_Visited000000~263f210b101021010113v_0~2T13400G79030o000c01c1^q_default_Selected_Disabledx79000o0s1e0141^h_default_Disabledx79000o0K0d0141^h_default_Disabled3400P0N2VhH3400340034003400q70020181^g_default_Visited000000000000000000000000000002000';
		$slide6     = '2Cdc60708090a0b0DC1001512u010120111201212013120141201512~2S1a00000000001^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^8dsdgsadg101^1^101^v_player.6RoriILyZrf.6WTeCBHvD3G1^1^00~2Ja~2o2f210b101001a1a103Jz0~2913400r78000141^h_default_DisabledA780501c1^q_default_Selected_Disabled3400PN2BhH3400340034003400q7w020181^g_default_Visited000000~283h41110b101001a1a1038e1~2T13400x79000o000c0141^h_default_Disabledx79000o0s1e0141^h_default_DisabledG79050o0K0d01c1^q_default_Selected_Disabled3400PN2NfH3400340034003400q70020181^g_default_Visited000000~263f210b101021010113v_0~2T13400G79030o000c01c1^q_default_Selected_Disabledx79000o0s1e0141^h_default_Disabledx79000o0K0d0141^h_default_Disabled3400P0N2VhH3400340034003400q70020181^g_default_Visited00000~2w1h41110b1010210101138e1id68008dsdgsadg3400P0N2pkH3400340034003400q7w020181^g_default_Visited00000000000000000000000000002000';
		$slide7     = '2Ufe60708090a0b0c0IH1001612z01012011120121201312014120151201612~2S1a00000000001^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^1^8dsdgsadg101^1^101^v_player.6RoriILyZrf.5z9aQlNOTtG1^1^00~2Uc~2o2f210b101001a1a103Jz0~2913400r78000141^h_default_DisabledA780501c1^q_default_Selected_Disabled3400PN2BhH3400340034003400q7w020181^g_default_Visited000000~283h41110b101001a1a1038e1~2T13400x79000o000c0141^h_default_Disabledx79000o0s1e0141^h_default_DisabledG79050o0K0d01c1^q_default_Selected_Disabled3400PN2NfH3400340034003400q70020181^g_default_Visited000000~263f210b101021010113v_0~2T13400G79030o000c01c1^q_default_Selected_Disabledx79000o0s1e0141^h_default_Disabledx79000o0K0d0141^h_default_Disabled3400P0N2VhH3400340034003400q70020181^g_default_Visited00000~2w1h41110b1010210101138e1id68008dsdgsadg3400P0N2pkH3400340034003400q7w020181^g_default_Visited00000~282h41110b1010210101238e1W3400mO50tnf0L0e001171u0g1$$9490f040d09490f0q1f066c00113400P0N2MlH3400340034003400q70020181^g_default_Visited0000000000000000000000000002000';
		$resumeData = $slide7;
		error_log( 'resume data=' . (string) $resumeData );
		// First, read your data into the slides method
		$slides = $this->slides( $resumeData );
		// if you only need the slide count
		$numslides = count( array_unique( $slides ) );
		// If you want to see the actual slide IDs
		$detail = $this->translateSlides( $slides );
		error_log( 'Resuming at Slide Number=' . $numslides );
		return $resumeData;
	}

	/**
	 * 2019-08-12
	 * Codeable Paul Cohen
	 * Implement state API for Storyline resume functionality
	 */
	public function putState( $query = array(), $body = '' ) {
		global $wpdb;
		error_log( '******PUT' );
		error_log( 'PUT putState query key + values' );
		foreach ( $query as $x => $x_value ) {
			error_log( 'Key=' . $x . ', Value=' . $x_value );
			switch ( $x ) {
				case 'stateId':
					$stateId = $x_value;
					// error_log("stateId=" . $stateId);
					break;
				case 'activityId':
					$activityId = $x_value;
					// error_log("activityId=" . $activityId);
					break;
				case 'agent':
					$agent = $x_value;
					// error_log("agent=" . $agent);
					$data = json_decode( $agent, true );
					if ( ! $data ) {
						throw new Exception( 'Unable to parse JSON' );
					}
					foreach ( $data as $x2 => $x2_value ) {
						switch ( $x2 ) {
							case 'objectType':
								$objectType = $x2_value;
								// error_log("objectType=" . $objectType);
								break;
							case 'mbox':
								$mbox = $x2_value;
								// error_log("mbox=" . $mbox);
								break;
							case 'name':
								$userName = $x2_value;
								// error_log("userName=" . $userName);
								break;
						}
					}
					break;
				case 'registration':
					$registration = $x_value;
					// error_log("registration=" . $registration);
					break;
			}
		}

		// Also check for use case where resume seems to send an empty state record. Ignore these so state does not get overwritten with a blank entry.
		if ( $body == '' ) {
			error_log( 'State is empty so no Update to State db record' );
			return false;
		}

		// State Data decoding - WARNING: THIS CAN IMPACT PERFORMANCE SO USE ONLY WHEN NECESSARY
		// error_log("stateData=" . (string) $body);
		// First, read your data into the slides method
		// $slides = $this->slides($body);
		// if you only need the slide count
		// $numslides = count(array_unique($slides));
		// If you want to see the actual slide IDs
		// $detail = $this->translateSlides($slides);
		// error_log("numslides=" . $numslides);

		// $pdo = $this->getPdo();
		$id = $this->getStateId( $query );
		if ( $id != null ) {
			// update existing record
			$q = "UPDATE {$this->tablePrefix}states SET state_data = '$body' where id = '$id'";
			$wpdb->query( $q );

			$date = date_create();

			// error_log("Record id=" . $id . " UPDATED with new state for slide " . $numslides);
			error_log( 'Record id=' . $id . ' UPDATED with new state' );
			return true;
		} else {
			// insert first time record
			$date        = date_create();
			$data_format = date_format( $date, 'Y-m-d H:i:s' );
			$q           = "INSERT INTO {$this->tablePrefix}states " .
					'       (user_name, actor_mbox, context_registration, st_timestamp, state_id, activity_id, state_data) ' .
					'VALUES ($userName, $mbox, $registration, $data_format, $stateId, $activityId, $body) ';

			$table  = "{$this->tablePrefix}states";
			$data   = array(
				'user_name'            => $userName,
				'context_registration' => $registration,
				'st_timestamp'         => $data_format,
				'state_id'             => $stateId,
				'activity_id'          => $activityId,
				'state_data'           => $body,
				'actor_mbox'           => $mbox,
			);
			$format = array( '%s', '%s', '%s', '%s', '%s', '%s', '%s' );
			$wpdb->insert( $table, $data, $format );

			// $wpdb->query( $q );

			/*
			$r    = $q->execute(
				array(
					'user_name'            => $userName,
					'actor_mbox'           => $mbox,
					'context_registration' => $registration,
					'st_timestamp'         => date_format( $date, 'Y-m-d H:i:s' ),
					'state_id'             => $stateId,
					'activity_id'          => $activityId,
					'state_data'           => $body,
				)
			);*/

			// error_log("New Record INSERTED with new state for slide " . $numslides);
			error_log( 'Record id=' . $id . ' UPDATED with new state' );
			return true;
		}
	}


	/**
	 * 2019-08-12
	 * Codeable Paul Cohen
	 * Implement state API for Storyline resume functionality
	 * Test Function to mockup resume testing    *
	 */
	public function putTestState( $query = array(), $body = '' ) {
		error_log( "Put Activities State $query key + values" );
		foreach ( $query as $x => $x_value ) {
			error_log( 'Key=' . $x . ', Value=' . $x_value );
		}
		error_log( 'data=' . (string) $body );
		// First, read your data into the slides method
		$slides = $this->slides( $body );
		// if you only need the slide count
		$numslides = count( array_unique( $slides ) );
		// If you want to see the actual slide IDs
		$detail = $this->translateSlides( $slides );
		error_log( 'numslides=' . $numslides );

		return null;
	}

	/**
	 * 2019-08-12
	 * Codeable Paul Cohen
	 * Implement state API for Storyline resume functionality
	 */
	public function slides( $data ) {
		$matches   = array();
		$items     = array();
		$dataregex = '/100(?P<end>[0-9a-zA-Z_$]{4,5}(?=[0-9a-zA-Z_$~]+010))(.*?)(?=010)(?P<data>(.*?)\k<end>)/';
		$itemregex = '/0(?=[0-9a-zA-Z_$])(?P<item>[0-9a-zA-Z_$]{4,}?(?=(0|$)))/';
		preg_match( $dataregex, $data, $matches );
		preg_match_all( $itemregex, $matches['data'], $items );
		return $items['item'];
	}

	/**
	 * 2019-08-12
	 * Codeable Paul Cohen
	 * Implement state API for Storyline resume functionality
	 */
	public function translateSlides( $slides ) {
		require_once __DIR__ . '/src/utils/AnyBase.php';
		$a64 = new AnyBase( '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_$' );
		$r   = array();
		foreach ( $slides as $slide ) {
			switch ( strlen( $slide ) ) {
				case 4:
					list($page64, $section64) = str_split( $slide, 2 );
					break;
				default: // anything else
					$section64 = substr( $slide, -2 );
					$page64    = substr( $slide, 0, 2 );
					break;
			}
			$r[ $slide ] = array(
				'section' => ( $a64->decode( $section64 ) - 65 ),
				'page'    => ( $a64->decode( $page64 ) - 63 ),
			);
		}
		return $r;
	}

	/**
	 * Set data service name.
	 * This data service name will be used to create a PDO object for
	 * connecting to the database. If you would like to reuse an existing
	 * pdo object, use the setPdo function instead.
	 *
	 * @param String dsn A data service name as accepted by PDO.
	 */
	public function setDsn( $dsn ) {
		if ( $this->pdo ) {
			throw new Exception( "Can't set DSN, PDO already created" );
		}

		$this->dsn = $dsn;
	}

	/**
	 * Set pdo (Php Database Object) to use for the connection to the
	 * database.
	 *
	 * @param PDO pdo The PDO to use.
	 */
	public function setPdo( $pdo ) {
		$this->pdo = $pdo;
	}

	/**
	 * Get pdo, create if not created already.
	 */
	private function getPdo() {
		if ( ! $this->pdo ) {
			if ( ! $this->dsn ) {
				throw new Exception( 'No DSN or PDO set.' );
			}

			$this->pdo = new PDO( $this->dsn );
		}

		return $this->pdo;
	}

	/**
	 * Install database tables.
	 *
	 * 2019-08-16 Codeable/Paul Cohen
	 * Change all CREATE TABLE to CREATE TABLE IF NOT EXISTS for resume state database update with new state table
	 * See also isInstalled() for new state table check
	 * Note: Database must be InnoDB due to key size error issue
	 * See https://stackoverflow.com/questions/8746207/1071-specified-key-was-too-long-max-key-length-is-1000-bytes
	 */
	public function install() {
		$pdo = $this->getPdo();
		global $wpdb;

		// error_log("creating statements db");
		$r = (
			"CREATE TABLE IF NOT EXISTS {$this->tablePrefix}statements ( " .
				'  statementId VARCHAR(36) NOT NULL PRIMARY KEY, ' .
				'  statement TEXT, ' .
				'  stored_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ' .
				')'
		);

		$wpdb->query( $r );

		$valueIndexSpec = 'value';
		if ( $pdo->getAttribute( PDO::ATTR_DRIVER_NAME ) == 'mysql' ) {
			$valueIndexSpec = 'value(255)';
		}

		// error_log("creating statements_index db");
		$r = (
			"CREATE TABLE IF NOT EXISTS {$this->tablePrefix}statements_index ( " .
				'  type VARCHAR(20) NOT NULL, ' .
				'  value TEXT NOT NULL, ' .
				'  statementId VARCHAR(36) NOT NULL, ' .
				"  PRIMARY KEY (type, $valueIndexSpec, statementId) " .
				')'
		);

		$wpdb->query( $r );

		// error_log("creating statements_expand db");
		$r = (
			"CREATE TABLE IF NOT EXISTS {$this->tablePrefix}statements_expand ( " .
				'  id BIGINT(20) NOT NULL AUTO_INCREMENT, ' .
				'  statementId VARCHAR(36) NOT NULL, ' .
				'  actor_mbox VARCHAR(255) NULL, ' .
				'  verb_id VARCHAR(80) NOT NULL, ' .
				'  verb_display VARCHAR(20) NULL, ' .
				'  context_registration VARCHAR(36) NULL, ' .
				'  st_timestamp VARCHAR(30) NULL, ' .
				'  object_objecttype VARCHAR(36) NULL, ' .
				'  object_id VARCHAR(255) NULL, ' .
				'  object_definition_type VARCHAR(100) NULL, ' .
				'  object_definition_name_und VARCHAR(255) NULL, ' .
				'  course_name VARCHAR(255) NULL, ' .
				'  PRIMARY KEY (id) ' .
				')'
		);

		$wpdb->query( $r );

		/**
		 * 2019-08-12
		 * Codeable Paul Cohen
		 * Implement state API for Storyline resume functionality
		 */
		// error_log("creating statements_expand db");
		$r = (
			"CREATE TABLE IF NOT EXISTS {$this->tablePrefix}states ( " .
				'  id BIGINT(20) NOT NULL AUTO_INCREMENT, ' .
				'  user_name VARCHAR(60) NULL, ' .
				'  actor_mbox VARCHAR(255) NULL, ' .
				'  context_registration VARCHAR(36) NULL, ' .
				'  st_timestamp VARCHAR(30) NULL, ' .
				'  state_id VARCHAR(255) NULL, ' .
				'  activity_id VARCHAR(255) NULL, ' .
				'  state_data TEXT NOT NULL, ' .
				'  PRIMARY KEY (id) ' .
				')'
		);

		$wpdb->query( $r );

		$r = (
			"CREATE TABLE IF NOT EXISTS {$this->tablePrefix}courses ( " .
				'  id BIGINT(20) NOT NULL AUTO_INCREMENT, ' .
				'  course_name VARCHAR(255) NOT NULL, ' .
				'  active TINYINT NOT NULL, ' .
				'  uuid VARCHAR(36) NOT NULL, ' .
				'  PRIMARY KEY (id) ' .
				')'
		);

		$wpdb->query( $r );

		// id, id_course, actor_mbox, verb_id, context_registration, st_timestamp, status, score, course_name)
		// add statement_id to register last statement that caused a change in each row
		$r = (
			"CREATE TABLE IF NOT EXISTS {$this->tablePrefix}status ( " .
				'  id BIGINT(20) NOT NULL AUTO_INCREMENT, ' .
				'  id_course_fk BIGINT(20) NOT NULL, ' .
				'  uuid VARCHAR(36) NOT NULL, ' .
				'  user_name VARCHAR(60) NOT NULL, ' .
				'  actor_mbox VARCHAR(255) NULL, ' .
				'  verb_id VARCHAR(80) NOT NULL, ' .
				'  context_registration VARCHAR(36) NOT NULL, ' .
				'  st_timestamp VARCHAR(30) NULL, ' .
				'  status VARCHAR(50) NULL, ' .
				'  score SMALLINT NULL, ' .
				'  course_name VARCHAR(255) NULL, ' .
				'  statementId VARCHAR(36) NOT NULL, ' .
				'  PRIMARY KEY (id) ' .
				')'
		);

		$wpdb->query( $r );
	}

	/**
	 * Uninstall database tables.
	 */
	public function uninstall() {
		// $pdo = $this->getPdo();
		global $wpdb;

		$r = (
			"DROP TABLE IF EXISTS {$this->tablePrefix}statements"
		);

		$wpdb->query( $r );

		$r = (
			"DROP TABLE IF EXISTS {$this->tablePrefix}statements_index"
		);

		$wpdb->query( $r );
		/**
		 * 2019-08-12
		 * Codeable Paul Cohen
		 * Implement state API for Storyline resume functionality
		 */
		$r = (
			"DROP TABLE IF EXISTS {$this->tablePrefix}states"
		);

		$wpdb->query( $r );

		$r = (
			"DROP TABLE IF EXISTS {$this->tablePrefix}courses"
		);

		$wpdb->query( $r );

		$r = (
			"DROP TABLE IF EXISTS {$this->tablePrefix}status"
		);

		$wpdb->query( $r );

	}

	/**
	 *  GET statement result and actor
	 *
	 * @param string $statementObjectDefinitionUnd course name
	 * @return array $response = array('result'=>array( array( row items ) ) )
	 */
	public function getStatementResultsAndActors( $statementObjectDefinitionUnd ) {
		global $wpdb;
		$response = array( 'result' => array() );

		if ( trim( $statementObjectDefinitionUnd ) == '' ) {
			return $response;
		}

		// $pdo             = $this->getPdo();
		$expand_table    = $this->tablePrefix . 'statements_expand';
		$statement_table = $this->tablePrefix . 'statements';
		$params          = array(
			$statementObjectDefinitionUnd,
		);
		// $qs="SELECT * FROM $table_name WHERE object_definition_name_und = ?";
		// $qs="SELECT t1.*, t2.statement FROM $expand_table AS t1 INNER JOIN $statement_table AS t2 ON t1.statementId = t2.statementId WHERE t1.object_definition_name_und = ?";
		$qs                      = "SELECT t1.*, t2.statement FROM $expand_table AS t1 INNER JOIN $statement_table AS t2 ON t1.statementId = t2.statementId WHERE t1.course_name = '$statementObjectDefinitionUnd'";
		$results_statements_data = $wpdb->get_results( $qs, ARRAY_A );

		$res = array();
		foreach ( $results_statements_data as $row ) {
			$row['statement'] = json_decode( $row['statement'], true );
			$res[]            = $row;
		}
		$response['result'] = $res;
		return $response;
	}

	/**
	 *  GET unique course name list
	 *
	 *  @return array $response = array('result'=>array( array('_id')))
	 */
	public function getUniquieStatementDefinitionNameUnds() {
		global $wpdb;
		$response = array( 'result' => array() );
		// $pdo        = $this->getPdo();
		$table_name = $this->tablePrefix . 'statements_expand';

		$qs                      = "SELECT DISTINCT course_name FROM $table_name WHERE course_name !=''";
		$results_statements_data = $wpdb->get_results( $qs, ARRAY_A );

		$res = array();
		foreach ( $results_statements_data as $row ) {
			$res[] = array( '_id' => $row['course_name'] );
		}
		$response['result'] = $res;
		return $response;
	}

	/**
	 * GET statement result for an actor
	 *
	 * @param string $statementObjectDefinitionUnd course name CG: changed to be uuid/context_registration
	 * @param string $statementActorMbox actor's email
	 * @return array $response = array('result'=>array( array( row items ) ) )
	 */
	public function getStatementResultsForActor( $statementObjectDefinitionUnd, $statementActorMbox ) {
		global $wpdb;
		$response = array( 'result' => array() );

		if ( trim( $statementObjectDefinitionUnd ) == '' ) {
			return $response;
		}
		if ( trim( $statementActorMbox ) == '' ) {
			return $response;
		}

		// $pdo             = $this->getPdo();
		$expand_table    = $this->tablePrefix . 'statements_expand';
		$statement_table = $this->tablePrefix . 'statements';
		/*
		$params = array(
			'http://adlnet.gov/expapi/activities/course',
			$statementObjectDefinitionUnd,
			'mailto:'.$statementActorMbox
		);
		*/
		// $qs="SELECT * FROM $table_name WHERE object_definition_type = ? AND object_definition_name_und = ? AND actor_mbox = ?";

		// $qs="SELECT t1.*, t2.statement FROM $expand_table AS t1 INNER JOIN $statement_table AS t2 ON t1.statementId = t2.statementId WHERE t1.object_definition_type = ? AND t1.object_definition_name_und = ? AND t1.actor_mbox = ?";
		$param_mail = 'mailto:' . $statementActorMbox;
		$qs         = "SELECT t1.*, t2.statement FROM $expand_table AS t1 INNER JOIN $statement_table AS t2 ON t1.statementId = t2.statementId WHERE t1.context_registration = '$statementObjectDefinitionUnd' AND t1.actor_mbox = '$param_mail'";

		$results_statements_data = $wpdb->get_results( $qs, ARRAY_A );

		$res = array();
		foreach ( $results_statements_data as $row ) {
			$row['statement'] = json_decode( $row['statement'], true );
			$res[]            = $row;
		}
		$response['result'] = $res;
		return $response;
	}

	/**
	 * GET statement result for an actor
	 *
	 * @param string $registrationId
	 * @param string $statementActorMbox actor's email
	 * @return array $response = array('result'=>array( array( row items ) ) )
	 */
	public function getAnswersForRegistration( $registrationId, $statementActorMbox ) {
		global $wpdb;
		$response = array( 'result' => array() );

		if ( trim( $registrationId ) == '' ) {
			return $response;
		}
		if ( trim( $statementActorMbox ) == '' ) {
			return $response;
		}

		// $pdo             = $this->getPdo();
		$expand_table    = $this->tablePrefix . 'statements_expand';
		$statement_table = $this->tablePrefix . 'statements';
		$param_mail      = 'mailto:' . $statementActorMbox;

		// $qs="SELECT * FROM $table_name WHERE context_registration = ? AND verb_id = ? AND actor_mbox = ?";
		$qs = "SELECT t1.*, t2.statement FROM $expand_table AS t1 INNER JOIN $statement_table AS t2 ON t1.statementId = t2.statementId WHERE t1.context_registration = '$registrationId' AND t1.verb_id = 'http://adlnet.gov/expapi/verbs/answered' AND t1.actor_mbox = '$param_mail'";

		$results_statements_data = $wpdb->get_results( $qs, ARRAY_A );

		$res = array();

		foreach ( $results_statements_data as $row ) {
			$row['statement'] = json_decode( $row['statement'], true );
			$res[]            = $row;
		}

		$response['result'] = $res;
		return $response;
	}
	/**
	 * Return first array value , so no need to name
	 */
	private function getfirstValue( $array ) {
		   $r = '';
		if ( is_array( $array ) ) {
			$first_key = array_key_first( $array );
		}
		if ( $first_key ) {
			$r = $array[ $first_key ];
		}

		return $r;
	}
}//end class
