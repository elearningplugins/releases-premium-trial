var articulatejq = jQuery.noConflict();
articulatejq(document).ready(function() {

    if (document.addEventListener) {
        document.addEventListener('webkitfullscreenchange', exitHandler, false);
        document.addEventListener('mozfullscreenchange', exitHandler, false);
        document.addEventListener('fullscreenchange', exitHandler, false);
        document.addEventListener('MSFullscreenChange', exitHandler, false);
    }

	function exitHandler() {
		if (!document.webkitIsFullScreen && !document.mozFullScreen && !document.msFullscreenElement) {
			articulatejq( 'html, body, .articulate-iframe' ).removeClass( 'articulate-fs-on' );
		}
	}

	function requestFullScreen(element) {
		// Supports most browsers and their versions.
		var requestMethod = element.requestFullScreen || element.webkitRequestFullScreen || element.mozRequestFullScreen || element.msRequestFullscreen;

		if (requestMethod) { // Native full screen.
			requestMethod.call(element);
		} else if (typeof window.ActiveXObject !== "undefined") { // Older IE.
			var wscript = new ActiveXObject("WScript.Shell");
			if (wscript !== null) {
				wscript.SendKeys("{F11}");
			}
		}
	}

	function makeFullScreen( id ) {
		articulatejq( 'html, body, #' + id + '.articulate-iframe' ).addClass( 'articulate-fs-on' );
		var elem = document.body;
		requestFullScreen(elem);
	}

	articulatejq( document ).on( 'click', '.articulate-fs', function( event ) {
		event.preventDefault();
		var id = articulatejq( this ).attr( 'data-id' );
		makeFullScreen( id );
		return false;
	} );

});

