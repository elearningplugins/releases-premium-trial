(function($){
	$(document).ready(function() { 	
		$('select.materialize_me').formSelect();
		M.updateTextFields();
	});
})(jQuery);