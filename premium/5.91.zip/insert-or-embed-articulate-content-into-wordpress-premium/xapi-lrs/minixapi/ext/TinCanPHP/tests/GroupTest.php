<?php
/*
	Copyright 2014 Rustici Software

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.
*/

namespace TinCanTest;

use TinCan\Agent;
use TinCan\AgentAccount;
use TinCan\Group;

class GroupTest extends \PHPUnit_Framework_TestCase {
	use TestCompareWithSignatureTrait;

	public function testInstantiation() {
		$obj = new Group();
		$this->assertInstanceOf( 'TinCan\Agent', $obj );
		$this->assertInstanceOf( 'TinCan\Group', $obj );
		$this->assertAttributeEquals( array(), 'member', $obj, 'member empty array' );
	}

	// TODO: need to loop possible configs
	public function testFromJSONInstantiations() {
		$obj = Group::fromJSON( '{"mbox":"' . COMMON_GROUP_MBOX . '", "member":[{"mbox":"' . COMMON_MBOX . '"}]}' );
		$this->assertInstanceOf( 'TinCan\Group', $obj );
		$this->assertSame( COMMON_GROUP_MBOX, $obj->getMbox(), 'mbox value' );
		$this->assertEquals( array( new Agent( array( 'mbox' => COMMON_MBOX ) ) ), $obj->getMember(), 'member list' );
	}

	// TODO: need to loop versions
	public function testAsVersionMbox() {
		$args = array(
			'mbox' => COMMON_GROUP_MBOX,
		);

		$obj       = Group::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$args['objectType'] = 'Group';

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testAsVersionMboxSha1() {
		$args = array(
			'mbox_sha1sum' => COMMON_GROUP_MBOX_SHA1,
		);

		$obj       = Group::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$args['objectType'] = 'Group';

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testAsVersionAccount() {
		$args = array(
			'account' => array(
				'name'     => COMMON_ACCT_NAME,
				'homePage' => COMMON_ACCT_HOMEPAGE,
			),
		);

		$obj       = Group::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$args['objectType'] = 'Group';

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testAsVersionAccountEmptyStrings() {
		$args = array(
			'account' => array(
				'name'     => '',
				'homePage' => '',
			),
		);

		$obj       = Group::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$args['objectType'] = 'Group';

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testAsVersionEmptyAccount() {
		$args = array(
			'account' => array(),
		);

		$obj       = Group::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$args['objectType'] = 'Group';
		unset( $args['account'] );

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testAsVersionEmptyMember() {
		$args = array(
			'member' => array(),
		);

		$obj       = Group::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$args['objectType'] = 'Group';
		unset( $args['member'] );

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testAsVersionEmpty() {
		$args = array();

		$obj       = Group::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$args['objectType'] = 'Group';

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testAddMember() {
		$common_agent = new Agent( array( 'mbox' => COMMON_MBOX ) );

		$obj = new Group();

		$obj->addMember( array( 'mbox' => COMMON_MBOX ) );
		$this->assertEquals( array( $common_agent ), $obj->getMember(), 'member list create Agent' );

		$obj->setMember( array() );

		$obj->addMember( $common_agent );
		$this->assertEquals( array( $common_agent ), $obj->getMember(), 'member list existing Agent' );

		$versioned = $obj->asVersion( '1.0.0' );
		$this->assertSame( $versioned['member'][0], $common_agent->asVersion( '1.0.0' ) );
	}

	public function testCompareWithSignature() {
		$name  = 'Test Group Name';
		$acct1 = new AgentAccount(
			array(
				'homePage' => COMMON_ACCT_HOMEPAGE,
				'name'     => COMMON_ACCT_NAME,
			)
		);
		$acct2 = new AgentAccount(
			array(
				'homePage' => COMMON_ACCT_HOMEPAGE,
				'name'     => COMMON_ACCT_NAME . '-diff',
			)
		);

		$member1 = new Agent(
			array( 'mbox' => COMMON_MBOX )
		);
		$member2 = new Agent(
			array( 'account' => $acct1 )
		);

		$cases = array(
			array(
				'description' => 'all null',
				'objArgs'     => array(),
			),
			array(
				'description' => 'mbox',
				'objArgs'     => array( 'mbox' => COMMON_GROUP_MBOX ),
			),
			array(
				'description' => 'mbox_sha1sum',
				'objArgs'     => array( 'mbox_sha1sum' => COMMON_GROUP_MBOX_SHA1 ),
			),
			array(
				'description' => 'openid',
				'objArgs'     => array( 'openid' => COMMON_OPENID ),
			),
			array(
				'description' => 'account',
				'objArgs'     => array( 'account' => $acct1 ),
			),
			array(
				'description' => 'mbox with name',
				'objArgs'     => array(
					'mbox' => COMMON_GROUP_MBOX,
					'name' => $name,
				),
			),
			array(
				'description' => 'mbox_sha1sum with name',
				'objArgs'     => array(
					'mbox_sha1sum' => COMMON_GROUP_MBOX_SHA1,
					'name'         => $name,
				),
			),
			array(
				'description' => 'openid with name',
				'objArgs'     => array(
					'openid' => COMMON_OPENID,
					'name'   => $name,
				),
			),
			array(
				'description' => 'account with name',
				'objArgs'     => array(
					'account' => $acct1,
					'name'    => $name,
				),
			),
			array(
				'description' => 'mbox with mismatch name',
				'objArgs'     => array(
					'mbox' => COMMON_GROUP_MBOX,
					'name' => $name,
				),
				'sigArgs'     => array(
					'mbox' => COMMON_GROUP_MBOX,
					'name' => $name . ' diff',
				),
			),
			array(
				'description' => 'mbox_sha1sum with mismatch name',
				'objArgs'     => array(
					'mbox_sha1sum' => COMMON_GROUP_MBOX_SHA1,
					'name'         => $name,
				),
				'sigArgs'     => array(
					'mbox_sha1sum' => COMMON_GROUP_MBOX_SHA1,
					'name'         => $name . ' diff',
				),
			),
			array(
				'description' => 'openid with mismatch name',
				'objArgs'     => array(
					'openid' => COMMON_OPENID,
					'name'   => $name,
				),
				'sigArgs'     => array(
					'openid' => COMMON_OPENID,
					'name'   => $name . ' diff',
				),
			),
			array(
				'description' => 'account with mismatch name',
				'objArgs'     => array(
					'account' => $acct1,
					'name'    => $name,
				),
				'sigArgs'     => array(
					'account' => $acct1,
					'name'    => $name . ' diff',
				),
			),
			array(
				'description' => 'mbox only: mismatch',
				'objArgs'     => array( 'mbox' => COMMON_GROUP_MBOX ),
				'sigArgs'     => array( 'mbox' => 'diff-' . COMMON_GROUP_MBOX ),
				'reason'      => 'Comparison of mbox failed: value is not the same',
			),
			array(
				'description' => 'mbox_sha1sum only: mismatch',
				'objArgs'     => array( 'mbox_sha1sum' => COMMON_GROUP_MBOX_SHA1 ),
				'sigArgs'     => array( 'mbox_sha1sum' => 'diff-' . COMMON_GROUP_MBOX_SHA1 ),
				'reason'      => 'Comparison of mbox_sha1sum failed: value is not the same',
			),
			array(
				'description' => 'openid only: mismatch',
				'objArgs'     => array( 'openid' => COMMON_OPENID ),
				'sigArgs'     => array( 'openid' => COMMON_OPENID . 'diff/' ),
				'reason'      => 'Comparison of openid failed: value is not the same',
			),
			array(
				'description' => 'account only: mismatch',
				'objArgs'     => array( 'account' => $acct1 ),
				'sigArgs'     => array( 'account' => $acct2 ),
				'reason'      => 'Comparison of account failed: Comparison of name failed: value is not the same',
			),

			//
			// special cases where we can try to equate an mbox and an mbox SHA1 sum
			//
			array(
				'description' => 'this.mbox to signature.mbox_sha1sum',
				'objArgs'     => array( 'mbox' => COMMON_GROUP_MBOX ),
				'sigArgs'     => array( 'mbox_sha1sum' => COMMON_GROUP_MBOX_SHA1 ),
			),
			array(
				'description' => 'this.mbox_sha1sum to signature.mbox',
				'objArgs'     => array( 'mbox_sha1sum' => COMMON_GROUP_MBOX_SHA1 ),
				'sigArgs'     => array( 'mbox' => COMMON_GROUP_MBOX ),
			),
			array(
				'description' => 'this.mbox to signature.mbox_sha1sum non-matching',
				'objArgs'     => array( 'mbox' => COMMON_GROUP_MBOX ),
				'sigArgs'     => array( 'mbox_sha1sum' => COMMON_GROUP_MBOX_SHA1 . '-diff' ),
				'reason'      => 'Comparison of this.mbox to signature.mbox_sha1sum failed: no match',
			),
			array(
				'description' => 'this.mbox_sha1sum to signature.mbox non-matching',
				'objArgs'     => array( 'mbox_sha1sum' => COMMON_GROUP_MBOX_SHA1 . '-diff' ),
				'sigArgs'     => array( 'mbox' => COMMON_GROUP_MBOX ),
				'reason'      => 'Comparison of this.mbox_sha1sum to signature.mbox failed: no match',
			),

			// special cases for unidentified groups, member list needs to match
			array(
				'description' => 'anonymous match: empty member list',
				'objArgs'     => array( 'member' => array() ),
			),
			array(
				'description' => 'anonymous match: single member',
				'objArgs'     => array( 'member' => array( $member1 ) ),
			),
			array(
				'description' => 'anonymous match: multiple members',
				'objArgs'     => array( 'member' => array( $member1, $member2 ) ),
			),
			array(
				'description' => 'anonymous non-match: sig member missing (empty)',
				'objArgs'     => array( 'member' => array( $member1 ) ),
				'sigArgs'     => array( 'member' => array() ),
				'reason'      => 'Comparison of member list failed: array lengths differ',
			),
			array(
				'description' => 'anonymous non-match: this member missing (empty)',
				'objArgs'     => array( 'member' => array() ),
				'sigArgs'     => array( 'member' => array( $member1 ) ),
				'reason'      => 'Comparison of member list failed: array lengths differ',
			),
			array(
				'description' => 'anonymous non-match: sig member missing',
				'objArgs'     => array( 'member' => array( $member1, $member2 ) ),
				'sigArgs'     => array( 'member' => array( $member1 ) ),
				'reason'      => 'Comparison of member list failed: array lengths differ',
			),
			array(
				'description' => 'anonymous non-match: this member missing',
				'objArgs'     => array( 'member' => array( $member1 ) ),
				'sigArgs'     => array( 'member' => array( $member1, $member2 ) ),
				'reason'      => 'Comparison of member list failed: array lengths differ',
			),
			array(
				'description' => 'anonymous non-match: different order',
				'objArgs'     => array( 'member' => array( $member2, $member1 ) ),
				'sigArgs'     => array( 'member' => array( $member1, $member2 ) ),
				'reason'      => 'Comparison of member 0 failed: Comparison of mbox failed: value is not the same',
			),
		);
		$this->runSignatureCases( 'TinCan\Group', $cases );
	}
}
