<?php
/*
	Copyright 2014 Rustici Software

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.
*/

namespace TinCanTest;

use TinCan\Verb;

class VerbTest extends \PHPUnit_Framework_TestCase {
	use TestCompareWithSignatureTrait;

	private static $DISPLAY;

	public static function setUpBeforeClass() {
		self::$DISPLAY = array(
			'en-US' => 'experienced',
			'en-GB' => 'experienced',
			'es'    => 'experimentado',
			'fr'    => 'expérimenté',
			'it'    => 'esperto',
		);
	}

	public function testInstantiation() {
		$obj = new Verb();
		$this->assertInstanceOf( 'TinCan\Verb', $obj );
		$this->assertAttributeEmpty( 'id', $obj, 'id empty' );
		$this->assertAttributeInstanceOf( 'TinCan\LanguageMap', 'display', $obj, 'display is LanguageMap' );
	}

	public function testFromJSONInvalidNull() {
		$this->setExpectedException( 'TinCan\JSONParseErrorException' );
		$obj = Verb::fromJSON( null );
	}

	public function testFromJSONInvalidEmptyString() {
		$this->setExpectedException( 'TinCan\JSONParseErrorException' );
		$obj = Verb::fromJSON( '' );
	}

	public function testFromJSONInvalidMalformed() {
		$this->setExpectedException( 'TinCan\JSONParseErrorException' );
		$obj = Verb::fromJSON( '{id:"some value"}' );
	}

	public function testFromJSONIDOnly() {
		$obj = Verb::fromJSON( '{"id":"' . COMMON_VERB_ID . '"}' );
		$this->assertInstanceOf( 'TinCan\Verb', $obj );
		$this->assertAttributeEquals( COMMON_VERB_ID, 'id', $obj, 'id matches' );
		$this->assertTrue( $obj->getDisplay()->isEmpty(), 'display empty' );
	}

	// TODO: need to loop versions
	public function testAsVersion() {
		$args = array(
			'id'      => COMMON_VERB_ID,
			'display' => self::$DISPLAY,
		);

		$obj       = Verb::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$this->assertEquals( $versioned, $args, 'serialized version matches original' );
	}

	public function testAsVersionEmpty() {
		$args = array();

		$obj       = Verb::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$this->assertEquals( $versioned, $args, 'serialized version matches original' );
	}

	public function testAsVersionEmptyLanguageMap() {
		$args = array( 'display' => array() );

		$obj       = Verb::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		unset( $args['display'] );

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testAsVersionEmptyStringInLanguageMap() {
		$args = array( 'display' => array( 'en' => '' ) );

		$obj       = Verb::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$this->assertEquals( $versioned, $args, 'serialized version matches original' );
	}

	public function testCompareWithSignature() {
		$full     = array(
			'id'      => COMMON_VERB_ID,
			'display' => self::$DISPLAY,
		);
		$display2 = array_replace( self::$DISPLAY, array( 'en-US' => 'not experienced' ) );
		$cases    = array(
			array(
				'description' => 'all null',
				'objArgs'     => array(),
			),
			array(
				'description' => 'id',
				'objArgs'     => array( 'id' => COMMON_VERB_ID ),
			),
			array(
				'description' => 'display',
				'objArgs'     => array( 'display' => self::$DISPLAY ),
			),
			array(
				'description' => 'all',
				'objArgs'     => $full,
			),

			//
			// display is not matched for signature purposes because it
			// is not supposed to affect the meaning of the statement
			//
			array(
				'description' => 'display only: mismatch (allowed)',
				'objArgs'     => array( 'display' => self::$DISPLAY ),
				'sigArgs'     => array( 'display' => $display2 ),
			),
			array(
				'description' => 'full: display mismatch (allowed)',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'display' => $display2 ) ),
			),

			array(
				'description' => 'id only: mismatch',
				'objArgs'     => array( 'id' => COMMON_VERB_ID ),
				'sigArgs'     => array( 'id' => COMMON_VERB_ID . '/invalid' ),
				'reason'      => 'Comparison of id failed: value is not the same',
			),
			array(
				'description' => 'full: id mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'id' => COMMON_VERB_ID . '/invalid' ) ),
				'reason'      => 'Comparison of id failed: value is not the same',
			),
		);
		$this->runSignatureCases( 'TinCan\Verb', $cases );
	}
}
