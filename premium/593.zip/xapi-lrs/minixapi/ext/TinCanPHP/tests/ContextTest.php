<?php
/*
	Copyright 2014 Rustici Software

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.
*/

namespace TinCanTest;

use TinCan\Agent;
use TinCan\Context;
use TinCan\ContextActivities;
use TinCan\Extensions;
use TinCan\Group;
use TinCan\StatementRef;
use TinCan\Util;

class ContextTest extends \PHPUnit_Framework_TestCase {
	use TestCompareWithSignatureTrait;

	private $emptyProperties = array(
		'registration',
		'revision',
		'platform',
		'language',
	);

	private $nonEmptyProperties = array(
		'contextActivities',
		'extensions',
	);

	public function testInstantiation() {
		$obj = new Context();
		$this->assertInstanceOf( 'TinCan\Context', $obj );
		foreach ( $this->emptyProperties as $property ) {
			$this->assertAttributeEmpty( $property, $obj, "$property empty" );
		}
		foreach ( $this->nonEmptyProperties as $property ) {
			$this->assertAttributeNotEmpty( $property, $obj, "$property not empty" );
		}
	}

	public function testUsesArraySetterTrait() {
		$this->assertContains( 'TinCan\ArraySetterTrait', class_uses( 'TinCan\Context' ) );
	}

	public function testUsesFromJSONTrait() {
		$this->assertContains( 'TinCan\FromJSONTrait', class_uses( 'TinCan\Context' ) );
	}

	public function testUsesAsVersionTrait() {
		$this->assertContains( 'TinCan\AsVersionTrait', class_uses( 'TinCan\Context' ) );
	}

	/*
	// TODO: need to loop possible configs
	public function testFromJSONInstantiations() {
		$obj = Context::fromJSON('{"mbox":"' . COMMON_GROUP_MBOX . '", "member":[{"mbox":"' . COMMON_MBOX . '"}]}');
		$this->assertInstanceOf('TinCan\Context', $obj);
		$this->assertSame(COMMON_GROUP_MBOX, $obj->getMbox(), 'mbox value');
		$this->assertEquals([['mbox' => COMMON_MBOX]], $obj->getMember(), 'member list');
	}
	*/

	public function testAsVersion() {
		$args                                        = array(
			'registration'      => Util::getUUID(),
			'instructor'        => array(
				'name' => 'test agent',
			),
			'team'              => array(
				'name' => 'test group',
			),
			'contextActivities' => array(
				'category' => array(
					array(
						'id' => 'test category',
					),
				),
			),
			'revision'          => 'test revision',
			'platform'          => 'test platform',
			'language'          => 'test language',
			'statement'         => array(
				'id' => Util::getUUID(),
			),
			'extensions'        => array(),
		);
		$args['extensions'][ COMMON_EXTENSION_ID_1 ] = 'test';

		$obj       = Context::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$args['instructor']['objectType']                       = 'Agent';
		$args['team']['objectType']                             = 'Group';
		$args['contextActivities']['category'][0]['objectType'] = 'Activity';
		$args['statement']['objectType']                        = 'StatementRef';

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testAsVersionEmpty() {
		$args = array();

		$obj       = Context::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$this->assertEquals( $versioned, $args, 'serialized version matches original' );
	}

	public function testAsVersionEmptyLists() {
		$args = array(
			'contextActivities' => array(
				'category' => array(),
			),
			'extensions'        => array(),
		);

		$obj       = Context::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		unset( $args['contextActivities'] );
		unset( $args['extensions'] );

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testSetInstructor() {
		$common_agent_cfg = array( 'mbox' => COMMON_MBOX );
		$common_agent     = new Agent( $common_agent_cfg );
		$common_group_cfg = array(
			'mbox'       => COMMON_MBOX,
			'objectType' => 'Group',
		);
		$common_group     = new Group( $common_agent_cfg );

		$obj = new Context();

		$obj->setInstructor( $common_agent_cfg );
		$this->assertEquals( $common_agent, $obj->getInstructor(), 'agent config' );

		$obj->setInstructor( null );
		$this->assertEmpty( $obj->getInstructor(), 'empty' );
	}

	public function testCompareWithSignature() {
		$registration1      = Util::getUUID();
		$registration2      = Util::getUUID();
		$instructor1        = new Agent(
			array( 'mbox' => COMMON_MBOX )
		);
		$instructor2        = new Agent(
			array(
				'account' => array(
					'homePage' => COMMON_ACCT_HOMEPAGE,
					'name'     => COMMON_ACCT_NAME,
				),
			)
		);
		$team1              = new Agent(
			array( 'mbox' => COMMON_MBOX )
		);
		$team2              = new Agent(
			array(
				'account' => array(
					'homePage' => COMMON_ACCT_HOMEPAGE,
					'name'     => COMMON_ACCT_NAME,
				),
			)
		);
		$contextActivities1 = new ContextActivities(
			array( 'parent' => array( COMMON_ACTIVITY_ID ) )
		);
		$contextActivities2 = new ContextActivities(
			array( 'parent' => array( COMMON_ACTIVITY_ID . '/parent' ) ),
			array( 'grouping' => array( COMMON_ACTIVITY_ID ) )
		);
		$ref1               = new StatementRef(
			array( 'id' => Util::getUUID() )
		);
		$ref2               = new StatementRef(
			array( 'id' => Util::getUUID() )
		);
		$extensions1        = new Extensions(
			array(
				COMMON_EXTENSION_ID_1 => 'test1',
				COMMON_EXTENSION_ID_2 => 'test2',
			)
		);
		$extensions2        = new Extensions(
			array(
				COMMON_EXTENSION_ID_1 => 'test1',
			)
		);

		$full = array(
			'registration'      => $registration1,
			'instructor'        => $instructor1,
			'team'              => $team1,
			'contextActivities' => $contextActivities1,
			'revision'          => '1',
			'platform'          => 'mobile',
			'language'          => 'en-US',
			'statement'         => $ref1,
			'extensions'        => $extensions1,
		);

		$cases = array(
			array(
				'description' => 'all null',
				'objArgs'     => array(),
			),
			array(
				'description' => 'registration',
				'objArgs'     => array( 'registration' => $registration1 ),
			),
			array(
				'description' => 'instructor',
				'objArgs'     => array( 'instructor' => $instructor1 ),
			),
			array(
				'description' => 'team',
				'objArgs'     => array( 'team' => $team1 ),
			),
			array(
				'description' => 'contextActivities',
				'objArgs'     => array( 'contextActivities' => $contextActivities1 ),
			),
			array(
				'description' => 'revision',
				'objArgs'     => array( 'revision' => '1' ),
			),
			array(
				'description' => 'platform',
				'objArgs'     => array( 'platform' => 'mobile' ),
			),
			array(
				'description' => 'language',
				'objArgs'     => array( 'language' => 'en-US' ),
			),
			array(
				'description' => 'statement',
				'objArgs'     => array( 'statement' => $ref1 ),
			),
			array(
				'description' => 'extensions',
				'objArgs'     => array( 'extensions' => $extensions1 ),
			),
			array(
				'description' => 'all',
				'objArgs'     => $full,
			),
			array(
				'description' => 'registration only: mismatch',
				'objArgs'     => array( 'registration' => $registration1 ),
				'sigArgs'     => array( 'registration' => $registration2 ),
				'reason'      => 'Comparison of registration failed: value is not the same',
			),
			array(
				'description' => 'instructor only: mismatch',
				'objArgs'     => array( 'instructor' => $instructor1 ),
				'sigArgs'     => array( 'instructor' => $instructor2 ),
				'reason'      => 'Comparison of instructor failed: Comparison of mbox failed: value is not the same',
			),
			array(
				'description' => 'team only: mismatch',
				'objArgs'     => array( 'team' => $team1 ),
				'sigArgs'     => array( 'team' => $team2 ),
				'reason'      => 'Comparison of team failed: Comparison of mbox failed: value is not the same',
			),
			array(
				'description' => 'contextActivities only: mismatch',
				'objArgs'     => array( 'contextActivities' => $contextActivities1 ),
				'sigArgs'     => array( 'contextActivities' => $contextActivities2 ),
				'reason'      => 'Comparison of contextActivities failed: Comparison of parent failed: array lengths differ',
			),
			array(
				'description' => 'revision only: mismatch',
				'objArgs'     => array( 'revision' => '1' ),
				'sigArgs'     => array( 'revision' => '2' ),
				'reason'      => 'Comparison of revision failed: value is not the same',
			),
			array(
				'description' => 'platform only: mismatch',
				'objArgs'     => array( 'platform' => 'mobile' ),
				'sigArgs'     => array( 'platform' => 'desktop' ),
				'reason'      => 'Comparison of platform failed: value is not the same',
			),
			array(
				'description' => 'language only: mismatch',
				'objArgs'     => array( 'language' => 'en-US' ),
				'sigArgs'     => array( 'language' => 'en-GB' ),
				'reason'      => 'Comparison of language failed: value is not the same',
			),
			array(
				'description' => 'statement only: mismatch',
				'objArgs'     => array( 'statement' => $ref1 ),
				'sigArgs'     => array( 'statement' => $ref2 ),
				'reason'      => 'Comparison of statement failed: Comparison of id failed: value is not the same',
			),
			array(
				'description' => 'extensions only: mismatch',
				'objArgs'     => array( 'extensions' => $extensions1 ),
				'sigArgs'     => array( 'extensions' => $extensions2 ),
				'reason'      => 'Comparison of extensions failed: http://id.tincanapi.com/extension/location not in signature',
			),
			array(
				'description' => 'full: registration mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'registration' => $registration2 ) ),
				'reason'      => 'Comparison of registration failed: value is not the same',
			),
			array(
				'description' => 'full: instructor mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'instructor' => $instructor2 ) ),
				'reason'      => 'Comparison of instructor failed: Comparison of mbox failed: value is not the same',
			),
			array(
				'description' => 'full: team mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'team' => $team2 ) ),
				'reason'      => 'Comparison of team failed: Comparison of mbox failed: value is not the same',
			),
			array(
				'description' => 'full: contextActivities mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'contextActivities' => $contextActivities2 ) ),
				'reason'      => 'Comparison of contextActivities failed: Comparison of parent failed: array lengths differ',
			),
			array(
				'description' => 'full: revision mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'revision' => '2' ) ),
				'reason'      => 'Comparison of revision failed: value is not the same',
			),
			array(
				'description' => 'full: platform mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'platform' => 'desktop' ) ),
				'reason'      => 'Comparison of platform failed: value is not the same',
			),
			array(
				'description' => 'full: language mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'language' => 'en-GB' ) ),
				'reason'      => 'Comparison of language failed: value is not the same',
			),
			array(
				'description' => 'full: statement mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'statement' => $ref2 ) ),
				'reason'      => 'Comparison of statement failed: Comparison of id failed: value is not the same',
			),
			array(
				'description' => 'full: extensions mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'extensions' => $extensions2 ) ),
				'reason'      => 'Comparison of extensions failed: http://id.tincanapi.com/extension/location not in signature',
			),
		);
		$this->runSignatureCases( 'TinCan\Context', $cases );
	}

	public function testSetInstructorConvertToGroup() {
		$obj = new Context();
		$obj->setInstructor(
			array(
				'objectType' => 'Group',
			)
		);
		$this->assertInstanceOf( 'TinCan\Group', $obj->getInstructor() );
	}

	public function testSetRegistrationInvalidArgumentException() {
		$this->setExpectedException(
			'InvalidArgumentException',
			'arg1 must be a UUID'
		);
		$obj = new Context();
		$obj->setRegistration( '232....3.3..3./2/2/1m3m3m3' );
	}
}
