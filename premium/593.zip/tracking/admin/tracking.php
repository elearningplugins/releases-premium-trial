<?php
$iea_tracking_admin = new iea_tracking_admin();
add_action( 'iea_admin_menu', array( $iea_tracking_admin, 'menu' ), 20 );
add_action( 'admin_init', array( $iea_tracking_admin, 'save' ) );
add_action( 'admin_enqueue_scripts', array( $iea_tracking_admin, 'styles' ), 500 );

class iea_tracking_admin {

	function styles() {
		global $hook_suffix;

		if ( empty( $hook_suffix ) || ! strstr( $hook_suffix, 'articulate' ) ) {
			return;
		}

		wp_enqueue_style( 'materialize-css', articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'css/materialize.css' );
		wp_enqueue_style( 'admin-css', articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'css/articulate.css' );
	}

	function menu() {
		add_submenu_page( 'articulate_content', 'Reports', 'Reports', 'manage_options', 'articulate-settings-tracking', array( $this, 'tracking' ) );
		add_submenu_page( 'articulate_content', 'Statement Viewer', 'Statement Viewer', 'manage_options', 'articulate-statement-viewer', array( $this, 'statement_tracker' ) );
	}

	function save() {
		if ( isset( $_POST['iea_save'] ) ) {
			if ( $_POST['iea_save'] == 'api_key' ) {
				update_option( 'iea-tracking-api-key', $_POST['iea-tracking-api-key'] );
			}
		}
	}

	function api() {
		$apiKeyForm = new ApiKeyForm();
		$apiKeyForm->showForm();
	}

	function tracking() {
		$tracking = new TrackingReports();
		$tracking->tracking();
		$this->addStyles();
	}

	function statement_tracker() {
		$statement_tracker = new StatementsViewer();
		$statement_tracker->statement_tracker();
		$this->addStyles();
	}

	private function addStyles() {

	}
}

require_once 'statementsviewer.php';
require_once 'trackingreports.php';
require_once 'apikeyform.php';
