<?php
/*
	Copyright 2014 Rustici Software

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.
*/

namespace TinCanTest;

use TinCan\Activity;
use TinCan\ContextActivities;

class ContextActivitiesTest extends \PHPUnit_Framework_TestCase {
	use TestCompareWithSignatureTrait;

	private static $listProps           = array( 'category', 'parent', 'grouping', 'other' );
	private static $common_activity_cfg = array(
		'id' => COMMON_ACTIVITY_ID,
	);

	public function testInstantiation() {
		$obj = new ContextActivities();
		$this->assertInstanceOf( 'TinCan\ContextActivities', $obj );
		foreach ( self::$listProps as $k ) {
			$this->assertAttributeEquals( array(), $k, $obj, "$k empty array" );
		}
	}

	public function testUsesArraySetterTrait() {
		$this->assertContains( 'TinCan\ArraySetterTrait', class_uses( 'TinCan\ContextActivities' ) );
	}

	public function testUsesFromJSONTrait() {
		$this->assertContains( 'TinCan\FromJSONTrait', class_uses( 'TinCan\ContextActivities' ) );
	}

	public function testUsesAsVersionTrait() {
		$this->assertContains( 'TinCan\AsVersionTrait', class_uses( 'TinCan\ContextActivities' ) );
	}

	public function testFromJSONInstantiations() {
		$common_activity = new Activity( self::$common_activity_cfg );

		$all_json = array();
		foreach ( self::$listProps as $k ) {
			$getMethod = 'get' . ucfirst( $k );

			$prop_json = '"' . $k . '":[' . json_encode( $common_activity->asVersion( '1.0.0' ) ) . ']';

			array_push( $all_json, $prop_json );

			$obj = ContextActivities::fromJSON( '{' . $prop_json . '}' );

			$this->assertInstanceOf( 'TinCan\ContextActivities', $obj );
			$this->assertEquals( array( $common_activity ), $obj->$getMethod(), "$k list" );
		}

		$obj = ContextActivities::fromJSON( '{' . join( ',', $all_json ) . '}' );

		$this->assertInstanceOf( 'TinCan\ContextActivities', $obj );
		$this->assertEquals( array( $common_activity ), $obj->getCategory(), 'all props: category list' );
		$this->assertEquals( array( $common_activity ), $obj->getParent(), 'all props: parent list' );
		$this->assertEquals( array( $common_activity ), $obj->getGrouping(), 'all props: grouping list' );
		$this->assertEquals( array( $common_activity ), $obj->getOther(), 'all props: other list' );
	}

	// TODO: need to loop versions
	public function testAsVersionWithSingleList() {
		$keys = array( 'category', 'parent', 'grouping', 'other' );
		foreach ( $keys as $k ) {
			$args       = array();
			$args[ $k ] = array( self::$common_activity_cfg );

			$obj       = ContextActivities::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
			$versioned = $obj->asVersion( '1.0.0' );

			$args[ $k ][0]['objectType'] = 'Activity';

			$this->assertEquals( $versioned, $args, 'serialized version matches original' );

			unset( $args[ $k ][0]['objectType'] );
		}
	}

	public function testAsVersionEmpty() {
		$args = array();

		$obj       = ContextActivities::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$this->assertEquals( $versioned, $args, 'serialized version matches original' );
	}

	public function testAsVersionWithEmptyList() {
		$keys = array( 'category', 'parent', 'grouping', 'other' );
		foreach ( $keys as $k ) {
			$args       = array();
			$args[ $k ] = array();

			$obj       = ContextActivities::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
			$versioned = $obj->asVersion( '1.0.0' );

			unset( $args[ $k ] );

			$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
		}
	}

	public function testListSetters() {
		$common_activity = new Activity( self::$common_activity_cfg );

		foreach ( self::$listProps as $k ) {
			$setMethod = 'set' . ucfirst( $k );
			$getMethod = 'get' . ucfirst( $k );

			$obj = new ContextActivities();

			$obj->$setMethod( $common_activity );
			$this->assertEquals( array( $common_activity ), $obj->$getMethod(), "$k: single Activity" );

			$obj->$setMethod( array() );
			$this->assertEquals( array(), $obj->$getMethod(), "$k: empty array" );

			$obj->$setMethod( array( $common_activity ) );
			$this->assertEquals( array( $common_activity ), $obj->$getMethod(), "$k: array of single Activity" );

			$obj->$setMethod( array() );

			$obj->$setMethod( self::$common_activity_cfg );
			$this->assertEquals( array( $common_activity ), $obj->$getMethod(), "$k: single Activity configuration" );

			$obj->$setMethod( array() );

			$obj->$setMethod( array( self::$common_activity_cfg ) );
			$this->assertEquals( array( $common_activity ), $obj->$getMethod(), "$k: array of single Activity configuration" );
		}
	}

	public function testCompareWithSignature() {
		$acts = array(
			new Activity(
				array( 'id' => COMMON_ACTIVITY_ID . '/0' )
			),
			new Activity(
				array( 'id' => COMMON_ACTIVITY_ID . '/1' )
			),
			new Activity(
				array( 'id' => COMMON_ACTIVITY_ID . '/2' )
			),
			new Activity(
				array( 'id' => COMMON_ACTIVITY_ID . '/3' )
			),
		);

		$cases = array(
			array(
				'description' => 'all null',
				'objArgs'     => array(),
			),
		);
		foreach ( self::$listProps as $k ) {
			array_push(
				$cases,
				array(
					'description' => "$k single",
					'objArgs'     => array( $k => array( $acts[0] ) ),
				),
				array(
					'description' => "$k multiple",
					'objArgs'     => array( $k => array( $acts[0], $acts[1] ) ),
				),
				array(
					'description' => "$k single empty sig (no $k set)",
					'objArgs'     => array( $k => array( $acts[0] ) ),
					'sigArgs'     => array(),
					'reason'      => "Comparison of $k failed: array lengths differ",
				),
				array(
					'description' => "$k single empty sig",
					'objArgs'     => array( $k => array( $acts[0] ) ),
					'sigArgs'     => array( $k => array() ),
					'reason'      => "Comparison of $k failed: array lengths differ",
				),
				array(
					'description' => "$k multiple single sig",
					'objArgs'     => array( $k => array( $acts[0], $acts[1] ) ),
					'sigArgs'     => array( $k => array( $acts[1] ) ),
					'reason'      => "Comparison of $k failed: array lengths differ",
				),
				array(
					'description' => "$k single multiple sig",
					'objArgs'     => array( $k => array( $acts[0] ) ),
					'sigArgs'     => array( $k => array( $acts[0], $acts[1] ) ),
					'reason'      => "Comparison of $k failed: array lengths differ",
				),
				array(
					'description' => "$k single diff sig",
					'objArgs'     => array( $k => array( $acts[0] ) ),
					'sigArgs'     => array( $k => array( $acts[1] ) ),
					'reason'      => 'Comparison of ' . $k . '[0] failed: Comparison of id failed: value is not the same',
				),
				array(
					'description' => "$k multiple diff order",
					'objArgs'     => array( $k => array( $acts[0], $acts[1] ) ),
					'sigArgs'     => array( $k => array( $acts[1], $acts[0] ) ),
					'reason'      => 'Comparison of ' . $k . '[0] failed: Comparison of id failed: value is not the same',
				)
			);
		}

		foreach ( array(
			array( 'category', 'parent' ),
			array( 'category', 'other' ),
			array( 'category', 'grouping' ),
			array( 'parent', 'other' ),
			array( 'parent', 'grouping' ),
			array( 'grouping', 'other' ),
			array( 'category', 'parent', 'other' ),
			array( 'category', 'parent', 'grouping' ),
			array( 'category', 'other', 'grouping' ),
			array( 'parent', 'other', 'grouping' ),
			self::$listProps,
		) as $set ) {
			$prefix    = implode( ', ', $set );
			$new_cases = array(
				array(
					'description' => $prefix,
					'objArgs'     => array(),
					'sigArgs'     => array(),
				),
				array(
					'description' => "$prefix: empty sig",
					'objArgs'     => array(),
					'sigArgs'     => array(),
					'reason'      => 'Comparison of ' . $set[0] . ' failed: array lengths differ',
				),
				array(
					'description' => "$prefix: one missing this",
					'objArgs'     => array(),
					'sigArgs'     => array(),
					'reason'      => 'Comparison of ' . $set[0] . ' failed: array lengths differ',
				),
				array(
					'description' => "$prefix: one missing signature",
					'objArgs'     => array(),
					'sigArgs'     => array(),
					'reason'      => 'Comparison of ' . $set[0] . ' failed: array lengths differ',
				),
			);

			for ( $i = 0; $i < count( $set ); $i++ ) {
				$new_cases[0]['objArgs'][ $set[ $i ] ] = $acts[ $i ];
				$new_cases[0]['sigArgs'][ $set[ $i ] ] = $acts[ $i ];

				$new_cases[1]['objArgs'][ $set[ $i ] ] = $acts[ $i ];

				$new_cases[2]['objArgs'][ $set[ $i ] ] = $acts[ $i ];
				$new_cases[3]['objArgs'][ $set[ $i ] ] = $acts[ $i ];
				if ( $i !== 0 ) {
					$new_cases[2]['sigArgs'][ $set[ $i ] ] = $acts[ $i ];
					$new_cases[3]['sigArgs'][ $set[ $i ] ] = $acts[ $i ];
				}
			}

			$cases = array_merge( $cases, $new_cases );
		}
		$this->runSignatureCases( 'TinCan\ContextActivities', $cases );
	}

	/**
	 * @dataProvider invalidListSetterDataProvider
	 */
	public function testListSetterThrowsInvalidArgumentException( $publicMethodName, $invalidValue ) {
		$this->setExpectedException(
			'InvalidArgumentException',
			'type of arg1 must be Activity, array of Activity properties, or array of Activity/array of Activity properties'
		);
		$obj = new ContextActivities();
		$obj->$publicMethodName( $invalidValue );
	}

	public function invalidListSetterDataProvider() {
		$invalidValue = 1;
		return array(
			array( 'setCategory', $invalidValue ),
			array( 'setParent', $invalidValue ),
			array( 'setGrouping', $invalidValue ),
			array( 'setOther', $invalidValue ),
		);
	}
}
