<?php
$iea_upload_admin = new iea_upload_admin();
add_action( 'iea/uploaded_quiz', array( $iea_upload_admin, 'generate_uuid' ), 10, 2 );

class iea_upload_admin {

	private $dsn;
	private $tablePrefix;

	function course_name( $course_dir, $uuid ) {

		$xml_path = $course_dir . DIRECTORY_SEPARATOR . 'tincan.xml';
		// check for file

		$name = '';
		if ( file_exists( $xml_path ) ) {
			$xml_string = file_get_contents( $xml_path );
			$xml        = simplexml_load_string( $xml_string );
			$json       = json_encode( $xml );
			$xml_array  = json_decode( $json, true );

			if ( isset( $xml_array['activities']['activity']['name'] ) ) {
				$name = $xml_array['activities']['activity']['name'];
			}

			if ( isset( $xml_array['activities']['activity'][0]['name'] ) ) {
				$name = $xml_array['activities']['activity'][0]['name'];
			}
		}

		return $name;
	}

	function generate_uuid( $arr, $target ) {

		global $wpdb;

		$file = fopen( '' . $target . '/uuid.txt', 'w' );
		$uuid = iea_generate_uuid();
		fwrite( $file, $uuid );
		fclose( $file );

		$course_name = $this->course_name( $target, $uuid );

		// insert course in table when uploaded, only for xAPI/TinCan courses
		if ( ! empty( $course_name ) ) {

			$table  = "{$wpdb->prefix}quiz_lrs_courses";
			$data   = array(
				'course_name' => $course_name,
				'active'      => 1,
				'uuid'        => $uuid,
			);
			$format = array( '%s', '%d', '%s' );
			$wpdb->insert( $table, $data, $format ); // db call ok custom table

		}

	}




}
