###Overview

This repo contains a statement viewing page for Tin Can API statement streams.

* Copy the file `config.js.template` to `config.js` and set `Config.endpoint` to the LRS endpoint, including a trailing slash (ex: https://cloud.scorm.com/tc/public/)
* Set the endpoint credentials in `Config.authUser` and `Config.authPassword` as provided by the LRS
* Load: index.html in a browser

###Contact:
info@tincanapi.com<br>
http://tincanapi.com
