<?php
class TrackingReports {
	public function tracking() {
		wp_enqueue_script( 'materializejs', articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'js/materialize.js' );
		wp_enqueue_script( 'materializealtjs', articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'js/materialize-alt.min.js' );
		wp_enqueue_script( 'datatablesjs', articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'js/jquery.dataTables.min.js' );
		wp_enqueue_script( 'buttons-html5', articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'js/buttons.html5.min.js' );
		wp_enqueue_script( 'buttons-print-js', articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'js/buttons.print.min.js' );
		wp_enqueue_script( 'datatables-buttons', articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'js/dataTables.buttons.min.js' );
		wp_enqueue_script( 'jszip-js', articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'js/jszip.min.js' );

		wp_enqueue_script( 'admin-js', articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'js/articulate.js' );

		// wp_enqueue_style( 'materialize-css', articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'css/materialize.css' );
		// wp_enqueue_style( 'admin-css', articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'css/articulate.css' );

		$report = isset( $_GET['report'] ) ? $_GET['report'] : '';
		if ( empty( $report ) ) {
			$baseUrl = $_SERVER['PHP_SELF'] . '?' . $_SERVER['QUERY_STRING'];
			?>

<h2 class="header">Reports</h2>
	<form action="" method="post" style="margin:0 24px 0 0;">
  <div class="collection">

	<a class='report-link collection-item' href='<?php echo $baseUrl . '&report=score'; ?>'>How did people score on a content item?</a>
	<a class='report-link collection-item' href='<?php echo $baseUrl . '&report=answers'; ?>'>How did a user answer on a content item?</a>
  </div>
			
			
			<?php
		} else {
			if ( $report == 'score' ) {
				$trackingReportScore = new TrackingReportScore();
				$trackingReportScore->showReport();
				$trackingReportScore->initScoreLinks();
			}
			if ( $report == 'answers' ) {
				$trackingReportAnswers = new TrackingReportAnswers();
				$trackingReportAnswers->showReport();
				// js added to del button
				  $trackingReportScore = new TrackingReportScore();
				 $trackingReportScore->initScoreLinks();
			}
		}
	}
}

require_once 'trackingreportscore.php';
require_once 'trackingreportanswers.php';
?>
