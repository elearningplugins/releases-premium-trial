<?php
class StatementsViewer {
	public function statement_tracker() {
		global $current_user;
		wp_enqueue_script( 'materializejs', articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'js/materialize.js' );
		wp_enqueue_style( 'materialize-css', articulate_WP_QUIZ_EMBEDER_PLUGIN_URL . 'css/materialize.css' );
		// wp_enqueue_style( 'quiz-base-css', ARTICULATE_PREMIUM_TRACKING_PLUGIN_URL . '/admin/TinCanStatementViewer/css/base.css?v=STATEMENTVIEWERPHPLINE6' );
		// wp_enqueue_style( 'quiz-skeleton-css', ARTICULATE_PREMIUM_TRACKING_PLUGIN_URL . '/admin/TinCanStatementViewer/css/skeleton.css?v=STATEMENTVIEWERPHPLINE7' );
		// wp_enqueue_style( 'quiz-tincanviewer-css', ARTICULATE_PREMIUM_TRACKING_PLUGIN_URL . '/admin/TinCanStatementViewer/css/TinCanViewer.css?v=STATEMENTVIEWERPHPLINE8' );
		?>
<link rel="stylesheet" href="<?php echo ARTICULATE_PREMIUM_TRACKING_PLUGIN_URL; ?>/admin/TinCanStatementViewer/css/base.css">
<link rel="stylesheet" href="<?php echo ARTICULATE_PREMIUM_TRACKING_PLUGIN_URL; ?>/admin/TinCanStatementViewer/css/skeleton.css">
<link rel="stylesheet" href="<?php echo ARTICULATE_PREMIUM_TRACKING_PLUGIN_URL; ?>/admin/TinCanStatementViewer/css/TinCanViewer.css">
<!--
<div class="container">-->
<!--email_off-->
	<h2 class="header">Statement Viewer</h2>
	<p class="flow-text lineheighter">Click on a statement to see the raw statement data.</p>
	<br /><br />
	<div id="searchBox">
		<table id="versionTable" class="versionTable">
			<tr>
				<td style="display: none;">
					<label>TCAPI Version:</label>
					<select id="version">
						<option value="1.0.0">1.0.0</option>
						<option value="0.95 + 0.9">0.95 + 0.9</option>
						<option value="0.95">0.95</option>
						<option value="0.9">0.9</option>
					</select>
				</td>
			</tr>
		</table>
		<table id="searchBoxTable" class="searchBoxTable" style="display: none;">
			<tr>
				<td><label>Actor Email</label><input id="actorEmail" type="text" placeholder="Email Address" ></td>
				<!--<td><label>Verb ID</label><input id="verb" type="text" placeholder="Verb"></td>-->
				<td><label>Verb ID</label><select id="verb" class="materialize_me"><option value="passed">passed</option><option value="experienced">experienced</option></td>
				<!--<td><label>Activity ID</label><input id="activityId" type="text" placeholder="Activity ID"></td>-->
				<td><label>Use Context Activities</label><input id="context" type="checkbox"></td>
			</tr>
		</table>
		<table id="advancedSearchTable" class="searchBoxTable" style="display: none;">
			<tr>
				<td><label>Since</label><input id="since" type="date" class="datepickerz"></td>
				<td><label>Until</label><input id="until" type="date" class="datepickerz"></td>
				<td><label>Registration</label><input id="registration" type="text" placeholder="TinCan Registration ID"></td>
				<td><label>Authoritative Only</label><input id="authoritative" type="checkbox"></td>
			</tr>
			<tr>
				<td><label>Actor JSON</label><input id="actorJson" type="text" placeholder="Actor JSON"></td>
				<td><label>Object JSON</label><input id="objectJson" type="text" placeholder="Object JSON"></td>
				<td><label>Instructor JSON</label><input id="instructorJson" type="text" placeholder="Instructor JSON"></td>
				<td><label>Sparse</label><input id="sparse" type="checkbox"></td>
			</tr>
		</table>
		<table id="searchBoxTable1" class="searchBoxTable">
			<tr>
				<td style="display: none;">
					<label>Agent Property</label>
					<select id="agentProperty">
						<option value="mbox">mbox</option>
					</select>
				</td>
				<td>
					<label>Email Address</label>
					<select id="agentValue" name="actorEmail" class="materialize_me">
						<option value="">Choose a user</option>
						<?php
						$list_users = get_users( array( 'orderby' => 'nicename' ) );
						foreach ( $list_users as $user ) {
							echo '<option value="' . $user->user_email . '">' . $user->user_firstname . ' ' . $user->user_lastname . ' ' . $user->user_email . '</option>';
						}
						?>
					</select>
				</td>
				<td><label>Verb ID</label><select id="verb1" class="materialize_me"><option value=""> -- show all -- </option><option value="passed">passed</option><option value="failed">failed</option><option value="attempted">attempted</option><option value="completed">completed</option><option value="experienced">experienced</option><option value="answered">answered</option><option value="progressed">progressed</option></td>
				<td style="display: none;"><label>Activity ID</label><input id="activityId1" type="text" placeholder="Activity ID"></td>
			</tr>
		</table>
		<table id="advancedSearchTable1" class="searchBoxTable" style="display: none;">
			<tr>
				<td style="display: none;"><label>Format </label><select id="format" class="materialize_me"><option value="">default</option><option value="exact">exact</option><option value="ids">ids</option><option value="canonical">canonical</option></select></td>
				<td><label>Since</label><input id="since1" type="date" class="datepickerz" ></td>
				<td><label>Until</label><input id="until1" type="date" class="datepickerz" ></td>
				<td style="display: none;"><label>Registration</label><input id="registration1" type="text" placeholder="TinCan Registration ID"></td>
			</tr>
			<tr style="display: none;">
				<td style="display: none;"><input id="relatedAgents"  type="checkbox" class="filled-in"><label for="relatedAgents">Related Agents</label></td>
				<td style="display: none;"><input id="relatedActivities" type="checkbox" class="filled-in"><label for="relatedActivities">Related Activities</label></td>
				<!--<td><label>Attachments</label><input id="attachments" type="checkbox"></td>-->
				<td></td>
				<td></td>
			</tr>
		</table>

		<div id="TCAPIQuery" style="display:none"><label>TCAPI Query</label><textarea readonly id="TCAPIQueryText"></textarea></div>

		<button id="refreshStatements" class="waves-light btn normalfont"><i class="material-icons left">replay</i> Refresh</button>
		<button id="showAdvancedOptions" class="waves-effect waves-light btn normalfont"><i class="material-icons left">visibility</i>Show Advanced Options</button>
		<button id="showQuery" style="display:none;" class="waves-effect waves-light btn normalfont"><i class="material-icons left">import_export</i> Show TCAPI Query</button>
	</div>
	<div id='theStatements'></div>
	<div id='statementsLoading'>
		<img src="<?php echo ARTICULATE_PREMIUM_TRACKING_PLUGIN_URL; ?>/admin/TinCanStatementViewer/img/loading.gif" alt="Loading">
	</div>
	<button id='showAllStatements' class="waves-light btn normalfont">More...</button>
<!--</div>-->
<script type='text/javascript'>
/* <![CDATA[ */
			<?php
			$tincan_vars      = array();
			$tracking_api_key = iea_get_tracking_api_key();
			if ( $tracking_api_key != '' ) {
				$login_var_string = base64_decode( $tracking_api_key );
				$login_var_array  = explode( ':', $login_var_string );
				if ( is_array( $login_var_array ) ) {
					$tincan_vars['a']  = $tracking_api_key;
					$tincan_vars['a1'] = $login_var_array[0];
					$tincan_vars['a2'] = $login_var_array[1];
				} else {
					$tincan_vars['a1'] = '';
					$tincan_vars['a2'] = '';
				}
			}
			$tincan_vars['endpoint']      = ARTICULATE_PREMIUM_TRACKING_ENDPOINT;
			$tincan_vars['actor']['name'] = $current_user->user_firstname;
			$tincan_vars['actor']['mbox'] = $current_user->user_email;
			?>

			var tincan_vars = <?php echo json_encode( $tincan_vars ); ?>;
			var $ = jQuery;
			/* ]]> */
</script>
 <!--/email_off-->
<script type="text/javascript" src="<?php echo ARTICULATE_PREMIUM_TRACKING_PLUGIN_URL; ?>/admin/TinCanStatementViewer/scripts/jquery-ui-1.8.17.custom.min.js"></script>
<script type="text/javascript" src="<?php echo ARTICULATE_PREMIUM_TRACKING_PLUGIN_URL; ?>/admin/TinCanStatementViewer/config.js"></script>
<script type="text/javascript" src="<?php echo ARTICULATE_PREMIUM_TRACKING_PLUGIN_URL; ?>/admin/TinCanStatementViewer/scripts/tabs.js"></script>
<script type="text/javascript" src="<?php echo ARTICULATE_PREMIUM_TRACKING_PLUGIN_URL; ?>/admin/TinCanStatementViewer/scripts/base64.js"></script>
<script type="text/javascript" src="<?php echo ARTICULATE_PREMIUM_TRACKING_PLUGIN_URL; ?>/admin/TinCanStatementViewer/scripts/TinCanJS/build/tincan.js"></script>
<script type="text/javascript" src="<?php echo ARTICULATE_PREMIUM_TRACKING_PLUGIN_URL; ?>/admin/TinCanStatementViewer/scripts/TinCanQueryUtils.js"></script>
<script type="text/javascript" src="<?php echo ARTICULATE_PREMIUM_TRACKING_PLUGIN_URL; ?>/admin/TinCanStatementViewer/scripts/TinCanViewer.js"></script>
<script type="text/javascript" src="<?php echo ARTICULATE_PREMIUM_TRACKING_PLUGIN_URL; ?>/admin/TinCanStatementViewer/scripts/materialize977.min.js"></script>

<script type="text/javascript">
			$(document).ready(function(){
				TC_VIEWER = new TINCAN.Viewer();
				TC_VIEWER.pageInitialize();
				TC_VIEWER.searchStatements();
			});


</script>

		<?php
	}
}
?>
