//globals: equal, responseText, statement, ok, deepEqual, QUnit, module, asyncTest, Util, start, golfStatements, console
/*jslint bitwise: true, browser: true, plusplus: true, maxerr: 50, indent: 4 */
function Config() {
	"use strict";
}
console.log(tincan_vars);
Config.endpoint = tincan_vars.endpoint;
Config.authUser =tincan_vars.a1;
Config.authPassword = tincan_vars.a2;
Config.actor = { "mbox":["<learner email>"], "name":["<Learner Name>"] };