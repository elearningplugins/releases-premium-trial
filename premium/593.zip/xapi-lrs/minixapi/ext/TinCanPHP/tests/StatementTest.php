<?php
/*
	Copyright 2014 Rustici Software

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.
*/

namespace TinCanTest;

use TinCan\Activity;
use TinCan\Agent;
use TinCan\Attachment;
use TinCan\Context;
use TinCan\Result;
use TinCan\Statement;
use TinCan\Util;
use TinCan\Verb;
use TinCan\Version;
use Namshi\JOSE\JWS;

class StatementTest extends \PHPUnit_Framework_TestCase {
	use TestCompareWithSignatureTrait;

	public function testInstantiation() {
		$obj = new Statement();
		$this->assertInstanceOf( 'TinCan\Statement', $obj );
		$this->assertAttributeEmpty( 'id', $obj, 'id empty' );
		$this->assertAttributeEmpty( 'actor', $obj, 'actor empty' );
		$this->assertAttributeEmpty( 'verb', $obj, 'verb empty' );
		$this->assertAttributeEmpty( 'target', $obj, 'target empty' );
		$this->assertAttributeEmpty( 'context', $obj, 'context empty' );
		$this->assertAttributeEmpty( 'result', $obj, 'result empty' );
		$this->assertAttributeEmpty( 'timestamp', $obj, 'timestamp empty' );
		$this->assertAttributeEmpty( 'stored', $obj, 'stored empty' );
		$this->assertAttributeEmpty( 'authority', $obj, 'authority empty' );
		$this->assertAttributeEmpty( 'version', $obj, 'version empty' );
	}

	public function testFromJSONInvalidNull() {
		$this->setExpectedException( 'TinCan\JSONParseErrorException' );
		$obj = Statement::fromJSON( null );
	}

	public function testFromJSONInvalidEmptyString() {
		$this->setExpectedException( 'TinCan\JSONParseErrorException' );
		$obj = Statement::fromJSON( '' );
	}

	public function testFromJSONInvalidMalformed() {
		$this->setExpectedException( 'TinCan\JSONParseErrorException' );
		$obj = Statement::fromJSON( '{id:"some value"}' );
	}

	public function testConstructionFromArrayWithId() {
		$id  = Util::getUUID();
		$cfg = array(
			'id'     => $id,
			'actor'  => array(
				'mbox' => COMMON_MBOX,
			),
			'verb'   => array(
				'id' => COMMON_VERB_ID,
			),
			'object' => array(
				'id' => COMMON_ACTIVITY_ID,
			),
		);
		$obj = new Statement( $cfg );

		$this->assertSame( $obj->getId(), $id, 'id' );
	}

	public function testStamp() {
		$obj = new Statement();
		$obj->stamp();

		$this->assertAttributeInternalType( 'string', 'timestamp', $obj, 'timestamp is string' );
		$this->assertRegExp( Util::UUID_REGEX, $obj->getId(), 'id is UUId' );
	}

	public function testSetId() {
		$this->setExpectedException(
			'InvalidArgumentException',
			'arg1 must be a UUID "some invalid id"'
		);

		$obj = new Statement();
		$obj->setId( 'some invalid id' );
	}

	public function testSetStoredInvalidArgumentException() {
		$this->setExpectedException(
			'InvalidArgumentException',
			'type of arg1 must be string or DateTime'
		);

		$obj = new Statement();
		$obj->setStored( 1 );
	}

	// TODO: need to loop versions
	public function testAsVersion() {
		$args = array(
			'actor'       => array(
				'mbox' => COMMON_MBOX,
			),
			'verb'        => array(
				'id'      => COMMON_VERB_ID,
				'display' => array(
					'en-US' => 'experienced',
				),
			),
			'object'      => array(
				'id'         => COMMON_ACTIVITY_ID,
				'definition' => array(
					'type'        => 'Invalid type',
					'name'        => array(
						'en-US' => 'Test',
					),
					'description' => array(
						'en-US' => 'Test description',
					),
					'extensions'  => array(
						'http://someuri' => 'some value',
					),
				),
			),
			'context'     => array(
				'contextActivities' => array(
					'parent' => array(
						array(
							'id'         => COMMON_ACTIVITY_ID . '/1',
							'definition' => array(
								'name' => array(
									'en-US' => 'Test: 1',
								),
							),
						),
					),
				),
				'registration'      => Util::getUUID(),
			),
			'result'      => array(
				'completion' => true,
				'success'    => false,
				'score'      => array(
					'raw'    => '97',
					'min'    => '65',
					'max'    => '100',
					'scaled' => '.97',
				),
			),
			'version'     => '1.0.0',
			'attachments' => array(
				array(
					'usageType'   => 'http://test',
					'display'     => array( 'en-US' => 'test display' ),
					'contentType' => 'text/plain; charset=ascii',
					'length'      => 0,
					'sha2'        => hash( 'sha256', json_encode( array( 'foo', 'bar' ) ) ),
				),
			),
		);

		$obj = Statement::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$obj->stamp();

		$versioned = $obj->asVersion( '1.0.0' );

		$args['id']                   = $obj->getId();
		$args['timestamp']            = $obj->getTimestamp();
		$args['actor']['objectType']  = 'Agent';
		$args['object']['objectType'] = 'Activity';
		$args['context']['contextActivities']['parent'][0]['objectType'] = 'Activity';

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testAsVersionEmpty() {
		$args = array();

		$obj       = Statement::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$this->assertEquals( $versioned, $args, 'serialized version matches original' );
	}

	public function testAsVersionEmptySubObjects() {
		$args = array(
			'actor'       => array(
				'mbox' => COMMON_MBOX,
			),
			'verb'        => array(
				'id'      => COMMON_VERB_ID,
				'display' => array(),
			),
			'object'      => array(
				'id'         => COMMON_ACTIVITY_ID,
				'definition' => array(
					'type'        => 'Invalid type',
					'name'        => array(),
					'description' => array(),
					'extensions'  => array(),
				),
			),
			'context'     => array(
				'contextActivities' => array(
					'parent' => array(),
				),
				'registration'      => Util::getUUID(),
			),
			'result'      => array(
				'completion' => true,
				'success'    => false,
				'score'      => array(),
			),
			'version'     => '1.0.0',
			'attachments' => array(),
		);

		$obj       = Statement::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$args['actor']['objectType']  = 'Agent';
		$args['object']['objectType'] = 'Activity';
		unset( $args['verb']['display'] );
		unset( $args['object']['definition']['name'] );
		unset( $args['object']['definition']['description'] );
		unset( $args['object']['definition']['extensions'] );
		unset( $args['context']['contextActivities'] );
		unset( $args['result']['score'] );
		unset( $args['attachments'] );

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testAsVersionSubObjectWithEmptyValue() {
		$args = array(
			'actor'   => array(
				'mbox' => COMMON_MBOX,
			),
			'verb'    => array(
				'id' => COMMON_VERB_ID,
			),
			'object'  => array(
				'id'         => COMMON_ACTIVITY_ID,
				'definition' => array(
					'type' => 'Invalid type',
					'name' => array(
						'en-US' => '',
					),
				),
			),
			'context' => array(
				'contextActivities' => array(),
			),
			'result'  => array(
				'completion' => true,
				'success'    => false,
				'score'      => array(
					'raw' => 0,
				),
			),
		);

		$obj       = Statement::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$args['actor']['objectType']  = 'Agent';
		$args['object']['objectType'] = 'Activity';
		unset( $args['context'] );

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testCompareWithSignature() {
		$id1                  = Util::getUUID();
		$id2                  = Util::getUUID();
		$actor1               = new Agent(
			array( 'mbox' => COMMON_MBOX )
		);
		$actor2               = new Agent(
			array(
				'account' => array(
					'homePage' => COMMON_ACCT_HOMEPAGE,
					'name'     => COMMON_ACCT_NAME,
				),
			)
		);
		$verb1                = new Verb(
			array( 'id' => COMMON_VERB_ID )
		);
		$verb2                = new Verb(
			array( 'id' => COMMON_VERB_ID . '/2' )
		);
		$activity1            = new Activity(
			array( 'id' => COMMON_ACTIVITY_ID )
		);
		$activity2            = new Activity(
			array( 'id' => COMMON_ACTIVITY_ID . '/2' )
		);
		$context1             = new Context(
			array( 'registration' => Util::getUUID() )
		);
		$context2             = new Context(
			array(
				'contextActivities' => array(
					array( 'parent' => array( COMMON_ACTIVITY_ID . '/parent' ) ),
					array( 'grouping' => array( COMMON_ACTIVITY_ID ) ),
				),
			)
		);
		$result1              = new Result(
			array( 'raw' => 87 )
		);
		$result2              = new Result(
			array( 'response' => 'a' )
		);
		$timestamp1           = '2015-01-28T14:23:37.159Z';
		$timestamp1_tz        = '2015-01-28T08:23:37.159-06:00';
		$timestamp1_subsecond = '2015-01-28T14:23:37.348Z';
		$timestamp2           = '2015-01-28T15:49:11.089Z';

		$attachments1 = new Attachment(
			array(
				'usageType'   => 'http://id.tincanapi.com/attachment/supporting_media',
				'display'     => array( 'en-US' => 'Test Display' ),
				'contentType' => 'application/json',
				'content'     => json_encode( array( 'foo', 'bar' ) ),
			)
		);
		$attachments2 = new Attachment(
			array(
				'usageType'   => 'http://id.tincanapi.com/attachment/supporting_media',
				'display'     => array( 'en-US' => 'Test Display' ),
				'contentType' => 'application/json',
				'content'     => json_encode( array( 'bar', 'foo' ) ),
			)
		);

		$full = array(
			'id'          => $id1,
			'actor'       => $actor1,
			'verb'        => $verb1,
			'target'      => $activity1,
			'context'     => $context1,
			'result'      => $result1,
			'timestamp'   => $timestamp1,
			'attachments' => array( $attachments1 ),
		);

		$cases = array(
			array(
				'description' => 'all null',
				'objArgs'     => array(),
			),
			array(
				'description' => 'id',
				'objArgs'     => array( 'id' => $id1 ),
			),
			array(
				'description' => 'actor',
				'objArgs'     => array( 'actor' => $actor1 ),
			),
			array(
				'description' => 'verb',
				'objArgs'     => array( 'verb' => $verb1 ),
			),
			array(
				'description' => 'object',
				'objArgs'     => array( 'target' => $activity1 ),
			),
			array(
				'description' => 'result',
				'objArgs'     => array( 'result' => $result1 ),
			),
			array(
				'description' => 'context',
				'objArgs'     => array( 'context' => $context1 ),
			),
			array(
				'description' => 'timestamp',
				'objArgs'     => array( 'timestamp' => $timestamp1 ),
			),
			array(
				'description' => 'attachments',
				'objArgs'     => array( 'attachments' => array( $attachments1 ) ),
			),
			array(
				'description' => 'all',
				'objArgs'     => $full,
			),

			//
			// special case where timestamp marks the same point in time but
			// is provided in a different timezone
			//
			array(
				'description' => 'timestamp timezone difference',
				'objArgs'     => array( 'timestamp' => $timestamp1 ),
				'sigArgs'     => array( 'timestamp' => $timestamp1_tz ),
			),

			//
			// special case where we make sure sub-second precision is handled
			//
			array(
				'description' => 'timestamp subsecond difference',
				'objArgs'     => array( 'timestamp' => $timestamp1 ),
				'sigArgs'     => array( 'timestamp' => $timestamp1_subsecond ),
				'reason'      => 'Comparison of timestamp failed: value is not the same',
			),

			array(
				'description' => 'id this only: mismatch',
				'objArgs'     => array( 'id' => $id1 ),
				'sigArgs'     => array(),
				'reason'      => 'Comparison of id failed: value not in signature',
			),
			array(
				'description' => 'id sig only: mismatch',
				'objArgs'     => array(),
				'sigArgs'     => array( 'id' => $id1 ),
				'reason'      => 'Comparison of id failed: value not in this',
			),
			array(
				'description' => 'id only: mismatch',
				'objArgs'     => array( 'id' => $id1 ),
				'sigArgs'     => array( 'id' => $id2 ),
				'reason'      => 'Comparison of id failed: value is not the same',
			),
			array(
				'description' => 'actor only: mismatch',
				'objArgs'     => array( 'actor' => $actor1 ),
				'sigArgs'     => array( 'actor' => $actor2 ),
				'reason'      => 'Comparison of actor failed: Comparison of mbox failed: value is not the same',
			),
			array(
				'description' => 'verb only: mismatch',
				'objArgs'     => array( 'verb' => $verb1 ),
				'sigArgs'     => array( 'verb' => $verb2 ),
				'reason'      => 'Comparison of verb failed: Comparison of id failed: value is not the same',
			),
			array(
				'description' => 'object only: mismatch',
				'objArgs'     => array( 'target' => $activity1 ),
				'sigArgs'     => array( 'target' => $activity2 ),
				'reason'      => 'Comparison of target failed: Comparison of id failed: value is not the same',
			),
			array(
				'description' => 'result only: mismatch',
				'objArgs'     => array( 'result' => $result1 ),
				'sigArgs'     => array( 'result' => $result2 ),
				'reason'      => 'Comparison of result failed: Comparison of response failed: value not present in this or signature',
			),
			array(
				'description' => 'context only: mismatch',
				'objArgs'     => array( 'context' => $context1 ),
				'sigArgs'     => array( 'context' => $context2 ),
				'reason'      => 'Comparison of context failed: Comparison of registration failed: value not present in this or signature',
			),
			array(
				'description' => 'timestamp only: mismatch',
				'objArgs'     => array( 'timestamp' => $timestamp1 ),
				'sigArgs'     => array( 'timestamp' => $timestamp2 ),
				'reason'      => 'Comparison of timestamp failed: value is not the same',
			),
			array(
				'description' => 'attachments this only: mismatch',
				'objArgs'     => array( 'attachments' => array( $attachments1 ) ),
				'sigArgs'     => array( 'attachments' => array() ),
				'reason'      => 'Comparison of attachments list failed: array lengths differ',
			),
			array(
				'description' => 'attachments sig only: mismatch',
				'objArgs'     => array( 'attachments' => array() ),
				'sigArgs'     => array( 'attachments' => array( $attachments2 ) ),
				'reason'      => 'Comparison of attachments list failed: array lengths differ',
			),
			array(
				'description' => 'attachments only: mismatch',
				'objArgs'     => array( 'attachments' => array( $attachments1 ) ),
				'sigArgs'     => array( 'attachments' => array( $attachments2 ) ),
				'reason'      => 'Comparison of attachment 0 failed: Comparison of sha2 failed: value is not the same',
			),
			array(
				'description' => 'full: id mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'id' => $id2 ) ),
				'reason'      => 'Comparison of id failed: value is not the same',
			),
			array(
				'description' => 'full: actor mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'actor' => $actor2 ) ),
				'reason'      => 'Comparison of actor failed: Comparison of mbox failed: value is not the same',
			),
			array(
				'description' => 'full: verb mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'verb' => $verb2 ) ),
				'reason'      => 'Comparison of verb failed: Comparison of id failed: value is not the same',
			),
			array(
				'description' => 'full: target mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'target' => $activity2 ) ),
				'reason'      => 'Comparison of target failed: Comparison of id failed: value is not the same',
			),
			array(
				'description' => 'full: result mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'result' => $result2 ) ),
				'reason'      => 'Comparison of result failed: Comparison of response failed: value not present in this or signature',
			),
			array(
				'description' => 'full: context mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'context' => $context2 ) ),
				'reason'      => 'Comparison of context failed: Comparison of registration failed: value not present in this or signature',
			),
			array(
				'description' => 'full: timestamp mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'timestamp' => $timestamp2 ) ),
				'reason'      => 'Comparison of timestamp failed: value is not the same',
			),
			array(
				'description' => 'full: attachments mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'attachments' => array( $attachments2 ) ) ),
				'reason'      => 'Comparison of attachment 0 failed: Comparison of sha2 failed: value is not the same',
			),
		);
		$this->runSignatureCases( 'TinCan\Statement', $cases );
	}

	public function testHasAttachments() {
		$stNoAttachments = new Statement();
		$this->assertFalse( $stNoAttachments->hasAttachments() );

		$stWithAttachments = new Statement(
			array(
				'attachments' => array(
					array(
						'usageType'   => 'http://test',
						'display'     => array( 'en-US' => 'test display' ),
						'contentType' => 'text/plain; charset=ascii',
						'length'      => 0,
						'sha2'        => hash( 'sha256', json_encode( array( 'foo', 'bar' ) ) ),
					),
				),
			)
		);
		$this->assertTrue( $stWithAttachments->hasAttachments() );
	}

	public function testHasAttachmentWithContent() {
		$content = 'Just some test content';

		$stNoAttachments = new Statement();
		$this->assertFalse( $stNoAttachments->hasAttachmentsWithContent() );

		$stWithAttachmentNoContent = new Statement(
			array(
				'attachments' => array(
					array(
						'usageType'   => 'http://test',
						'display'     => array( 'en-US' => 'test display' ),
						'contentType' => 'text/plain; charset=ascii',
						'length'      => strlen( $content ),
						'sha2'        => hash( 'sha256', $content ),
					),
				),
			)
		);
		$this->assertFalse( $stWithAttachmentNoContent->hasAttachmentsWithContent() );

		$stWithAttachmentWithContent = new Statement(
			array(
				'attachments' => array(
					array(
						'usageType'   => 'http://test',
						'display'     => array( 'en-US' => 'test display' ),
						'contentType' => 'text/plain; charset=ascii',
						'length'      => strlen( $content ),
						'sha2'        => hash( 'sha256', $content ),
						'content'     => $content,
					),
				),
			)
		);
		$this->assertTrue( $stWithAttachmentWithContent->hasAttachmentsWithContent() );
	}

	public function testSignNoArgs() {
		$obj = new Statement();

		if ( PHP_MAJOR_VERSION >= 7 && PHP_MINOR_VERSION >= 1 ) {
			$this->setExpectedException(
				'ArgumentCountError'
			);
		} else {
			$this->setExpectedException(
				'PHPUnit_Framework_Error_Warning',
				( getenv( 'TRAVIS_PHP_VERSION' ) == 'hhvm' ? 'sign() expects at least 2 parameters, 0 given' : 'Missing argument 1' )
			);
		}
		$obj->sign();
	}

	public function testSignOneArg() {
		$obj = new Statement();

		if ( PHP_MAJOR_VERSION >= 7 && PHP_MINOR_VERSION >= 1 ) {
			$this->setExpectedException(
				'ArgumentCountError'
			);
		} else {
			$this->setExpectedException(
				'PHPUnit_Framework_Error_Warning',
				( getenv( 'TRAVIS_PHP_VERSION' ) == 'hhvm' ? 'sign() expects at least 2 parameters, 1 given' : 'Missing argument 2' )
			);
		}
		$obj->sign( 'test' );
	}

	public function testSignNoActor() {
		$this->setExpectedException(
			'InvalidArgumentException',
			'actor must be present in signed statement'
		);

		$obj = new Statement();
		$obj->sign( 'test', 'test' );
	}

	public function testSignNoVerb() {
		$this->setExpectedException(
			'InvalidArgumentException',
			'verb must be present in signed statement'
		);

		$obj = new Statement(
			array(
				'actor' => array( 'mbox' => COMMON_MBOX ),
			)
		);
		$obj->sign( 'test', 'test' );
	}

	public function testSignNoObject() {
		$this->setExpectedException(
			'InvalidArgumentException',
			'object must be present in signed statement'
		);

		$obj = new Statement(
			array(
				'actor' => array( 'mbox' => COMMON_MBOX ),
				'verb'  => array( 'id' => COMMON_VERB_ID ),
			)
		);
		$obj->sign( 'test', 'test' );
	}

	public function testSignInvalidAlgorithm() {
		$this->setExpectedException(
			'InvalidArgumentException',
			"Invalid signing algorithm: 'not right'"
		);

		$obj = new Statement(
			array(
				'actor'  => array( 'mbox' => COMMON_MBOX ),
				'verb'   => array( 'id' => COMMON_VERB_ID ),
				'object' => new Activity(
					array(
						'id' => COMMON_ACTIVITY_ID . '/StatementTest/testSignNoPassword',
					)
				),
			)
		);
		$obj->sign( 'file://' . $GLOBALS['KEYs']['private'], $GLOBALS['KEYs']['password'], array( 'algorithm' => 'not right' ) );
	}

	public function testSignEmptyPassword() {
		$this->setExpectedException(
			'Exception',
			'Unable to get private key: error:0906A068:PEM routines:PEM_do_header:bad password read'
		);

		$obj = new Statement(
			array(
				'actor'  => array( 'mbox' => COMMON_MBOX ),
				'verb'   => array( 'id' => COMMON_VERB_ID ),
				'object' => new Activity(
					array(
						'id' => COMMON_ACTIVITY_ID . '/StatementTest/testSignNoPassword',
					)
				),
			)
		);
		$obj->sign( 'file://' . $GLOBALS['KEYs']['private'], '' );
	}

	public function testSignInvalidPassword() {
		$this->setExpectedExceptionRegExp(
			'Exception',
			'/Unable to get private key: error:.*:bad decrypt/'
		);

		$obj = new Statement(
			array(
				'actor'  => array( 'mbox' => COMMON_MBOX ),
				'verb'   => array( 'id' => COMMON_VERB_ID ),
				'object' => new Activity(
					array(
						'id' => COMMON_ACTIVITY_ID . '/StatementTest/testSignNoPassword',
					)
				),
			)
		);
		$obj->sign( 'file://' . $GLOBALS['KEYs']['private'], 'notthecorrectpasswordhopefully' );
	}

	public function testSignInvalidX5cErrorToException() {
		$this->setExpectedExceptionRegExp(
			'PHPUnit_Framework_Error',
			'/supplied parameter cannot be coerced into an X509 certificate!/'
		);

		$obj = new Statement(
			array(
				'actor'  => array( 'mbox' => COMMON_MBOX ),
				'verb'   => array( 'id' => COMMON_VERB_ID ),
				'object' => new Activity(
					array(
						'id' => COMMON_ACTIVITY_ID . '/StatementTest/testSignNoPassword',
					)
				),
			)
		);
		$obj->sign( 'file://' . $GLOBALS['KEYs']['private'], $GLOBALS['KEYs']['password'], array( 'x5c' => 'invalid' ) );
	}

	public function testSignInvalidX5cNoError() {
		$this->setExpectedExceptionRegExp(
			'Exception',
			'/Unable to read certificate for x5c inclusion: .*/'
		);

		$obj = new Statement(
			array(
				'actor'  => array( 'mbox' => COMMON_MBOX ),
				'verb'   => array( 'id' => COMMON_VERB_ID ),
				'object' => new Activity(
					array(
						'id' => COMMON_ACTIVITY_ID . '/StatementTest/testSignNoPassword',
					)
				),
			)
		);
		@$obj->sign( 'file://' . $GLOBALS['KEYs']['private'], $GLOBALS['KEYs']['password'], array( 'x5c' => 'invalid' ) );
	}

	public function testVerifyNoSignature() {
		$obj    = new Statement(
			array(
				'actor'  => array( 'mbox' => COMMON_MBOX ),
				'verb'   => array( 'id' => COMMON_VERB_ID ),
				'object' => new Activity(
					array(
						'id' => COMMON_ACTIVITY_ID . '/StatementTest/testSignAndVerify',
					)
				),
			)
		);
		$result = $obj->verify();

		$this->assertFalse( $result['success'], 'success' );
		$this->assertSame( $result['reason'], 'Unable to locate signature attachment (usage type)', 'reason' );
	}

	public function testVerifyInvalidJWS() {
		$obj    = new Statement(
			array(
				'actor'       => array( 'mbox' => COMMON_MBOX ),
				'verb'        => array( 'id' => COMMON_VERB_ID ),
				'object'      => new Activity(
					array(
						'id' => COMMON_ACTIVITY_ID . '/StatementTest/testSignAndVerify',
					)
				),
				'attachments' => array(
					array(
						'usageType'   => 'http://adlnet.gov/expapi/attachments/signature',
						'display'     => array( 'en-US' => 'test display' ),
						'contentType' => 'application/octet-stream',
						'content'     => 'not a signature',
					),
				),
			)
		);
		$result = $obj->verify();

		$this->assertFalse( $result['success'], 'success' );
		$this->assertStringStartsWith(
			'Failed to load JWS',
			$result['reason'],
			'reason'
		);
	}

	public function testVerifyInvalidX5cErrorToException() {
		$this->setExpectedExceptionRegExp(
			'PHPUnit_Framework_Error',
			'/supplied parameter cannot be coerced into an X509 certificate!/'
		);

		$content = new JWS(
			array(
				'alg' => 'RS256',
				'x5c' => array( 'notAValidCertificate' ),
			)
		);
		$content->setPayload( array( 'prop' => 'val' ), false );
		$content->sign( openssl_pkey_get_private( 'file://' . $GLOBALS['KEYs']['private'], $GLOBALS['KEYs']['password'] ) );

		$obj    = new Statement(
			array(
				'actor'       => array( 'mbox' => COMMON_MBOX ),
				'verb'        => array( 'id' => COMMON_VERB_ID ),
				'object'      => new Activity(
					array(
						'id' => COMMON_ACTIVITY_ID . '/StatementTest/testSignNoPassword',
					)
				),
				'attachments' => array(
					array(
						'usageType'   => 'http://adlnet.gov/expapi/attachments/signature',
						'display'     => array( 'en-US' => 'test display' ),
						'contentType' => 'application/octet-stream',
						'content'     => $content->getTokenString(),
					),
				),
			)
		);
		$result = $obj->verify();
	}

	public function testVerifyInvalidX5cNoError() {
		$content = new JWS(
			array(
				'alg' => 'RS256',
				'x5c' => array( 'notAValidCertificate' ),
			)
		);
		$content->setPayload( array( 'prop' => 'val' ), false );
		$content->sign( openssl_pkey_get_private( 'file://' . $GLOBALS['KEYs']['private'], $GLOBALS['KEYs']['password'] ) );

		$obj     = new Statement(
			array(
				'actor'       => array( 'mbox' => COMMON_MBOX ),
				'verb'        => array( 'id' => COMMON_VERB_ID ),
				'object'      => new Activity(
					array(
						'id' => COMMON_ACTIVITY_ID . '/StatementTest/testSignNoPassword',
					)
				),
				'attachments' => array(
					array(
						'usageType'   => 'http://adlnet.gov/expapi/attachments/signature',
						'display'     => array( 'en-US' => 'test display' ),
						'contentType' => 'application/octet-stream',
						'content'     => $content->getTokenString(),
					),
				),
			)
		);
		@$result = $obj->verify();

		$this->assertFalse( $result['success'], 'success' );
		$this->assertSame( 'failed to read cert in x5c: error:0906D06C:PEM routines:PEM_read_bio:no start line', $result['reason'], 'reason' );
	}

	public function testVerifyNoPubKey() {
		$content = new JWS(
			array(
				'alg' => 'RS256',
			)
		);
		$content->setPayload( array( 'prop' => 'val' ), false );
		$content->sign( openssl_pkey_get_private( 'file://' . $GLOBALS['KEYs']['private'], $GLOBALS['KEYs']['password'] ) );

		$obj    = new Statement(
			array(
				'actor'       => array( 'mbox' => COMMON_MBOX ),
				'verb'        => array( 'id' => COMMON_VERB_ID ),
				'object'      => new Activity(
					array(
						'id' => COMMON_ACTIVITY_ID . '/StatementTest/testSignNoPassword',
					)
				),
				'attachments' => array(
					array(
						'usageType'   => 'http://adlnet.gov/expapi/attachments/signature',
						'display'     => array( 'en-US' => 'test display' ),
						'contentType' => 'application/octet-stream',
						'content'     => $content->getTokenString(),
					),
				),
			)
		);
		$result = $obj->verify();

		$this->assertFalse( $result['success'], 'success' );
		$this->assertSame( $result['reason'], 'No public key found or provided for verification', 'reason' );
	}

	public function testVerifyIncorrectPubKey() {
		$content = new JWS(
			array(
				'alg' => 'RS256',
			)
		);
		$content->setPayload( array( 'prop' => 'val' ), false );
		$content->sign( openssl_pkey_get_private( 'file://' . $GLOBALS['KEYs']['private'], $GLOBALS['KEYs']['password'] ) );

		$obj = new Statement(
			array(
				'actor'       => array( 'mbox' => COMMON_MBOX ),
				'verb'        => array( 'id' => COMMON_VERB_ID ),
				'object'      => new Activity(
					array(
						'id' => COMMON_ACTIVITY_ID . '/StatementTest/testSignNoPassword',
					)
				),
				'attachments' => array(
					array(
						'usageType'   => 'http://adlnet.gov/expapi/attachments/signature',
						'display'     => array( 'en-US' => 'test display' ),
						'contentType' => 'application/octet-stream',
						'content'     => $content->getTokenString(),
					),
				),
			)
		);

		$newKey = openssl_pkey_new(
			array(
				'private_key_bits' => 2048,
				'private_key_type' => OPENSSL_KEYTYPE_RSA,
			)
		);
		$pubKey = openssl_pkey_get_details( $newKey );
		$pubKey = $pubKey['key'];

		$result = $obj->verify( array( 'publicKey' => $pubKey ) );

		$this->assertFalse( $result['success'], 'success' );
		$this->assertSame( $result['reason'], 'Failed to verify signature', 'reason' );
	}

	public function testVerifyDiffStatement() {
		$obj = new Statement(
			array(
				'actor'  => array( 'mbox' => COMMON_MBOX ),
				'verb'   => array( 'id' => COMMON_VERB_ID ),
				'object' => new Activity(
					array(
						'id' => COMMON_ACTIVITY_ID . '/StatementTest/testVerifyDiffStatement',
					)
				),
			)
		);
		$obj->sign( 'file://' . $GLOBALS['KEYs']['private'], $GLOBALS['KEYs']['password'], array( 'x5c' => 'file://' . $GLOBALS['KEYs']['public'] ) );

		$diff   = new Statement(
			array(
				'actor'       => array( 'mbox' => COMMON_MBOX ),
				'verb'        => array( 'id' => COMMON_VERB_ID ),
				'object'      => new Activity(
					array(
						'id' => COMMON_ACTIVITY_ID . '/StatementTest/testVerifyDiffStatement-diff',
					)
				),
				'attachments' => $obj->getAttachments(),
			)
		);
		$result = $diff->verify();

		$this->assertFalse( $result['success'], 'success' );
		$this->assertSame( $result['reason'], 'Statement to signature comparison failed: Comparison of target failed: Comparison of id failed: value is not the same', 'reason' );
	}

	public function testSignAndVerify() {
		$obj = new Statement(
			array(
				'actor'  => array( 'mbox' => COMMON_MBOX ),
				'verb'   => array( 'id' => COMMON_VERB_ID ),
				'object' => new Activity(
					array(
						'id' => COMMON_ACTIVITY_ID . '/StatementTest/testSignAndVerify',
					)
				),
			)
		);
		$obj->sign( 'file://' . $GLOBALS['KEYs']['private'], $GLOBALS['KEYs']['password'] );

		$attachment = $obj->getAttachments()[0];

		$this->assertSame( $attachment->getUsageType(), 'http://adlnet.gov/expapi/attachments/signature', 'usage type value' );
		$this->assertSame( $attachment->getContentType(), 'application/octet-stream', 'content type value' );

		$result = $obj->verify( array( 'publicKey' => 'file://' . $GLOBALS['KEYs']['public'] ) );
		if ( ! $result['success'] ) {
			print $result['reason'];
		}
		$this->assertTrue( $result['success'], 'success return value' );
	}

	public function testSignAndVerifyFromEmbedded() {
		$obj = new Statement(
			array(
				'actor'  => array( 'mbox' => COMMON_MBOX ),
				'verb'   => array( 'id' => COMMON_VERB_ID ),
				'object' => new Activity(
					array(
						'id' => COMMON_ACTIVITY_ID . '/StatementTest/testSignAndVerifyFromEmbedded',
					)
				),
			)
		);
		$obj->sign( 'file://' . $GLOBALS['KEYs']['private'], $GLOBALS['KEYs']['password'], array( 'x5c' => 'file://' . $GLOBALS['KEYs']['public'] ) );

		$attachment = $obj->getAttachments()[0];

		$this->assertSame( $attachment->getUsageType(), 'http://adlnet.gov/expapi/attachments/signature', 'usage type value' );
		$this->assertSame( $attachment->getContentType(), 'application/octet-stream', 'content type value' );

		$result = $obj->verify();
		if ( ! $result['success'] ) {
			print $result['reason'];
		}
		$this->assertTrue( $result['success'], 'success return value' );
	}

	public function testSignAndVerifyNoPubKey() {
		$obj = new Statement(
			array(
				'actor'  => array( 'mbox' => COMMON_MBOX ),
				'verb'   => array( 'id' => COMMON_VERB_ID ),
				'object' => new Activity(
					array(
						'id' => COMMON_ACTIVITY_ID . '/StatementTest/testSignAndVerify',
					)
				),
			)
		);
		$obj->sign( 'file://' . $GLOBALS['KEYs']['private'], $GLOBALS['KEYs']['password'] );

		$result = $obj->verify();
		$this->assertFalse( $result['success'], 'success return value' );
		$this->assertSame( $result['reason'], 'No public key found or provided for verification', 'reason' );
	}
}
