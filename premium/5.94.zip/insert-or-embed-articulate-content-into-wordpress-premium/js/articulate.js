var articulatejq = jQuery.noConflict();
articulatejq(document).ready(function() {

	// Function to display a row.
	articulatejq.fn.show_row = function() {
		this.fadeIn( 300, function() {
			articulatejq( this ).removeClass( 'hide-row' );
			var total = articulatejq( '.tblScore' ).attr( 'data-count' );
			var visible = parseInt( articulatejq( '.tblScore' ).find( 'tr[data-num]:not(.hide-row)' ).length );
			if ( visible >= total ) {
				articulatejq( 'button#showMoreReports' ).remove();
			}
		} );
	}

	// Load more reports.
	articulatejq( document ).on( 'click', 'button#showMoreReports', function( event ) {
		event.preventDefault;
		var results = articulatejq( '.tblScore' );
		var visible = parseInt( results.find( 'tr[data-num]:not(.hide-row)' ).length );
		var per_page = parseInt( results.attr( 'data-per-page' ) );
		var display = parseInt( visible + per_page );
		results.find( 'tr[data-num].hide-row' ).filter(function(){
		  return articulatejq(this).attr("data-num") <= display;
		}).show_row();
	} );

	// Date pickers.
    articulatejq('.datepickerz').pickadate({
        selectMonths: true, // Creates a dropdown to control month
        selectYears: 15, // Creates a dropdown of 15 years to control year
        format: 'yyyy-mm-dd',
		onClose: function() {
			articulatejq(document.activeElement).blur();
		}
    });
	articulatejq('.datepickerz').on('mousedown',function(event){ event.preventDefault(); });

	// Enable custom dates UI.
	var curr_date = articulatejq( '#report_date' ).val();
	if ( curr_date && curr_date == 'custom' ) {
		articulatejq( '.articulate_cb_date' ).removeClass( 'articulate_cb-hidden' );
	}

	articulatejq( document ).on( 'change', '#report_date', function( event ) {
		var curr_date = articulatejq( '#report_date' ).val();
		if ( curr_date && curr_date == 'custom' ) {
			articulatejq( '.articulate_cb_date' ).removeClass( 'articulate_cb-hidden' );
		} else {
			articulatejq( '.articulate_cb_date' ).addClass( 'articulate_cb-hidden' );
		}
	} );

	// Modify export URL.
	if ( articulatejq( '.export-report' ).length ) {
	var show_incomplete = articulatejq( '#show_incompletions' ).is( ':checked' );
	var export_btn = articulatejq( '.export-report' );
	var export_url = export_btn.attr( 'href' );
	if ( show_incomplete ) {
		export_url = export_url + '&show_incomplete=1';
		export_btn.attr( 'href', export_url );
	} else {
		export_url = export_url.replace( '&show_incomplete=1', '' );
		export_btn.attr( 'href', export_url );
	}

	// When the checkbox is changed.
	articulatejq( document ).on( 'change', '#show_incompletions', function() {
		if ( articulatejq( this ).is( ':checked' ) ) {
			export_url = export_url + '&show_incomplete=1';
			export_btn.attr( 'href', export_url );
		} else {
			export_url = export_url.replace( '&show_incomplete=1', '' );
			export_btn.attr( 'href', export_url );
		}
	} );
	}

});

articulatejq(window).load(function () {
    setTimeout(function () {
       	// Show reports.
		articulatejq( '.articulate-progress' ).hide();
		articulatejq( '.tblScore' ).fadeIn( 300 );
		articulatejq( '.table-footer' ).css( { opacity: 1 } );
    }, 500 );

});

			(function(window, document, undefined) {

			  var factory = function($, DataTable) {

			    "use strict";


			    $('.search-toggle').click(function() {
			      if ($('.hiddensearch').css('display') == 'none')
			        $('.hiddensearch').slideDown();
			      else
			        $('.hiddensearch').slideUp();
			    });

			    /* Set the defaults for DataTables initialisation */
			    $.extend(true, DataTable.defaults, {
			      dom: "<'hiddensearch'f'>" +
			        "tr"+
			        "<'table-footer'Blip'>",
			      renderer: 'material'
			    });
			    /* Default class modification */
			    $.extend(DataTable.ext.classes, {
			      sWrapper: "dataTables_wrapper",
			      sFilterInput: "form-control input-sm",
			      sLengthSelect: "form-control input-sm"
			    });

			    /* Bootstrap paging button renderer */
			    DataTable.ext.renderer.pageButton.material = function(settings, host, idx, buttons, page, pages) {
			      var api = new DataTable.Api(settings);
			      var classes = settings.oClasses;
			      var lang = settings.oLanguage.oPaginate;
			      var btnDisplay, btnClass, counter = 0;

			      var attach = function(container, buttons) {
			        var i, ien, node, button;
			        var clickHandler = function(e) {
			          e.preventDefault();
			          if (!$(e.currentTarget).hasClass('disabled')) {
			            api.page(e.data.action).draw(false);
			          }
			        };

			        for (i = 0, ien = buttons.length; i < ien; i++) {
			          button = buttons[i];

			          if ($.isArray(button)) {
			            attach(container, button);
			          } else {
			            btnDisplay = '';
			            btnClass = '';

			            switch (button) {

			              case 'first':
			                btnDisplay = lang.sFirst;
			                btnClass = button + (page > 0 ?
			                  '' : ' disabled');
			                break;

			              case 'previous':
			                btnDisplay = '<i class="material-icons">chevron_left</i>';
			                btnClass = button + (page > 0 ?
			                  '' : ' disabled');
			                break;

			              case 'next':
			                btnDisplay = '<i class="material-icons">chevron_right</i>';
			                btnClass = button + (page < pages - 1 ?
			                  '' : ' disabled');
			                break;

			              case 'last':
			                btnDisplay = lang.sLast;
			                btnClass = button + (page < pages - 1 ?
			                  '' : ' disabled');
			                break;

			            }

			            if (btnDisplay) {
			              node = $('<li>', {
			                  'class': classes.sPageButton + ' ' + btnClass,
			                  'id': idx === 0 && typeof button === 'string' ?
			                    settings.sTableId + '_' + button : null
			                })
			                .append($('<a>', {
			                    'href': '#',
			                    'aria-controls': settings.sTableId,
			                    'data-dt-idx': counter,
			                    'tabindex': settings.iTabIndex
			                  })
			                  .html(btnDisplay)
			                )
			                .appendTo(container);

			              settings.oApi._fnBindAction(
			                node, {
			                  action: button
			                }, clickHandler
			              );

			              counter++;
			            }
			          }
			        }
			      };

			      // IE9 throws an 'unknown error' if document.activeElement is used
			      // inside an iframe or frame.
			      var activeEl;

			      try {
			        // Because this approach is destroying and recreating the paging
			        // elements, focus is lost on the select button which is bad for
			        // accessibility. So we want to restore focus once the draw has
			        // completed
			        activeEl = $(document.activeElement).data('dt-idx');
			      } catch (e) {}

			      attach(
			        $(host).empty().html('<ul class="material-pagination"/>').children('ul'),
			        buttons
			      );

			      if (activeEl) {
			        $(host).find('[data-dt-idx=' + activeEl + ']').focus();
			      }
			    };

			    /*
			     * TableTools Bootstrap compatibility
			     * Required TableTools 2.1+
			     */
			    if (DataTable.TableTools) {
			      // Set the classes that TableTools uses to something suitable for Bootstrap
			      $.extend(true, DataTable.TableTools.classes, {
			        "container": "DTTT btn-group",
			        "buttons": {
			          "normal": "btn btn-default",
			          "disabled": "disabled"
			        },
			        "collection": {
			          "container": "DTTT_dropdown dropdown-menu",
			          "buttons": {
			            "normal": "",
			            "disabled": "disabled"
			          }
			        },
			        "print": {
			          "info": "DTTT_print_info"
			        },
			        "select": {
			          "row": "active"
			        }
			      });

			      // Have the collection use a material compatible drop down
			      $.extend(true, DataTable.TableTools.DEFAULTS.oTags, {
			        "collection": {
			          "container": "ul",
			          "button": "li",
			          "liner": "a"
			        }
			      });
			    }

			  }; // /factory

			  // Define as an AMD module if possible
				  if (typeof define === 'function' && define.amd) {
				    define(['jquery', 'datatables'], factory);
				  } else if (typeof exports === 'object') {
				    // Node/CommonJS
				    factory(require('jquery'), require('datatables'));
				  } else if (jQuery) {
				    // Otherwise simply initialise as normal, stopping multiple evaluation
				    factory(jQuery, jQuery.fn.dataTable);
				  }

			})(window, document);



			articulatejq(document).ready(function() {
			  articulatejq('#datatable').dataTable({
					"oLanguage": {
					  "sSearch": "",
					  "sSearchPlaceholder": "Search...",
			      "sInfo": "_START_ -_END_ of _TOTAL_",
			      "sLengthMenu": '<span>Reports per page:</span><select class="md-select">' +
			        '<option value="25">25</option>' +
			        '<option value="50">50</option>' +
			        '<option value="75">75</option>' +
			        '<option value="100">100</option>' +
			        '<option value="-1">All</option>' +
			        '</select></div>'
					},
					"pageLength" : 25,
					"bAutoWidth": false,
					"bPaginate": true,
					"bInfo": true,
					"buttons": [],
					"order": [[ 3, "desc" ]]
				});
				articulatejq('.md-select').formSelect();
			});