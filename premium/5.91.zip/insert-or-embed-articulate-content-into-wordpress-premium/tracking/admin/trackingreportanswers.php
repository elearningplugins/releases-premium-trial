<?php
class TrackingReportAnswers {
	public function showReport() {
		error_reporting( error_reporting() & ~E_NOTICE );
		$user   = $_GET['user'];
		$course = $_GET['course']; // course is now the uuid (context_registration) instead of title
		if ( ! isset( $user ) ) {
			$traclingReportsScore = new TrackingReportScore();
			$traclingReportsScore->showReport();
			if ( isset( $course ) ) {
				$this->showRunReportButton();
			}
		} else {
			$this->showAttemptReport();
		}
	}

	private function showRunReportButton() {
		$page   = $_GET['page'];
		$report = $_GET['report'];
		$course = $_GET['course'];
		?>
		<form method="GET">
			<input type="hidden" name="page" value="<?php echo $page; ?>" />
			<input type="hidden" name="report" value="<?php echo $report; ?>" />
			<input type="hidden" name="course" value="<?php echo $course; ?>" />
			<input type="hidden" name="user" id="txtUser" />
			<br/><button type='submit' class="waves-effect waves-light btn hidereport nodisplay">Run Report</button>
		</form>
		<script>
			jQuery(function () {
				var $ = jQuery;
				var rows = $('#tblScore tr');
				var txtUser = $('#txtUser');

				var getCallback = function (r) {
					return function () {
						$('#tblScore .current').removeClass('current');
						r.addClass('current');
						txtUser.val(r[0].dataset.userEmail);
						$('.hidereport').removeClass('nodisplay');
					}
				}

				for (var i = 1; i < rows.length; i++) {
					var row = $(rows[i]);
					row.click(getCallback(row));
				}


			});
		</script>
		<?php
	}

	private function showAttemptReport() {
		global $wpdb;

		$user             = $_GET['user'];
		$course           = $_GET['course'];
		$apiDataProvider  = new ApiDataProvider();
		$statements       = $apiDataProvider->getStatementResultsForActor( $course, $user );
		$statementsHelper = new StatementsHelper();
		$uniqueStatements = $statementsHelper->getBestResultsForEachUser( $statements );
		$statement        = $uniqueStatements[ $user ];
		?>
		<div class="attemptReport">
		<?php

		// get statement which have score in it
		$s        = $this->get_score_statement( $user, $course, $statement );
		$stmt_arr = json_decode( $s, true );

		 // CG: ['object']['definition']['name'] sometimes does not exist in the statements
		 $course_name = isset( $stmt_arr['object']['definition']['name'] ) ? $this->getfirstValue( $stmt_arr['object']['definition']['name'] ) : '';

		/**
		 * use old method only if course name does not match
		 */
		 $s = $stmt_arr;
		if ( $course_name != $course ) {
			$s = $statement;
		}

		$this->showOverallInformation( $user, $course, $statement );

		$actormbox          = 'mailto:' . $user;
		$query2             = "SELECT * FROM {$wpdb->prefix}quiz_lrs_status WHERE actor_mbox = '$actormbox' AND context_registration = '$course'";
		$results_status_tbl = $wpdb->get_results( $query2, OBJECT );

		// should return only one result
		$status = '';
		foreach ( $results_status_tbl as $key => $stmnt ) {
			$status = $stmnt->status;
		}

		if ( isset( $_GET['attempted'] ) && $_GET['attempted'] === 'yes' ) {
			$this->showAttemptAnswers( $user, $course, $statement );
		} elseif ( in_array( $status, array( 'passed', 'failed', 'completed' ) ) ) {
			$this->showAnswers( $user, $course, $statement );
		}

		?>
		</div>
		<?php
	}

	private function showAttemptAnswers( $user, $uuid, $statement ) {

		$apiDataProvider = new ApiDataProvider();
		$answersRaw      = $apiDataProvider->getAnswersForRegistration( $uuid, $user );

		$answers          = $answersRaw['result'];
		$statementsHelper = new StatementsHelper();
		// $attemptAnswers   = $statementsHelper->getAttemptQuestionResults( $answers, $statement['timestamp'] );
		$attemptAnswers = $answers;
		$position       = 0;

		// show questions
		$tests     = array();
		$responses = array();

		foreach ( $attemptAnswers as $answer ) {

			$statement       = $answer['statement'];
			$interactionType = $statement['object']['definition']['interactionType'];
			$name            = $statement['object']['definition']['name']['und'];
			if ( ! in_array( $name, $tests ) ) {
				$tests[]        = $name;
				$responses[1][] = $answer;
			} else {
				$tests[]               = $name;
				$counts                = array_count_values( $tests );
				$count                 = $counts[ $name ];
				$responses[ $count ][] = $answer;
			}
		}

		if ( ! empty( $responses ) ) {
			$highest = max( array_keys( $responses ) );

			foreach ( $responses[ $highest ] as $answer ) {
				$this->showAnswer( $answer, $position );
				$position++;
			}
		}

	}

	private function showAnswers( $user, $uuid, $statement ) {

		$apiDataProvider = new ApiDataProvider();
		$answersRaw      = $apiDataProvider->getAnswersForRegistration( $uuid, $user );

		$answers          = $answersRaw['result'];
		$statementsHelper = new StatementsHelper();
		// $attemptAnswers   = $statementsHelper->getAttemptQuestionResults( $answers, $statement['timestamp'] );
		$attemptAnswers = $answers;
		$position       = 0;

		// show questions
		$tests     = array();
		$responses = array();

		foreach ( $attemptAnswers as $answer ) {

			$statement       = $answer['statement'];
			$interactionType = $statement['object']['definition']['interactionType'];
			if ( $interactionType == 'choice' ) {
				$preparedAnswer = $this->prepareChoiceAnswer( $statement );
			} elseif ( $interactionType == 'matching' ) {
				$preparedAnswer = $this->prepareMatchingAnswer( $statement );
			} elseif ( $interactionType == 'sequencing' ) {
				$preparedAnswer = $this->prepareSequencingAnswer( $statement );
			} elseif ( $interactionType == 'likert' ) {
				$preparedAnswer = $this->prepareLikertAnswer( $statement );
			} else {
				$preparedAnswer = $this->prepareTextAnswer( $statement );
			}
			if ( $preparedAnswer['isCorrect'] ) {
				$answer['score'] = 1;
			} else {
				$answer['score'] = 0;
			}

			$name = $statement['object']['definition']['name']['und'];

			if ( ! in_array( $name, $tests ) ) {
				$tests[]        = $name;
				$responses[1][] = $answer;
			} else {
				$tests[]               = $name;
				$counts                = array_count_values( $tests );
				$count                 = $counts[ $name ];
				$responses[ $count ][] = $answer;
			}
		}

		$scores = array();
		foreach ( $responses as $group => $answers ) {
			$all_score = 0;
			foreach ( $answers as $key => $answer ) {
				$all_score = $all_score + absint( $answer['score'] );
			}
			$scores[ $group ] = $all_score;
		}

		if ( ! empty( $scores ) ) {
			$value = max( $scores );
			$key   = array_search( $value, $scores );
			$best  = $key;
		}

		if ( ! empty( $best ) ) {
			foreach ( $responses[ $best ] as $answer ) {
				$this->showAnswer( $answer, $position );
				$position++;
			}
		}

	}

	private function showAnswer( $answer, $position ) {
		?>
		<div class="item">
		<?php
		$is_survey       = false;
		$statement       = $answer['statement'];
		$interactionType = $statement['object']['definition']['interactionType'];

		if ( $interactionType == 'choice' ) {
			$preparedAnswer = $this->prepareChoiceAnswer( $statement );
		} elseif ( $interactionType == 'matching' ) {
			$preparedAnswer = $this->prepareMatchingAnswer( $statement );
		} elseif ( $interactionType == 'sequencing' ) {
			$preparedAnswer = $this->prepareSequencingAnswer( $statement );
		} elseif ( $interactionType == 'likert' ) {
			$preparedAnswer = $this->prepareLikertAnswer( $statement );
		} else {
			$preparedAnswer = $this->prepareTextAnswer( $statement );
		}

		if ( isset( $statement['result']['success'] ) ) {
			$answeredCorrectlyorIncorrectlyTrueFalse = $statement['result']['success'];
			if ( $answeredCorrectlyorIncorrectlyTrueFalse = 'false' ) {
				$is_survey = false;
			}
		} else {
			$is_survey = true;
		}

		$this->showAnswerHtml( $preparedAnswer, $position, $is_survey );
		?>
		</div>
		<?php
	}

	private function prepareChoiceAnswer( $statement ) {
		$correctResponsesPattern = $statement['object']['definition']['correctResponsesPattern'];
		$correctResponses        = explode( '[,]', $correctResponsesPattern[0] );
		$isUserRespondCorrectly  = $statement['result']['success'] == 'true';
		$userResponses           = explode( '[,]', $statement['result']['response'] );
		$result                  = array(
			'isCorrect' => $isUserRespondCorrectly,
			'type'      => 'Multiple choice',
			'points'    => isset( $statement['result']['score']['raw'] ) ? $statement['result']['score']['raw'] : '',
			'choices'   => array(),
			'text'      => $this->getfirstValue( $statement['object']['definition']['name'] ),
		);
		if ( isset( $statement['object']['definition']['choices'] ) ) {
			foreach ( $statement['object']['definition']['choices'] as $choice ) {
				$userChoice    = in_array( $choice['id'], $userResponses );
				$correctChoice = in_array( $choice['id'], $correctResponses );
				$choice        = array(
					'isUser'    => $userChoice,
					'isCorrect' => $correctChoice,
					'text'      => $this->getfirstValue( $choice['description'] ),
				);
				array_push( $result['choices'], $choice );
			}
		}

		// check if still not choice avialible for rise
		$choice_available = count( $result['choices'] );
		if ( ! $choice_available ) {
			// get from xml
			$course                 = $_GET['course'];
			$quiz                   = $this->getfirstValue( $statement['object']['definition']['name'] );
			$cn                     = $this->quiz_options( $course, $quiz, $statement );
			$correctResponsePattern = $cn[0]['choices_xml']['correctResponsePatterns']['correctResponsePattern'];
			$userResponse           = $statement['result']['response'];
			// loop through choices and create new array
			if ( is_array( $cn[0]['choices_xml']['choices']['component'] ) ) {
				$z = 1;
				foreach ( $cn[0]['choices_xml']['choices']['component'] as $ck => $cv ) {
					$isCorrect = 0;
					if ( $correctResponsePattern == $cv['id'] ) {
						$isCorrect = 1;
					}
					$isUser = 0;
					if ( $z == $userResponse ) {
						$isUser = 1;
					}
					$userChoice = array(
						'isUser'    => $isUser,
						'isCorrect' => $isCorrect,
						'text'      => $cv['description'],
					);
					array_push( $result['choices'], $userChoice );
					$z++;
				}
			}
		}

		return $result;
	}

	private function prepareLikertAnswer( $statement ) {
		$correctResponsesPattern = $statement['object']['definition']['correctResponsesPattern'];
		$correctResponses        = explode( '[,]', $correctResponsesPattern[0] );
		$isUserRespondCorrectly  = $statement['result']['success'] == 'true';
		$userResponses           = explode( '[,]', $statement['result']['response'] );
		$result                  = array(
			'isCorrect' => $isUserRespondCorrectly,
			'type'      => 'Multiple choice',
			'points'    => $statement['result']['score']['raw'],
			'choices'   => array(),
			'text'      => $this->getfirstValue( $statement['object']['definition']['name'] ),
		);
		foreach ( $statement['object']['definition']['scale'] as $choice ) {
			$userChoice    = in_array( $choice['id'], $userResponses );
			$correctChoice = in_array( $choice['id'], $correctResponses );
			$choice        = array(
				'isUser'    => $userChoice,
				'isCorrect' => $correctChoice,
				'text'      => $this->getfirstValue( $choice['description'] ),
			);
			array_push( $result['choices'], $choice );
		}
		return $result;
	}

	private function prepareMatchingAnswer( $statement ) {
		$correctResponsesPattern   = $statement['object']['definition']['correctResponsesPattern'];
		$correctResponseChoiceText = $this->getMatchingText( $statement, $correctResponsesPattern[0] );
		$isUserRespondCorrectly    = $statement['result']['success'] == 'true';
		$result                    = array(
			'isCorrect' => $isUserRespondCorrectly,
			'type'      => 'Matching',
			'points'    => isset( $statement['result']['score']['raw'] ) ? $statement['result']['score']['raw'] : '',
			'choices'   => array(),
			'text'      => $this->getfirstValue( $statement['object']['definition']['name'] ),
		);
		$choice                    = array(
			'isUser'    => $isUserRespondCorrectly,
			'isCorrect' => true,
			'text'      => $correctResponseChoiceText,
		);
		array_push( $result['choices'], $choice );
		if ( ! $isUserRespondCorrectly ) {
			$userResponseChoiceText = $this->getMatchingText( $statement, $statement['result']['response'] );
			$choice                 = array(
				'isUser'    => true,
				'isCorrect' => false,
				'text'      => $userResponseChoiceText,
			);
			array_push( $result['choices'], $choice );
		}
		return $result;
	}

	private function getMatchingText( $statement, $pattern ) {
		$choiceText = '';
		$patternArr = explode( '[,]', $pattern );
		foreach ( $patternArr as $pairStr ) {
			$pairArr  = explode( '[.]', $pairStr );
			$sourceId = $pairArr[0];
			$targetId = $pairArr[1];
			foreach ( $statement['object']['definition']['source'] as $source ) {
				if ( $source['id'] == $sourceId ) {
					$choiceText = $this->getfirstValue( $choiceText . $source['description'] );
				}
			}
			$choiceText = $choiceText . ' => ';
			foreach ( $statement['object']['definition']['target'] as $target ) {
				if ( $target['id'] == $targetId ) {
					$choiceText = $this->getfirstValue( $choiceText . $target['description'] );
				}
			}
			$choiceText = $choiceText . ', ';
		}
		$result = substr( $choiceText, 0, strlen( $choiceText ) - 2 );
		return $result;
	}

	private function prepareSequencingAnswer( $statement ) {
		$correctResponsesPattern   = $statement['object']['definition']['correctResponsesPattern'];
		$correctResponseChoiceText = $this->getSequencingText( $statement, $correctResponsesPattern[0] );
		$isUserRespondCorrectly    = $statement['result']['success'] == 'true';
		$result                    = array(
			'isCorrect' => $isUserRespondCorrectly,
			'type'      => 'Sequencing',
			'points'    => $statement['result']['score']['raw'],
			'choices'   => array(),
			'text'      => $this->getfirstValue( $statement['object']['definition']['name'] ),
		);
		$choice                    = array(
			'isUser'    => $isUserRespondCorrectly,
			'isCorrect' => true,
			'text'      => $correctResponseChoiceText,
		);
		array_push( $result['choices'], $choice );
		if ( ! $isUserRespondCorrectly ) {
			$userResponseChoiceText = $this->getSequencingText( $statement, $statement['result']['response'] );
			$choice                 = array(
				'isUser'    => true,
				'isCorrect' => false,
				'text'      => $userResponseChoiceText,
			);
			array_push( $result['choices'], $choice );
		}
		return $result;
	}

	private function getSequencingText( $statement, $pattern ) {
		$choiceText = '';
		$patternArr = explode( '[,]', $pattern );
		foreach ( $patternArr as $choiceId ) {
			foreach ( $statement['object']['definition']['choices'] as $choices ) {
				if ( $choices['id'] == $choiceId ) {
					$choiceText = $this->getfirstValue( $choiceText . $choices['description'] );
				}
			}
			$choiceText = $choiceText . ' => ';
		}
		$result = substr( $choiceText, 0, strlen( $choiceText ) - 4 );
		return $result;
	}

	private function prepareTextAnswer( $statement ) {
		$isUserRespondCorrectly  = $statement['result']['success'] == 'true';
		$correctResponsesPattern = isset( $statement['object']['definition']['correctResponsesPattern'] ) ? $statement['object']['definition']['correctResponsesPattern'] : array();
		$result                  = array(
			'isCorrect' => $isUserRespondCorrectly,
			'type'      => 'Fill in',
			'points'    => isset( $statement['result']['score']['raw'] ) ? $statement['result']['score']['raw'] : '',
			'choices'   => array(),
			'text'      => $this->getfirstValue( $statement['object']['definition']['name'] ),
		);
		$correctChoice           = array(
			'isUser'    => $isUserRespondCorrectly,
			'isCorrect' => true,
			'text'      => $isUserRespondCorrectly && empty( $correctResponsesPattern[0] ) ? $statement['result']['response'] : $correctResponsesPattern[0],
		);
		array_push( $result['choices'], $correctChoice );
		if ( ! $isUserRespondCorrectly ) {
			$userChoice = array(
				'isUser'    => true,
				'isCorrect' => false,
				'text'      => $statement['result']['response'],
			);
			array_push( $result['choices'], $userChoice );
		}

		return $result;
	}

	private function showAnswerHtml( $preparedAnswer, $position, $is_survey = false ) {
		$questionClass = $preparedAnswer['isCorrect'] ? 'correctQuestion' : 'wrongQuestion';
		?>
			  <?php
				if ( $questionClass != 'wrongQuestion' ) {
					echo '<div class="questionResult"><i class="small material-icons teal lighten-2">done</i></div>';
				} else {
					if ( $is_survey ) {
						echo '<div class="questionResult"><i class="small material-icons black" style="color:black;">content_paste</i></div>';
					} else {
						echo '<div class="questionResult wrongQuestion"><i class="small material-icons pink lighten-2">error</i></div>';
					}
				}
				?>

	<span class="question"><?php echo $position + 1; ?>. <?php echo $preparedAnswer['text']; ?></span><span class='type'> (<?php echo $preparedAnswer['type']; ?>
		<?php
		if ( ! $is_survey && ! $preparedAnswer['points'] == '0' || $preparedAnswer['points'] == '0' ) {
			echo ' &mdash; ' . $preparedAnswer['points'] . ' points';
		} else {
			if ( $preparedAnswer['points'] == '' && ! $is_survey ) {
				echo '&mdash; points not available';
			} else {
				echo '&mdash; UNGRADED';
			}
		}
		?>
		)</span>
		<table class="striped bordered highlight">
			<tr>
				<th></th>
				<th class="correctColumn">Correct Response</th>
				<th class="userColumn">User Response</th>
			</tr>
			<?php
			foreach ( $preparedAnswer['choices'] as $choice ) {
				?>
			<tr>
				<td><?php echo $choice['text']; ?></td>
				<td>
				<?php
				if ( $choice['isCorrect'] ) {
					?>
					<i class="small material-icons">done</i><?php } ?></td>
				<td>
				<?php
				if ( $choice['isUser'] ) {
					?>
					<i class="small material-icons">perm_identity</i><?php } ?></td>
			</tr>
				<?php
			}
			?>
		</table>
		<?php
	}

	private function showOverallInformation( $user, $uuid, $statement ) {
		global $wpdb;

		$statementsHelper = new StatementsHelper();

		$actormbox          = 'mailto:' . $user;
		$query2             = "SELECT * FROM {$wpdb->prefix}quiz_lrs_status WHERE actor_mbox = '$actormbox' AND context_registration = '$uuid'";
		$results_status_tbl = $wpdb->get_results( $query2, OBJECT );

		if ( isset( $_GET['attempted'] ) && $_GET['attempted'] === 'yes' ) {
			$query2             = "SELECT * FROM {$wpdb->prefix}quiz_lrs_statements_expand WHERE context_registration = '$uuid' AND actor_mbox = '$actormbox' AND verb_display = 'attempted' ORDER BY st_timestamp DESC LIMIT 1";
			$results_status_tbl = $wpdb->get_results( $query2, OBJECT );
		}

		// should return only one result
		foreach ( $results_status_tbl as $key => $stmnt ) {
				$statementId = $stmnt->statementId;
				$context     = $stmnt->context_registration;
				$course_name = $stmnt->course_name;
				$user_name   = isset( $stmnt->user_name ) ? $stmnt->user_name : '';
				$actor_mbox  = $stmnt->actor_mbox;
				$status      = isset( $stmnt->status ) ? $stmnt->status : '';
				$score       = isset( $stmnt->score ) ? $stmnt->score : '';
				$timestamp   = $stmnt->st_timestamp;
				$user        = str_replace( 'mailto:', '', $actor_mbox );

				$userdata  = get_user_by( 'email', $user );
				$user_name = '';
			if ( $userdata->user_firstname != '' && $userdata->user_lastname != '' ) {
				$user_name = $userdata->user_firstname . ' ' . $userdata->user_lastname;
			} elseif ( $userdata->user_firstname != '' ) {
				$user_name = $userdata->user_firstname;
			} elseif ( $userdata->user_lastname != '' ) {
				$user_name = $userdata->user_lastname;
			}
			if ( $user_name == '' && $userdata->user_nicename != '' ) {
				$user_name = $userdata->user_nicename;
			}

			if ( $user_name == '' ) {
				$user_name = 'Anonymous';
			}
		}

		?>
		<h2 class="header">
		<?php

		echo $course_name;
		$safe_user = htmlspecialchars( $user );

		$duration = $statementsHelper->getDurationStr( $statement );

		?>
		
		</h2>
		<h4 class="header">Attempt detail for <?php echo $user_name; ?> (<?php echo $safe_user; ?>) on <?php echo $timestamp; ?> </h4>
		<table class="striped bordered highlight">
			<tr>
				<td>Duration:</td>
				<td><?php echo isset( $_GET['attempted'] ) && $_GET['attempted'] === 'yes' ? 'N/A' : $duration; ?></td>
			</tr>
			<tr>
				<td>Score:</td>
				<td>
				<?php

				echo isset( $_GET['attempted'] ) && $_GET['attempted'] === 'yes' ? 'N/A' : $score;

				?>
			</td>
			</tr>
			<tr>
				<td>Passing score:</td>
				<td>N/A</td>
			</tr>
			<tr>
				<td>Status:</td>
				<td>
				<?php

				echo isset( $_GET['attempted'] ) && $_GET['attempted'] === 'yes' ? 'Incomplete' : ucfirst( $status );

				?>
				</td>
			</tr>
		</table>
		<?php
	}
	/**
	 * Return first array value , so no need to name
	 */
	private function getfirstValue( $array ) {
		   $r = '';
		if ( is_array( $array ) ) {
			$first_key = array_key_first( $array );
		}
		if ( isset( $first_key ) ) {
			$r = $array[ $first_key ];
		}

		return $r;
	}
	 /**
	  * get all course with xml
	  */
	private function all_course_with_xml() {

		$n = $o = array();
		// get all xml file folder
		$upload_dir = wp_upload_dir();
		$dir        = '' . $upload_dir['basedir'] . '/articulate_uploads';
		$i          = 0;
		foreach ( new DirectoryIterator( $dir ) as $fileInfo ) {
			if ( ! $fileInfo->isDot() ) {
				if ( $fileInfo->isDir() ) {
					$folder_name = $fileInfo->getFilename();
					$course_dir  = $dir . DIRECTORY_SEPARATOR . $folder_name;
					$xml_path    = $course_dir . DIRECTORY_SEPARATOR . 'tincan.xml';
					$name        = '';
					if ( file_exists( $xml_path ) ) {
						$xml_string = file_get_contents( $xml_path );
						$xml        = simplexml_load_string( $xml_string );
						$json       = json_encode( $xml );
						$xml_array  = json_decode( $json, true );

						if ( isset( $xml_array['activities']['activity']['name'] ) ) {
							$name = $xml_array['activities']['activity']['name'];
						}

						if ( isset( $xml_array['activities']['activity'][0]['name'] ) ) {
							$name = $xml_array['activities']['activity'][0]['name'];
						}
					}

					// get uuid
					$uuid_path = $course_dir . DIRECTORY_SEPARATOR . 'uuid.txt';
					if ( file_exists( $xml_path ) ) {
						$uuid = file_get_contents( $uuid_path );
					}

					$n[ $i ]['name']       = $name;
					$n[ $i ]['course_dir'] = $course_dir;
					$n[ $i ]['uuid']       = $uuid;
					$n[ $i ]['course']     = $course;
					$n[ $i ]['xml']        = $xml_array;

					$i++;

				}
			}
		}
		return $n;
	}

	 // get all quiz and xml file
	private function quiz_options( $course, $quiz, $s ) {

		$n = $o = array();
		// get all xml file folder
		$upload_dir = wp_upload_dir();
		$dir        = '' . $upload_dir['basedir'] . '/articulate_uploads';
		$i          = 0;
		foreach ( new DirectoryIterator( $dir ) as $fileInfo ) {
			if ( ! $fileInfo->isDot() ) {
				if ( $fileInfo->isDir() ) {
					$folder_name = $fileInfo->getFilename();
					$course_dir  = $dir . DIRECTORY_SEPARATOR . $folder_name;
					$xml_path    = $course_dir . DIRECTORY_SEPARATOR . 'tincan.xml';
					$name        = '';
					if ( file_exists( $xml_path ) ) {
						$xml_string = file_get_contents( $xml_path );
						$xml        = simplexml_load_string( $xml_string );
						$json       = json_encode( $xml );
						$xml_array  = json_decode( $json, true );

						if ( isset( $xml_array['activities']['activity']['name'] ) ) {
							$name = $xml_array['activities']['activity']['name'];
						}

						if ( isset( $xml_array['activities']['activity'][0]['name'] ) ) {
							$name = $xml_array['activities']['activity'][0]['name'];
						}
					}

					// get uuid
					$uuid_path = $course_dir . DIRECTORY_SEPARATOR . 'uuid.txt';
					$uuid      = file_get_contents( $uuid_path );

					// add to array only if there is name
					if ( ! empty( $name ) && $name == $course ) {

						// loop through xml to get choice array
						foreach ( $xml_array['activities']['activity'] as $k => $v ) {
							if ( $v['name'] == $quiz ) {
								$choices_xml = $v;
							}
						}
						$n[ $i ]['name']       = $name;
						$n[ $i ]['course_dir'] = $course_dir;
						$n[ $i ]['uuid']       = $uuid;
						$n[ $i ]['course']     = $course;
						$n[ $i ]['quiz']       = $quiz;

						$n[ $i ]['choices_xml'] = $choices_xml;

						$i++;
					}
				}
			}
		}
		return $n;
	}

	// CG: $course is now uuid/context_registration
	public function get_score_statement( $user, $course, $statement ) {
		global $wpdb;
		$context = $statement['context']['registration'];
		// check expand table for use and passed verb with given context

		$table1 = $wpdb->prefix . 'quiz_lrs_statements_expand';
		$rows   = $wpdb->get_results( "SELECT * FROM $table1 WHERE context_registration = '$context' and actor_mbox='mailto:$user'", ARRAY_A );
		$res    = array();
		foreach ( $rows as $rs ) {
			// get last id only ,so see latest attempt result
			$total_index = count( $rows );
			$stmntID     = $rs['statementId'];
			// get statement from statement table
			$table2 = $wpdb->prefix . 'quiz_lrs_statements';
			$rows2  = $wpdb->get_results( "SELECT * FROM $table2 WHERE statementId = '$stmntID' ", ARRAY_A );

			if ( $rows2[0]['statement'] ) {
				$rs['course_name']                = $_GET['course'];
				$rs['object_definition_name_und'] = $_GET['course'];
				$rs['statement']                  = json_decode( $rows2[0]['statement'], true );
				$rs['statement1']                 = $rows2[0]['statement'];
				$res[]                            = $rs;
			}
		}

		$r = $res;

		// get best score and return that statement

		$refScore  = 0;
		$refStment = array();
		foreach ( $r as $rkey => $rval ) {
			$score = isset( $rval['statement']['result']['score']['raw'] ) ? $rval['statement']['result']['score']['raw'] : '';
			// in Rise an experienced statment with score is sent after the failed/passed one
			// watch out this causes SL to fail! was if($score>=$refScore){
			// problem is that SL also sends score.raw for individual questions... and only scaled for final quiz
			// override because it is a SL course
			if ( isset( $rval['statement']['result']['score']['scaled'] ) ) {
				$score = $rval['statement']['result']['score']['scaled'] * 100;
			}
			if ( $score > $refScore ) {
				$bigger                 = $score;
				$refStment['index']     = $rkey;
				$refStment['statement'] = $rval['statement1'];
			} else {
				$bigger = $refScore;
			}
			$refScore = $bigger;
		}
		if ( isset( $refStment['statement'] ) ) {
			return $refStment['statement'];
		} else {

		}

		return $rows2[0]['statement'];

	}//end get_score_statement()

	/*
	 * get statement id from expand table
	 */
	public function get_ss_id( $statement ) {
		global $wpdb;
		$id     = $statement['id'];
		$table1 = $wpdb->prefix . 'quiz_lrs_statements_expand';
		$rows   = $wpdb->get_results( "SELECT * FROM $table1 WHERE statementId = '$id'", ARRAY_A );
		return $rows[0]['id'];
	}

}
// some function for checking data in string
function xapi_contains( $needle, $haystack ) {
	return strpos( $haystack, $needle ) !== false;
}
/**
 * create function to check if course is of rise type
 * return : boolean
 */
function is_rise_course( $course_name ) {

	global $wpdb;
		// get statement id
		$table1 = $wpdb->prefix . 'quiz_lrs_statements_expand';
		$table2 = $wpdb->prefix . 'quiz_lrs_statements';
		$rows   = $wpdb->get_results( "SELECT * FROM $table1 WHERE course_name = '$course_name'", ARRAY_A );

	if ( $rows[0]['statementId'] ) {
		$id    = $rows[0]['statementId'];
		$rows2 = $wpdb->get_results( "SELECT * FROM $table2 WHERE statementId = '$id'", ARRAY_A );
	}
	$activity_array = json_decode( $rows2[0]['statement'], true );
	$activity_id    = $activity_array['object']['id'];

	if ( xapi_contains( 'rise', $activity_id ) ) {
		return true;
	}
	return false;

}
require_once 'trackingreportscore.php';
?>
