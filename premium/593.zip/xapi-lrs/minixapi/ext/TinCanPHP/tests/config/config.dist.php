<?php

$LRSs = array(
	array(
		'endpoint' => '',
		'username' => '',
		'password' => '',
		'version'  => '1.0.1',
	),
);
$KEYs = array(
	'public'   => 'path/to/keys/cacert.pem',
	'private'  => 'path/to/keys/privkey.pem',
	'password' => null,
);
