<?php
/*
	Copyright 2014 Rustici Software

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.
*/

namespace TinCanTest;

use TinCan\Activity;
use TinCan\Agent;
use TinCan\Context;
use TinCan\Result;
use TinCan\SubStatement;
use TinCan\Util;
use TinCan\Verb;

class SubStatementTest extends \PHPUnit_Framework_TestCase {
	use TestCompareWithSignatureTrait;

	public function testInstantiation() {
		$obj = new SubStatement();
		$this->assertInstanceOf( 'TinCan\StatementBase', $obj );
	}

	public function testGetObjectType() {
		$obj = new SubStatement();
		$this->assertSame( 'SubStatement', $obj->getObjectType() );
	}

	// TODO: need to loop versions
	public function testAsVersion() {
		$args = array(
			'timestamp' => '2015-01-28T14:23:37.159Z',
			'actor'     => array(
				'mbox' => COMMON_MBOX,
			),
			'verb'      => array(
				'id'      => COMMON_VERB_ID,
				'display' => array(
					'en-US' => 'experienced',
				),
			),
			'object'    => array(
				'id'         => COMMON_ACTIVITY_ID,
				'definition' => array(
					'type'        => 'Invalid type',
					'name'        => array(
						'en-US' => 'Test',
					),
					'description' => array(
						'en-US' => 'Test description',
					),
					'extensions'  => array(
						'http://someuri' => 'some value',
					),
				),
			),
			'context'   => array(
				'contextActivities' => array(
					'parent' => array(
						array(
							'id'         => COMMON_ACTIVITY_ID . '/1',
							'definition' => array(
								'name' => array(
									'en-US' => 'Test: 1',
								),
							),
						),
					),
				),
				'registration'      => Util::getUUID(),
			),
			'result'    => array(
				'completion' => true,
				'success'    => false,
				'score'      => array(
					'raw'    => '97',
					'min'    => '65',
					'max'    => '100',
					'scaled' => '.97',
				),
			),
		);

		$obj = SubStatement::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );

		$versioned = $obj->asVersion( '1.0.0' );

		$args['objectType']           = 'SubStatement';
		$args['timestamp']            = $obj->getTimestamp();
		$args['actor']['objectType']  = 'Agent';
		$args['object']['objectType'] = 'Activity';
		$args['context']['contextActivities']['parent'][0]['objectType'] = 'Activity';

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testAsVersionEmpty() {
		$args = array();

		$obj       = SubStatement::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$args['objectType'] = 'SubStatement';

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testAsVersionEmptySubObjects() {
		$args = array(
			'actor'   => array(
				'mbox' => COMMON_MBOX,
			),
			'verb'    => array(
				'id'      => COMMON_VERB_ID,
				'display' => array(),
			),
			'object'  => array(
				'id'         => COMMON_ACTIVITY_ID,
				'definition' => array(
					'type'        => 'Invalid type',
					'name'        => array(),
					'description' => array(),
					'extensions'  => array(),
				),
			),
			'context' => array(
				'contextActivities' => array(
					'parent' => array(),
				),
				'registration'      => Util::getUUID(),
			),
			'result'  => array(
				'completion' => true,
				'success'    => false,
				'score'      => array(),
			),
		);

		$obj       = SubStatement::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$args['objectType']           = 'SubStatement';
		$args['actor']['objectType']  = 'Agent';
		$args['object']['objectType'] = 'Activity';
		unset( $args['verb']['display'] );
		unset( $args['object']['definition']['name'] );
		unset( $args['object']['definition']['description'] );
		unset( $args['object']['definition']['extensions'] );
		unset( $args['context']['contextActivities'] );
		unset( $args['result']['score'] );

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testAsVersionSubObjectWithEmptyValue() {
		$args = array(
			'actor'   => array(
				'mbox' => COMMON_MBOX,
			),
			'verb'    => array(
				'id' => COMMON_VERB_ID,
			),
			'object'  => array(
				'id'         => COMMON_ACTIVITY_ID,
				'definition' => array(
					'type' => 'Invalid type',
					'name' => array(
						'en-US' => '',
					),
				),
			),
			'context' => array(
				'contextActivities' => array(),
			),
			'result'  => array(
				'completion' => true,
				'success'    => false,
				'score'      => array(
					'raw' => 0,
				),
			),
		);

		$obj       = SubStatement::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$args['objectType']           = 'SubStatement';
		$args['actor']['objectType']  = 'Agent';
		$args['object']['objectType'] = 'Activity';
		unset( $args['context'] );

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}


	public function testCompareWithSignature() {
		$actor1               = new Agent(
			array( 'mbox' => COMMON_MBOX )
		);
		$actor2               = new Agent(
			array(
				'account' => array(
					'homePage' => COMMON_ACCT_HOMEPAGE,
					'name'     => COMMON_ACCT_NAME,
				),
			)
		);
		$verb1                = new Verb(
			array( 'id' => COMMON_VERB_ID )
		);
		$verb2                = new Verb(
			array( 'id' => COMMON_VERB_ID . '/2' )
		);
		$activity1            = new Activity(
			array( 'id' => COMMON_ACTIVITY_ID )
		);
		$activity2            = new Activity(
			array( 'id' => COMMON_ACTIVITY_ID . '/2' )
		);
		$context1             = new Context(
			array( 'registration' => Util::getUUID() )
		);
		$context2             = new Context(
			array(
				'contextActivities' => array(
					array( 'parent' => array( COMMON_ACTIVITY_ID . '/parent' ) ),
					array( 'grouping' => array( COMMON_ACTIVITY_ID ) ),
				),
			)
		);
		$result1              = new Result(
			array( 'raw' => 87 )
		);
		$result2              = new Result(
			array( 'response' => 'a' )
		);
		$timestamp1           = '2015-01-28T14:23:37.159Z';
		$timestamp1_tz        = '2015-01-28T08:23:37.159-06:00';
		$timestamp1_subsecond = '2015-01-28T14:23:37.348Z';
		$timestamp2           = '2015-01-28T15:49:11.089Z';

		$full = array(
			'actor'     => $actor1,
			'verb'      => $verb1,
			'target'    => $activity1,
			'context'   => $context1,
			'result'    => $result1,
			'timestamp' => $timestamp1,
		);

		$cases = array(
			array(
				'description' => 'all null',
				'objArgs'     => array(),
			),
			array(
				'description' => 'actor',
				'objArgs'     => array( 'actor' => $actor1 ),
			),
			array(
				'description' => 'verb',
				'objArgs'     => array( 'verb' => $verb1 ),
			),
			array(
				'description' => 'object',
				'objArgs'     => array( 'target' => $activity1 ),
			),
			array(
				'description' => 'result',
				'objArgs'     => array( 'result' => $result1 ),
			),
			array(
				'description' => 'context',
				'objArgs'     => array( 'context' => $context1 ),
			),
			array(
				'description' => 'timestamp',
				'objArgs'     => array( 'timestamp' => $timestamp1 ),
			),
			array(
				'description' => 'all',
				'objArgs'     => $full,
			),

			//
			// special case where timestamp marks the same point in time but
			// is provided in a different timezone
			//
			array(
				'description' => 'timestamp timezone difference',
				'objArgs'     => array( 'timestamp' => $timestamp1 ),
				'sigArgs'     => array( 'timestamp' => $timestamp1_tz ),
			),

			//
			// special case where we make sure sub-second precision is handled
			//
			array(
				'description' => 'timestamp subsecond difference',
				'objArgs'     => array( 'timestamp' => $timestamp1 ),
				'sigArgs'     => array( 'timestamp' => $timestamp1_subsecond ),
				'reason'      => 'Comparison of timestamp failed: value is not the same',
			),

			array(
				'description' => 'actor only: mismatch',
				'objArgs'     => array( 'actor' => $actor1 ),
				'sigArgs'     => array( 'actor' => $actor2 ),
				'reason'      => 'Comparison of actor failed: Comparison of mbox failed: value is not the same',
			),
			array(
				'description' => 'verb only: mismatch',
				'objArgs'     => array( 'verb' => $verb1 ),
				'sigArgs'     => array( 'verb' => $verb2 ),
				'reason'      => 'Comparison of verb failed: Comparison of id failed: value is not the same',
			),
			array(
				'description' => 'object only: mismatch',
				'objArgs'     => array( 'target' => $activity1 ),
				'sigArgs'     => array( 'target' => $activity2 ),
				'reason'      => 'Comparison of target failed: Comparison of id failed: value is not the same',
			),
			array(
				'description' => 'result only: mismatch',
				'objArgs'     => array( 'result' => $result1 ),
				'sigArgs'     => array( 'result' => $result2 ),
				'reason'      => 'Comparison of result failed: Comparison of response failed: value not present in this or signature',
			),
			array(
				'description' => 'context only: mismatch',
				'objArgs'     => array( 'context' => $context1 ),
				'sigArgs'     => array( 'context' => $context2 ),
				'reason'      => 'Comparison of context failed: Comparison of registration failed: value not present in this or signature',
			),
			array(
				'description' => 'timestamp only: mismatch',
				'objArgs'     => array( 'timestamp' => $timestamp1 ),
				'sigArgs'     => array( 'timestamp' => $timestamp2 ),
				'reason'      => 'Comparison of timestamp failed: value is not the same',
			),
			array(
				'description' => 'full: actor mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'actor' => $actor2 ) ),
				'reason'      => 'Comparison of actor failed: Comparison of mbox failed: value is not the same',
			),
			array(
				'description' => 'full: verb mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'verb' => $verb2 ) ),
				'reason'      => 'Comparison of verb failed: Comparison of id failed: value is not the same',
			),
			array(
				'description' => 'full: target mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'target' => $activity2 ) ),
				'reason'      => 'Comparison of target failed: Comparison of id failed: value is not the same',
			),
			array(
				'description' => 'full: result mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'result' => $result2 ) ),
				'reason'      => 'Comparison of result failed: Comparison of response failed: value not present in this or signature',
			),
			array(
				'description' => 'full: context mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'context' => $context2 ) ),
				'reason'      => 'Comparison of context failed: Comparison of registration failed: value not present in this or signature',
			),
			array(
				'description' => 'full: timestamp mismatch',
				'objArgs'     => $full,
				'sigArgs'     => array_replace( $full, array( 'timestamp' => $timestamp2 ) ),
				'reason'      => 'Comparison of timestamp failed: value is not the same',
			),
		);
		$this->runSignatureCases( 'TinCan\SubStatement', $cases );
	}
}
