<?php
/*
	Copyright 2014 Rustici Software

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.
*/

namespace TinCanTest;

use TinCan\Agent;
use TinCan\AgentAccount;

class AgentTest extends \PHPUnit_Framework_TestCase {
	use TestCompareWithSignatureTrait;

	public function testInstantiation() {
		$obj = new Agent();
		$this->assertInstanceOf( 'TinCan\Agent', $obj );
		$this->assertAttributeEmpty( 'name', $obj, 'name empty' );
		$this->assertAttributeEmpty( 'mbox', $obj, 'mbox empty' );
		$this->assertAttributeEmpty( 'mbox_sha1sum', $obj, 'mbox_sha1sum empty' );
		$this->assertAttributeEmpty( 'openid', $obj, 'openid empty' );
		$this->assertAttributeEmpty( 'account', $obj, 'account empty' );
	}

	public function testFromJSONInvalidNull() {
		$this->setExpectedException( 'TinCan\JSONParseErrorException' );
		$obj = Agent::fromJSON( null );
	}

	public function testFromJSONInvalidEmptyString() {
		$this->setExpectedException( 'TinCan\JSONParseErrorException' );
		$obj = Agent::fromJSON( '' );
	}

	public function testFromJSONInvalidMalformed() {
		$this->setExpectedException( 'TinCan\JSONParseErrorException' );
		$obj = Agent::fromJSON( '{name:"some value"}' );
	}

	// TODO: need to loop possible configs
	public function testFromJSONInstantiations() {
		$obj = Agent::fromJSON( '{"mbox":"' . COMMON_MBOX . '"}' );
		$this->assertInstanceOf( 'TinCan\Agent', $obj );
		$this->assertSame( COMMON_MBOX, $obj->getMbox(), 'mbox value' );
	}

	// TODO: need to loop versions
	public function testAsVersionMbox() {
		$args = array(
			'mbox' => COMMON_MBOX,
		);

		$obj       = Agent::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$args['objectType'] = 'Agent';

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testAsVersionMboxSha1() {
		$args = array(
			'mbox_sha1sum' => COMMON_MBOX_SHA1,
		);

		$obj       = Agent::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$args['objectType'] = 'Agent';

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testAsVersionAccount() {
		$args = array(
			'account' => array(
				'name'     => COMMON_ACCT_NAME,
				'homePage' => COMMON_ACCT_HOMEPAGE,
			),
		);

		$obj       = Agent::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$args['objectType'] = 'Agent';

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testAsVersionAccountEmptyStrings() {
		$args = array(
			'account' => array(
				'name'     => '',
				'homePage' => '',
			),
		);

		$obj       = Agent::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$args['objectType'] = 'Agent';

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testAsVersionEmptyAccount() {
		$args = array(
			'account' => array(),
		);

		$obj       = Agent::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$args['objectType'] = 'Agent';
		unset( $args['account'] );

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testAsVersionEmpty() {
		$args = array();

		$obj       = Agent::fromJSON( json_encode( $args, JSON_UNESCAPED_SLASHES ) );
		$versioned = $obj->asVersion( '1.0.0' );

		$args['objectType'] = 'Agent';

		$this->assertEquals( $versioned, $args, 'serialized version matches corrected' );
	}

	public function testIsIdentified() {
		$identified = array(
			array(
				'description' => 'mbox',
				'args'        => array( 'mbox' => COMMON_MBOX ),
			),
			array(
				'description' => 'mbox_sha1sum',
				'args'        => array( 'mbox_sha1sum' => COMMON_MBOX_SHA1 ),
			),
			array(
				'description' => 'openid',
				'args'        => array( 'openid' => COMMON_OPENID ),
			),
			array(
				'description' => 'account',
				'args'        => array(
					'account' => array(
						'homePage' => COMMON_ACCT_HOMEPAGE,
						'name'     => COMMON_ACCT_NAME,
					),
				),
			),
		);
		foreach ( $identified as $case ) {
			$obj = new Agent( $case['args'] );
			$this->assertTrue( $obj->isIdentified(), 'identified ' . $case['description'] );
		}

		$notIdentified = array(
			array(
				'description' => 'empty',
				'args'        => array(),
			),
			array(
				'description' => 'name only',
				'args'        => array( 'name' => 'Test' ),
			),
		);
		foreach ( $notIdentified as $case ) {
			$obj = new Agent( $case['args'] );
			$this->assertFalse( $obj->isIdentified(), 'not identified ' . $case['description'] );
		}
	}

	public function testSetMbox() {
		$obj = new Agent();

		$obj->setMbox( COMMON_MBOX );
		$this->assertSame( COMMON_MBOX, $obj->getMbox() );

		$obj->setMbox( COMMON_EMAIL );
		$this->assertSame( COMMON_MBOX, $obj->getMbox() );

		//
		// make sure it doesn't add mailto when null
		//
		$obj->setMbox( null );
		$this->assertAttributeEmpty( 'mbox', $obj );
	}

	public function testGetMbox_sha1sum() {
		$obj = new Agent( array( 'mbox_sha1sum' => COMMON_MBOX_SHA1 ) );
		$this->assertSame( $obj->getMbox_sha1sum(), COMMON_MBOX_SHA1, 'original sha1' );

		$obj = new Agent( array( 'mbox' => COMMON_MBOX ) );
		$this->assertSame( $obj->getMbox_sha1sum(), COMMON_MBOX_SHA1, 'sha1 from mbox' );
	}

	public function testCompareWithSignature() {
		$name  = 'Test Name';
		$acct1 = new AgentAccount(
			array(
				'homePage' => COMMON_ACCT_HOMEPAGE,
				'name'     => COMMON_ACCT_NAME,
			)
		);
		$acct2 = new AgentAccount(
			array(
				'homePage' => COMMON_ACCT_HOMEPAGE,
				'name'     => COMMON_ACCT_NAME . '-diff',
			)
		);

		$cases = array(
			array(
				'description' => 'all null',
				'objArgs'     => array(),
			),
			array(
				'description' => 'mbox',
				'objArgs'     => array( 'mbox' => COMMON_MBOX ),
			),
			array(
				'description' => 'mbox_sha1sum',
				'objArgs'     => array( 'mbox_sha1sum' => COMMON_MBOX_SHA1 ),
			),
			array(
				'description' => 'openid',
				'objArgs'     => array( 'openid' => COMMON_OPENID ),
			),
			array(
				'description' => 'account',
				'objArgs'     => array( 'account' => $acct1 ),
			),
			array(
				'description' => 'mbox with name',
				'objArgs'     => array(
					'mbox' => COMMON_MBOX,
					'name' => $name,
				),
			),
			array(
				'description' => 'mbox_sha1sum with name',
				'objArgs'     => array(
					'mbox_sha1sum' => COMMON_MBOX_SHA1,
					'name'         => $name,
				),
			),
			array(
				'description' => 'openid with name',
				'objArgs'     => array(
					'openid' => COMMON_OPENID,
					'name'   => $name,
				),
			),
			array(
				'description' => 'account with name',
				'objArgs'     => array(
					'account' => $acct1,
					'name'    => $name,
				),
			),
			array(
				'description' => 'mbox with mismatch name',
				'objArgs'     => array(
					'mbox' => COMMON_MBOX,
					'name' => $name,
				),
				'sigArgs'     => array(
					'mbox' => COMMON_MBOX,
					'name' => $name . ' diff',
				),
			),
			array(
				'description' => 'mbox_sha1sum with mismatch name',
				'objArgs'     => array(
					'mbox_sha1sum' => COMMON_MBOX_SHA1,
					'name'         => $name,
				),
				'sigArgs'     => array(
					'mbox_sha1sum' => COMMON_MBOX_SHA1,
					'name'         => $name . ' diff',
				),
			),
			array(
				'description' => 'openid with mismatch name',
				'objArgs'     => array(
					'openid' => COMMON_OPENID,
					'name'   => $name,
				),
				'sigArgs'     => array(
					'openid' => COMMON_OPENID,
					'name'   => $name . ' diff',
				),
			),
			array(
				'description' => 'account with mismatch name',
				'objArgs'     => array(
					'account' => $acct1,
					'name'    => $name,
				),
				'sigArgs'     => array(
					'account' => $acct1,
					'name'    => $name . ' diff',
				),
			),
			array(
				'description' => 'mbox only: mismatch',
				'objArgs'     => array( 'mbox' => COMMON_MBOX ),
				'sigArgs'     => array( 'mbox' => 'diff-' . COMMON_MBOX ),
				'reason'      => 'Comparison of mbox failed: value is not the same',
			),
			array(
				'description' => 'mbox_sha1sum only: mismatch',
				'objArgs'     => array( 'mbox_sha1sum' => COMMON_MBOX_SHA1 ),
				'sigArgs'     => array( 'mbox_sha1sum' => 'diff-' . COMMON_MBOX_SHA1 ),
				'reason'      => 'Comparison of mbox_sha1sum failed: value is not the same',
			),
			array(
				'description' => 'openid only: mismatch',
				'objArgs'     => array( 'openid' => COMMON_OPENID ),
				'sigArgs'     => array( 'openid' => COMMON_OPENID . 'diff/' ),
				'reason'      => 'Comparison of openid failed: value is not the same',
			),
			array(
				'description' => 'account only: mismatch',
				'objArgs'     => array( 'account' => $acct1 ),
				'sigArgs'     => array( 'account' => $acct2 ),
				'reason'      => 'Comparison of account failed: Comparison of name failed: value is not the same',
			),

			//
			// special cases where we can try to equate an mbox and an mbox SHA1 sum
			//
			array(
				'description' => 'this.mbox to signature.mbox_sha1sum',
				'objArgs'     => array( 'mbox' => COMMON_MBOX ),
				'sigArgs'     => array( 'mbox_sha1sum' => COMMON_MBOX_SHA1 ),
			),
			array(
				'description' => 'this.mbox_sha1sum to signature.mbox',
				'objArgs'     => array( 'mbox_sha1sum' => COMMON_MBOX_SHA1 ),
				'sigArgs'     => array( 'mbox' => COMMON_MBOX ),
			),
			array(
				'description' => 'this.mbox to signature.mbox_sha1sum non-matching',
				'objArgs'     => array( 'mbox' => COMMON_MBOX ),
				'sigArgs'     => array( 'mbox_sha1sum' => COMMON_MBOX_SHA1 . '-diff' ),
				'reason'      => 'Comparison of this.mbox to signature.mbox_sha1sum failed: no match',
			),
			array(
				'description' => 'this.mbox_sha1sum to signature.mbox non-matching',
				'objArgs'     => array( 'mbox_sha1sum' => COMMON_MBOX_SHA1 . '-diff' ),
				'sigArgs'     => array( 'mbox' => COMMON_MBOX ),
				'reason'      => 'Comparison of this.mbox_sha1sum to signature.mbox failed: no match',
			),
		);
		$this->runSignatureCases( 'TinCan\Agent', $cases );
	}
}
